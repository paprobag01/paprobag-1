<?php 
class Common_model extends CI_Model
{
function getAllDetails($data=null)
{
	if(count($data)>0){
		
		$where=$data['where'];
		$table=$data['table'];
		$order_by=$data['order_by'];
		$sql=$this->db->query('select * from '.$table.' '.$where.' '.$order_by.'');
		return $sql->result_array();
	}
}
function getDetail($data=null)
{
	if(count($data)>0){
		
		$where=$data['where'];
		$table=$data['table'];
		$order_by=$data['order_by'];
		$sql=$this->db->query('select * from '.$table.' '.$where.' '.$order_by.'');
		return $sql->row_array();
	}
}
function getAllProducts($data){
		
	$start=0;
	$limit=8;

	if(isset($_GET['pagid']))
	{

		$pagid=$_GET['pagid'];
		$start=($pagid-1)*$limit;
	 $start;
	}
	else
	{
		$pagid=1;
	}
	if(count($data)>0){

		$where=$data['where'];
		$table=$data['table'];
		$sql=$this->db->query('select * from '.$table.' '.$where.' limit '.$start.', '.$limit.'');
		return array($sql->result_array(), $pagid);
	}
}
function getPagination($data=null)
{
	
	if(count($data)>0){
	
		$where=$data['where'];
		$table=$data['table'];
		$order_by=$data['order_by'];
		
	$sql=$this->db->query('SELECT COUNT(*) as cnt FROM '.$table.' '.$where.'');
	$limit=8;

	foreach($sql->result_array() as $rw)
	{
		$rows=$rw['cnt'];
	}
	$total=ceil($rows/$limit);
	
	return array($total, $rows);
	}
}
}
?>