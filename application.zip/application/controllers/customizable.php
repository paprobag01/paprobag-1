<?php
class Customizable extends CI_Controller
{
	

	function __Construct(){
		parent::__construct();
		$this->load->model('common_model');
	}
	function getProducts($id=null,$prodType=null)
	{
		//echo $prodType; die;
	
		if(isset($prodType) && $prodType!=preg_match('/[A-Z]+[a-z]+[0-9]+/', $prodType))
		{
			$arr7['where']="";
			$arr7['table']='products';
			$arr7['order_by']='';
			$data['page_data']=$this->common_model->getAllDetails($arr7);
			$data['prodType']=$prodType;
				
			$arr8['where']="where ready_to_deliver=$prodType and deleted=0";
			$arr8['table']='categories';
			$arr8['order_by']='order by cat_position';
			$data['page_data8']=$this->common_model->getAllDetails($arr8);
			$subcatArr="";
			//	print_r($data['page_data8']); die;
			foreach ($data['page_data8'] as $row)
			{
				$catid= $row['cat_id'];
				$arr9['where']="where cat_id=$catid and deleted=0";
				$arr9['table']='subcategories';
				$arr9['order_by']='';
				$subcatArr[]=$this->common_model->getAllDetails($arr9);
			}
	
			$data['page_data9']=$subcatArr;
			/*
			 if($prodType==1)
			 {
			 $data['category_name']="Retail";
			 }
			 if($prodType==2)
			 {
			 $data['category_name']="Offers";
			 }
			 if($prodType==3)
			 {
			 $data['category_name']="Wholesale";
			 }
			 foreach($data['page_data'] as $row)
			 {
			 $catid=$row['cat_id'];
			 }
			 */
			//print_r($data['page_data7']); die;
		}
		else {
				
				
			$arr5="";
			if($prodType=='custm')
			{
				$arr5['where']="where cat_id=$id and customize_now=1 and deleted=0";
				$arr6['where']="where IsHome=1 and customize_now=1 and deleted=0";
			}
			if($prodType=='printready')
			{
				$arr5['where']="where cat_id=$id and ready_to_print=1 and deleted=0";
				$arr6['where']="where IsHome=1 and ready_to_print=1 and deleted=0";
			}
				
				
			$arr1['where']="where cat_id=$id and deleted=0";
			$arr1['table']='subcategories';
			$arr1['order_by']='';
			$data['page_data1']=$this->common_model->getAllDetails($arr1);
	
	
	
			$arr5['table']='categories';
			$arr5['order_by']='';
			$data['page_data3']=$this->common_model->getDetail($arr5);
	
	
			$cnt=sizeof($data['page_data1']);
			$subcatpage_dataArr="";
			$subcat_pagidArr="";
			$data_totalArr="";
			$data_limitArr="";
			for($i=0;$i<$cnt; $i++)
			{
			$subcatid=$data['page_data1'][$i]['sub_cat_id'];
			//echo $subcatid;
			$arr3['where']="where cat_id=$id and prod_sub_categories=$subcatid and deleted=0";
			$arr3['table']='products';
				$arr3['order_by']='';
	
	
					$arr4['where']="where cat_id=$id and prod_sub_categories=$subcatid and deleted=0";
					$arr4['table']='products';
							$arr4['order_by']='';
	
				$prodArr=$this->common_model->getAllProducts($arr3);
					$pagination=$this->common_model->getPagination($arr4);
	
					$subcatpage_dataArr[]=$prodArr[0];
					$subcat_pagidArr[]=$prodArr[1];
					$data_totalArr[]=$pagination[0];
					$data_limitArr[]=$pagination[1];
	
			}
			//	print_r($subcatpage_dataArr[1]);
					//die;
	
					$data['page_data2']=$subcatpage_dataArr;
				$data['pagid2']=$subcat_pagidArr;
					$data['total2']=$data_totalArr;
					$data['limit2']=$data_limitArr;
	
					$arr['where']="where cat_id=$id and deleted=0";
					$arr['table']='products';
					$arr['order_by']='';
	
	
							$arr2['where']="where cat_id=$id and deleted=0";
									$arr2['table']='products';
									$arr2['order_by']='';
	
									$prodArr=$this->common_model->getAllProducts($arr);
									$pagination=$this->common_model->getPagination($arr2);
									$data['page_data']=$prodArr[0];
				$data['pagid']=$prodArr[1];
				$data['total']=$pagination[0];
							$data['limit']=$pagination[1];
	
	
	
	
							$arr6['table']='categories';
									$arr6['order_by']='order by cat_position';
											$data['page_data6']=$this->common_model->getAllDetails($arr6);
		}
	
		$this->load->view("header_view", $data);
		$this->load->view("customizable_view", $data);
		$this->load->view("footer_view");
	}
		
}