<?php 
 class Categories extends CI_Controller{

		function __Construct(){
		parent::__construct();
		if(!$this->session->userdata('user_id')){
				   redirect("cms/login");
				}
				
               $this->load->library('site_sentry');
			}
      
	  function index(){
		  $data['page']='categories';
		  
		  $arr['table']='categories';
		$arr['where']='where deleted=0';
		$arr['and']="";
		$arr['order_by']="order by ready_to_print, ready_to_deliver, customize_now, cat_position"; 
		$data['page_data']=$this->site_sentry->get_all($arr); 
		 $this->load->view('cms/header_view', $data);
		 $this->load->view('cms/categories_list');
		 $this->load->view('cms/footer_view');
		
     }
	 function save_categories(){ 
		$id=$this->input->post("cat_id");
		$type="edit";
		$data['table']="categories"; 
		$this->site_sentry->Save_records($data);
		$this->viewCategory($id,$type);
	}
	function viewCategory($id=null,$type=null)
	{
		
		$arr['primary_id']=$id;
		$arr['table']='categories';
		$arr['where']="";
		$arr['and']="";
		$arr['order_by']="";
		  $data['page_data']=$this->site_sentry->PopulateValues($arr); 
		//  print_r($data['page_data']);die;
		  $data['page']='categories';
		  
		  $data['type']=$type;
		  
		 $this->load->view('cms/header_view', $data);
		 $this->load->view('cms/add_categories_view', $data);
		 $this->load->view('cms/footer_view', $data);
		 
		 
		
	}
	
	function deleteCategory($id=null)
	{
		$this->db->where('cat_id', $id);	
		$data= array(
		
		'deleted'=>1,
		'created_on'=>date('d-m-Y')
		
		);
		$this->db->update('categories', $data); 
		redirect('cms/categories');
	}
		
	
}
?>