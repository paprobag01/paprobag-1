<?php 
class service_model extends CI_Model{

			function get_all_service(){

			    $sql=$this->db->query("select * from services where service_status='Active'");
			    return $sql->result_array();
			
			}
			



}?>		