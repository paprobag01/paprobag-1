<?php 
extract($page_data);
?>
<!-- BEGIN PAGE -->  
      <div class="page-content"> 
         <!-- BEGIN PAGE CONTAINER-->
         <div class="container-fluid">
            <!-- BEGIN PAGE HEADER-->   
            <div class="row-fluid">
               <div class="span12"> 
                  <h3 class="page-title">
                     Create Categories
                  </h3> 
				   <p style="text-align:right"><button type="button" id="add_new" class="btn blue">View Subcategory Details</button></p>			
               </div>
            </div>
            <!-- END PAGE HEADER-->
            <!-- BEGIN PAGE CONTENT-->
            <div class="row-fluid">
               <div class="span12">
                  <!-- BEGIN SAMPLE FORM PORTLET-->   
				 
                  <div class="portlet box blue">
                     <div class="portlet-title">
                        <h4><i class="icon-reorder"></i>Add Category details</h4>
                        <div class="tools">
                           <a href="javascript:;" class="collapse"></a> 
                           <a href="javascript:;" class="remove"></a>
                        </div>
                     </div>
                     <div class="portlet-body form">
                        <!-- BEGIN FORM-->
                        <form action="<?php echo base_url()?>cms/categories/save_categories" class="form-horizontal" method="post" enctype="multipart/form-data" />
							<input type="hidden" name="cat_id" value="<?php echo $cat_id;?>"/>
							<input type="hidden" name="created_on" value="<?php echo date('d-m-Y')?>"/>
						   <!-- <div class="control-group">
                              <label class="control-label">Image :</label>
                              <div class="controls">
                                <div class="fileupload fileupload-new" data-provides="fileupload">
                                    <div class="fileupload-new thumbnail" style="width: 200px; height: 150px;">
                                       <?php if($air_image!=""){?>
										<img src="<?php echo base_url().$air_image;?>" /> 
										<?php } else {?>
									   <img src="<?php echo base_url()?>assets/img/noimage.gif" alt="" />
									   <?php }?>
									   <input type="hidden" value="<?php echo $air_image; ?>" name="img_url">	
                                    </div>
                                    <div class="fileupload-preview fileupload-exists thumbnail" style="max-width: 200px; max-height: 150px; line-height: 20px;"></div>
                                    <div>
                                       <span class="btn btn-file"><span class="fileupload-new">Select image</span>
                                       <span class="fileupload-exists">Change</span>
                                       <input type="file" name="fileinput" <?php if($type=='view'){?>disabled<?php }?> class="default" /></span>
                                       <a href="#" class="btn fileupload-exists" data-dismiss="fileupload">Remove</a>
                                    </div>
									
                                 </div> 
                              </div>
                           </div> 
						    <!-- <div class="control-group">
                              <label class="control-label">Date</label>
                              <div class="controls">
                                 <input type="text" <?php if($type=='view'){?>disabled<?php }?>  name="paper_date" id="paper_date" class="span4  m-wrap" value="<?php 
								 if($paper_date!='')
								 {
									echo date("d/m/Y",strtotime($paper_date)); 
								}?>" /> 
                              </div>
                           </div>-->	 
						    
						   <div class="control-group">
                              <label class="control-label">Category Name:</label>
                              <div class="controls">
                               <input type="text" <?php if($type=='view'){?>disabled<?php }?> name="category_name" id="category_name" value="<?php echo $category_name?>" class="span4  m-wrap" /> 
                              </div>
                           </div>
						   <div class="control-group">
                              <label class="control-label">Meta Title</label>
                              <div class="controls">
                                <!-- <textarea  name="details"  id="ai" class="span12 ckeditor m-wrap" cols="30" rows="10">  </textarea> -->
									
								  <input type="text" <?php if($type=='view'){?>disabled<?php }?> name="cat_meta_title" id="cat_meta_title" value="<?php echo $cat_meta_title; ?>" class="span4  m-wrap" /> 
                              </div>
                           </div>
						   <div class="control-group">
                              <label class="control-label">Meta Keywords</label>
                              <div class="controls">
                                 <textarea  name="cat_meta_keywords"  id="ai" class="span12 m-wrap" <?php if($type=='view'){?>disabled<?php }?> cols="30" rows="2"><?php echo $cat_meta_keywords;?></textarea>
									
								 
                              </div>
                           </div>
						    <div class="control-group">
                              <label class="control-label">Meta Description</label>
                              <div class="controls">
                                 <textarea  name="cat_meta_description"  id="ai" class="span12 m-wrap" <?php if($type=='view'){?>disabled<?php }?> cols="30" rows="2"><?php echo $cat_meta_description ?></textarea>
									
								 
                              </div>
                           </div>
						    <div class="control-group">
                              <label class="control-label">Category Image:</label>
                              <div class="controls">
                                <div class="fileupload fileupload-new" data-provides="fileupload">
                                    <?php if($type=='edit'){ ?><div class="fileupload-new thumbnail" style="width: 200px; height: 150px;">
                                       <?php if($image_url!=""){?>
										<img src="<?php echo base_url().$image_url?>" /> 
										<?php } else {?>
									   <img src="<?php echo base_url()?>images/noimage.gif" alt="" />
									   <?php }?>
									   <input type="hidden" value="<?php echo $image_url; ?>" name="img_url">	
                                    </div><?php } ?> 
                                    <div class="fileupload-preview fileupload-exists thumbnail" style="max-width: 200px; max-height: 150px; line-height: 20px;"></div>
                                    <div>
                                       <span class="btn btn-file"><span class="fileupload-new">Select image</span>
                                       <span class="fileupload-exists">Change</span>
                                       <input type="file" name="fileinput" <?php if($type=='view'){?>disabled<?php }?> class="default" /></span>
                                       <a href="#" class="btn fileupload-exists" data-dismiss="fileupload">Remove</a>
                                    </div>
									
                                 </div> 
                              </div>
                           </div> 
						     <div class="control-group">
                              <label class="control-label">Home Page:</label>
                              <div class="controls">
							  <select name="IsHome" <?php if($type=='view'){?>disabled<?php }?>>
								<?php 
								if($type=="edit")//IsOnProdDetails
								{
								if($IsHome==0)
								{
								?>
								<option value="1">Enable</option>
								<?php 
								}
								else{
								?>
								<option value="0">Disable</option>
								<?php 
								}
								}
								?>
								<option value="1">Enable</option>
								<option value="0">Disable</option>
								</select>
							  </div>
							  </div>
							  
							   <div class="control-group">
							  
								<label class="control-label">Add To Cart Page:</label>
                              <div class="controls">
							  <select name="IsOnProdDetails" <?php if($type=='view'){?>disabled<?php }?>>
								<?php 
								if($type=="edit")//IsOnProdDetails
								{
								if($IsOnProdDetails==0)
								{
								?>
								<option value="<?php echo $IsOnProdDetails;?>">Enable</option>
								<?php 
								}
								else{
								?>
								<option value="<?php echo $IsOnProdDetails;?>">Disable</option>
								<?php 
								}
								}
								?>
								<option value="1">Enable</option>
								<option value="0">Disable</option>
								</select>
							 
							  </div>
							  </div>
							  <div class="control-group">
	                              <label class="control-label">Ready To Deliver:</label>
		                              <div class="controls">
		                              <select name="ready_to_deliver" <?php if($type=='view'){?>disabled<?php }?>>
		                            <?php if($ready_to_deliver==0){ ?>
		                               <option value="<?php echo $ready_to_deliver?>">None</option>
		                              <?php } else if($ready_to_deliver==1){?>
		                              <option value="<?php echo $ready_to_deliver?>">Retail</option>
		                              <?php } else if($ready_to_deliver==2){?>
		                              <option value="<?php echo $ready_to_deliver?>">Offer</option>
		                              <?php } else if($ready_to_deliver==3){?>
		                              <option value="<?php echo $ready_to_deliver?>">Wholesale</option>
		                              <?php }?>
		                              <option value="1">Retail</option>
		                              <option value="2">Offer</option>
		                              <option value="3">Wholesale</option>
		                              </select>
		                              </div>
                              </div>
                              <div class="control-group">
	                              <label class="control-label">Ready To Print:</label>
		                              <div class="controls">
		                              <select name="ready_to_print" <?php if($type=='view'){?>disabled<?php }?>>
		                                <?php // if($type=="edit") { ?>
		                               <option value="<?php echo $ready_to_print?>"><?php if($ready_to_print==1){ echo "Yes"; } if($ready_to_print==0){ echo "No";}?></option>
		                               <?php // }?> -->
		                              <option value="1">Yes</option>
		                              <option value="0">No</option>
		                              
		                              </select>
		                              </div>
                              </div>
                              <div class="control-group">
	                              <label class="control-label">Customize Now:</label>
		                              <div class="controls">
		                              <select name="customize_now" <?php if($type=='view'){?>disabled<?php }?>>
		                               <?php // if($type=="edit") { ?>
		                               <option value="<?php echo $customize_now?>"><?php if($customize_now==1){ echo "Yes"; } if($customize_now==0){ echo "No";}?></option>
		                               <?php // }?> 
		                              <option value="1">Yes</option>
		                              <option value="0">No</option>
		                              
		                              </select>
		                              </div>
                              </div>
							  <div class="control-group">
                              <label class="control-label">Position:</label>
                              <div class="controls">
                               <input type="number" <?php if($type=='view'){?>disabled<?php }?> name="cat_position" id="cat_position" value="<?php echo $cat_position?>" class="span4  m-wrap" /> 
                              </div>
                           </div>
						  <?php if($type!='view'){ ?>
                           <div class="form-actions">
                           <button type="submit" class="btn blue">Save</button>
                              <button type="button" class="cancel btn">Cancel</button>
                           </div>
						   <?php }?>
                        </form>
                        <!-- END FORM-->           
                     </div>
                  </div>
                  <!-- END SAMPLE FORM PORTLET-->
               </div>
            </div>
			<script type="text/javascript">
			 $(document).ready(function(){
				 $("#add_new").click(function(){

				document.location="<?php echo base_url()?>cms/subcategories";
			});
				$(".cancel").click(function()
					{

					document.location="<?php echo base_url()?>cms/home_page/home_page_view";
				});             

				
		  });	
		  </script>	
			</div>
            </div>
			</div>