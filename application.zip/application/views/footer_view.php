					
					
					
			
 
			<!-- <footer id="footer" class="bg-color6" style="margin-top: -100px">
				<div class="container">
					<div class="row">
						<div class="col-md-3">
							<h4>Contact Us</h4>
							<p>Morbi accumsan ipsum velit. Nam nec tellus a odio tincidunt auctor</p>
							<address>
								Telephone: +91 (022) 40159568<br>
								Phone: +91 9702 945550<br>
								Email: <a href="mailto:info@softbunch.com">info@softbunch.com</a>
							</address>
							<ul class="social-icons">
								<li><a href="#" target="_blank" data-toggle="tooltip" data-placement="top" title="Facebook"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#" target="_blank" data-toggle="tooltip" data-placement="top" title="Twitter"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#" target="_blank" data-toggle="tooltip" data-placement="top" title="Google Plus"><i class="fa fa-google-plus"></i></a></li>
								<li><a href="#" target="_blank" data-toggle="tooltip" data-placement="top" title="Instagram"><i class="fa fa-instagram"></i></a></li>
								<li><a href="#" target="_blank" data-toggle="tooltip" data-placement="top" title="Flickr"><i class="fa fa-flickr"></i></a></li>
							</ul>
						</div>
						<div class="col-md-2">
							<h4>Useful links</h4>
							<ul class="list-links">
								<li><a href="#">About Us</a></li>
								<li><a href="#">Size guide</a></li>
								<li><a href="#">Postage + Delivery</a></li>
								<li><a href="#">Shipping & Returns</a></li>
								<li><a href="#">Privacy Policy</a></li>
								<li><a href="#">Returns + Exchangees</a></li>
								<li><a href="#">Terms + Conditions</a></li>
							</ul>
						</div>
						<div class="col-md-4">
							<h4>Newsletter</h4>
							
							<form role="form" class="form-newsletter">
								<div class="form-group">
									<label for="exampleInputEmail2" class="sr-only">Email address</label>
									<input type="email" placeholder="Your email address" id="exampleInputEmail2" class="form-control">
								</div>
								<button class="btn btn-lightdark" type="submit">Subscribe</button>
							</form>
						</div>
						<div class="col-md-3">
							<div class="footer-copyright">
								<p><img src="<?php echo base_url()?>images/paprobagsLogo.png" alt=""></p>
								<p> © 2015 Softbunch. All Rights Reserved. Designed by <a href="http://softbunch.com/" target="_blank">softbunch.com</a>.</p>
								<ul class="card-icons">
									<li><a href="#" target="_blank" data-toggle="tooltip" data-placement="top" title="Paypal"><i class="fa fa-cc-paypal"></i></a></li>
									<li><a href="#" target="_blank" data-toggle="tooltip" data-placement="top" title="Mastercard"><i class="fa fa-cc-mastercard"></i></a></li>
									<li><a href="#" target="_blank" data-toggle="tooltip" data-placement="top" title="Visa"><i class="fa fa-cc-visa"></i></a></li>
									<li><a href="#" target="_blank" data-toggle="tooltip" data-placement="top" title="Discover"><i class="fa fa-cc-discover"></i></a></li>
									<li><a href="#" target="_blank" data-toggle="tooltip" data-placement="top" title="AMEX"><i class="fa fa-cc-amex"></i></a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</footer>
		</div>

				<!-- Begin Search -->
		 <div class="modal fade bs-example-modal-lg search-wrapper" tabindex="-1" role="dialog" aria-hidden="true">
			<div class="modal-dialog modal-lg">
				<div class="modal-content">
					<p class="clearfix"><button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button></p>
					<form class="form-inline form-search" role="form">
						<div class="form-group">
							<label class="sr-only" for="textsearch">Enter text search</label>
							<input type="text" class="form-control input-lg" id="textsearch" placeholder="Enter text search">
						</div>
						<button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
					</form>
				</div>
			</div>
		</div>
		<!-- End Search -->
		
		<!-- Begin Login/Register -->
		 <div class="modal fade form-wrapper" tabindex="-1" role="dialog" aria-hidden="true">
			<div class="modal-dialog">
				<div class="modal-content">
					<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
					<ul role="tablist" class="nav nav-tabs grid-tabs text-center">
						<li class="active"><a data-toggle="tab" role="tab" href="#login">Login</a></li>
						<li><a data-toggle="tab" role="tab" href="#register">Register</a></li>
					</ul>
					<div class="tab-content">
						<div id="login" class="tab-pane active">
							<form class="form-block" role="form">
								<div class="text-center">
									<h2>I'm already a member</h2>
									<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr sed diam nonumy eirmod tempor invidunt proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
								</div>
								<div class="form-group">
									<label for="lemail" class="control-label sr-only">Email</label>
									<input type="email" class="form-control" id="lemail" placeholder="Email">
								</div>
								<div class="form-group">
									<label for="lpassword" class="control-label sr-only">Password</label>
									<input type="password" class="form-control" id="lpassword" placeholder="Password">
								</div>
								<div class="form-group text-center">
									<div class="checkbox">
										<label><input type="checkbox"> Remember me</label>
										<a href="#">Lost Password?</a>
									</div>
								</div>
								<div class="form-group text-center">
									<button type="submit" class="btn btn-default">Login</button>
								</div>
							</form>
						</div>
						<div id="register" class="tab-pane">
							<form class="form-block" role="form">
								<div class="text-center">
									<h2>I'm new here</h2>
									<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr sed diam nonumy eirmod tempor invidunt proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
								</div>
								<div class="form-group">
									<label for="name" class="control-label sr-only">Name</label>
									<input type="text" class="form-control" id="name" placeholder="Name">
								</div>
								<div class="form-group">
									<label for="resemail" class="control-label sr-only">Email</label>
									<input type="email" class="form-control" id="resemail" placeholder="Email">
								</div>
								<div class="form-group">
									<label for="respassw" class="control-label sr-only">Password</label>
									<input type="password" class="form-control" id="respassw" placeholder="Password">
								</div>
								<div class="form-group text-center">
									<button type="submit" class="btn btn-default">Register</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- End Login/Register -->
		
		<!-- Begin Quickview -->
		<!-- <div class="modal fade quickview-wrapper" id="quickview-detail" tabindex="-1" role="dialog" aria-hidden="true">
			<div class="modal-dialog modal-lg">
				<div class="modal-content">
					<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
					<div class="product-detail">
						<div class="row">
							<div class="col-md-6">
								<div class="product-preview">
									<div class="flexslider flexsliderModal">
										<ul class="slides">
											<li data-thumb="images/products/product-9.jpg">
												<img src="<?php echo base_url()?>images/products/product-9.jpg" alt="">
											</li>
											<li data-thumb="images/products/product-8.jpg">
												<img src="<?php echo base_url()?>images/products/product-8.jpg" alt="">
											</li>
											<li data-thumb="images/products/product-7.jpg">
												<img src="<?php echo base_url()?>images/products/product-7.jpg" alt="">
											</li>
											<li data-thumb="images/products/product-6.jpg">
												<img src="<?php echo base_url()?>images/products/product-6.jpg" alt="">
											</li>
										</ul>
									</div>
								</div>
							</div>
							<div class="col-md-6">
								<div class="thumb-item thumb-item-list summary">
									<div class="thumb-item-content">
										<h3><a href="#">Silver Stainless Steel</a></h3>
										<ul class="list-review">
											<li>
												<div class="star-rating" title="Rated 5.00 out of 5">
													<span style="width:100%"><strong class="rating">5.00</strong> out of 5</span>
												</div>
											</li>
											<li>0 Review</li>
											<li class="btn-add-review"><a href="#">Add Your Review</a></li>
										</ul>
										<p class="product-price"><ins>$280.00</ins></p>
										<p>Nam ullamcorper neque non erat elementum vulputate. Nullam dignissim lobortis interdum. Donec nisi est, tempus eget. Nam ullamcorper neque non erat elementum vulputate. Nullam dignissim lobortis interdum.</p>
										<p class="quan">
											<label>Qty:</label>
											<input type="text" name="quantity" value="1" title="Qty" class="input-text qty">
										</p>
										<p class="thumb-act thumb-act-more">
											<a href="#" class="btn-cart"><i class="fa fa-shopping-cart"></i> <span>Add to Cart</span></a>
											<a href="#"><i class="fa fa-heart-o"></i></a>
											<a href="#"><i class="fa fa-exchange"></i></a>
										</p>
										<hr>
										<p class="product-cat">Category: <a href="#">Bottoms</a>.</p>
										<ul class="social-icons-share">
											<li><label>Share on:</label></li>
											<li><a href="#" target="_blank" data-toggle="tooltip" data-placement="top" title="Facebook"><i class="fa fa-facebook"></i></a></li>
											<li><a href="#" target="_blank" data-toggle="tooltip" data-placement="top" title="Twitter"><i class="fa fa-twitter"></i></a></li>
											<li><a href="#" target="_blank" data-toggle="tooltip" data-placement="top" title="Google Plus"><i class="fa fa-google-plus"></i></a></li>
											<li><a href="#" target="_blank" data-toggle="tooltip" data-placement="top" title="Pinterest"><i class="fa fa-pinterest"></i></a></li>
											<li><a href="#" target="_blank" data-toggle="tooltip" data-placement="top" title="Email"><i class="fa fa-envelope-o"></i></a></li>
										</ul>
									</div>
								</div>
								
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- End Quickview -->
		
		<!-- <div id="offcanvas" class="uk-offcanvas">
            <div class="uk-offcanvas-bar">
				<ul id="main-menu-offcanvas" class="uk-nav-offcanvas" data-uk-nav>
					<li class="uk-parent uk-active">
						<a href="#">Home</a>
						<ul class="uk-nav-sub">
							<li class="active"><a href="index.html">Home Version 1</a></li>
							<li><a href="index-2.html">Home Version 2</a></li>
							<li><a href="index-3.html">Home Version 3</a></li>
							<li><a href="index-4.html">Home Version 4</a></li>
							<li><a href="index-5.html">Home Version 5</a></li>
						</ul>
					</li>
					<li class="uk-parent">
						<a href="#">Men</a>
						<ul class="uk-nav-sub">
							<li><a href="#">Coats and Trench coats</a></li>
							<li><a href="#">Jackets</a></li>
							<li><a href="#">Blazers</a></li>
							<li><a href="#">Suits</a></li>
							<li><a href="#">Edition</a></li>
							<li><a href="#">Trousers</a></li>
							<li><a href="#">Jeans</a></li>
							<li><a href="#">Shirts</a></li>
							<li><a href="#">T-shirts</a></li>
							<li><a href="#">Sweatshirts</a></li>
							<li><a href="#">Shoes</a></li>
							<li><a href="#">Bags</a></li>
							<li><a href="#">Accessories</a></li>
						</ul>
					</li>
					<li class="uk-parent">
						<a href="#">Women</a>
						<ul class="uk-nav-sub">
							<li><a href="#">Coats and Trench coats</a></li>
							<li><a href="#">Jackets</a></li>
							<li><a href="#">Blazers</a></li>
							<li><a href="#">Suits</a></li>
							<li><a href="#">Edition</a></li>
							<li><a href="#">Trousers</a></li>
							<li><a href="#">Jeans</a></li>
							<li><a href="#">Shirts</a></li>
							<li><a href="#">T-shirts</a></li>
							<li><a href="#">Sweatshirts</a></li>
							<li><a href="#">Shoes</a></li>
							<li><a href="#">Bags</a></li>
							<li><a href="#">Accessories</a></li>
						</ul>
					</li>
					<li class="uk-parent">
						<a href="#">Shop</a>
						<ul class="uk-nav-sub">
							<li><a href="shop-grid-fullwidth.html">Shop Grid Full Width</a></li>
							<li><a href="shop-grid-classic.html">Shop Grid Classic</a></li>
							<li><a href="shop-product-grid.html">Shop Product Grid</a></li>
							<li><a href="shop-list-sidebar.html">Shop List Sidebar</a></li>
							<li><a href="shop-product-detail-fullwidth.html">Product Detail FullWidth</a></li>
							<li><a href="shop-product-detail-classic.html">Product Detail Classic</a></li>
							<li><a href="shop-product-detail-custom.html">Product Detail Custom</a></li>
							<li><a href="shop-cart-full.html">Shopping Cart Full</a></li>
							<li><a href="shop-checkout.html">Shop-Checkout</a></li>
						</ul>
					</li>
					<li class="uk-parent">
						<a href="#">Blog</a>
						<ul class="uk-nav-sub">
							<li><a href="blog.html">Blog Full Width</a></li>
							<li><a href="blog-mansory.html">Blog Mansory</a></li>
							<li><a href="blog-sidebar.html">Blog Sidebar</a></li>
							<li><a href="blog-single.html">Blog Single</a></li>
						</ul>
					</li>
					<li class="uk-parent">
						<a href="#">Pages</a>
						<ul class="uk-nav-sub">
							<li><a href="page-about.html">About Us</a></li>
							<li><a href="page-404.html">Page 404</a></li>
						</ul>
					</li>
					<li class="uk-parent">
						<a href="contact.html">Contact Us</a>
					</li>
				</ul>
			</div>
		</div>	-->
		
		
		<div id="offcanvas-cart" class="uk-offcanvas">
			<div class="uk-offcanvas-bar uk-offcanvas-bar-flip">
				<div class="uk-panel" id="minicartProds">
				
					<?php 
					if(isset($_SESSION['cart']))
					{
						if($_SESSION['cartqty']>0)
						{
					$subtotal=0;
		$html='<h3>Cart</h3><ul class="list-thumbs-pro" >';
		foreach($_SESSION['cart'] as $k=>$v)
		{
			$subtotal=$subtotal+intval($v["prod_price"])*intval($v["quantity"]);
				$html.='<div class="shopp" id="each">';
				$html.='<div class="label1">Product Name:'.$v["prod_name"].'</div>';
				$html.='<div class="shopp-price"><em>Price:'.intval($v["prod_price"])*intval($v["quantity"]).'</em></div>';
				$html.='Quantity<span class="shopp-quantity">'.$v["quantity"].'</span>';
				$html.='<a onclick="getProdInfo'.$v["prod_id"].'('.$v["prod_id"].')"><img src="'.base_url().'images/remove.png" class="removeProd" /><br class="all" /></a>';
				$html.='</div>';
		}
		$html.='</ul>';
		$html.='<ul class="list-inline cart-subtotals">';
		$html.='<li class="cart-subtotal"><strong>Subtotal:</strong></li>';
		$html.='<li class="price"><span class="amount"><strong id="cart-total">'.$subtotal.'</strong></span></li>';
		$html.='<ul class="list-inline cart-subtotals">';
		$html.='<a href="" class="btn btn-dark btn-block">View Cart</a>';
		$html.='<a href="shop-checkout.html" class="btn btn-primary btn-block">Go to Checkout</a>';
		echo $html;
					}
					else{
						echo "Cart is empty";
					}
					}
					?>
				</div>
			</div>
		</div> 
		<a name="footer"></a>
		<footer id="footer" class="bg-color6">
				<div class="container" >
				
                
				<div  style="background:#414141;padding:20px;">
					<div class="row">
						<div class="col-md-31">
							<h4 class="foooterTitle">Help</h4>
							<span class="footrtitlebgimg"><img src="<?php echo base_url()?>images/footerTitleArrow.png" class="footerimg"/></span>
							<ul class="list-links">
								<li><a href="#">Product List</a></li>
								<li><a href="#">Contact Us</a></li>
								<li><a href="#">Delivery</a></li>
								<li><a href="#">FAQ</a></li>
								
								
								
							</ul>
						</div>
						<div class="col-md-31">
							<h4 class="foooterTitle">Policy</h4>
							<span class="footrtitlebgimg"><img src="<?php echo base_url()?>images/footerTitleArrow.png" class="footerimg"/></span>
							<ul class="list-links">
								<li><a href="#">Cancellation and Refund</a></li>
								<li><a href="#">Return and Replacement</a></li>
								<li><a href="#">Terms and Conditions</li>
								<li><a href="#">Privacy Policy</a></li>
								
							</ul>
						</div>
						<div class="col-md-31">
							<h4 class="foooterTitle">Paprobag</h4>
							<span class="footrtitlebgimg"><img src="<?php echo base_url()?>images/footerTitleArrow.png" class="footerimg"/></span>
							<ul class="list-links">
								<li><a href="#">About Us</a></li>
								<li><a href="#">Career</a></li>
								<li><a href="#">Seller</li>
								<li><a href="#">Investor</a></li>
								
							</ul>
						</div>
						<div class="col-md-31">
							<h4 class="foooterTitle">Get Social</h4>
							<span class="footrtitlebgimg"><img src="<?php echo base_url()?>images/footerTitleArrow.png" class="footerimg"/></span>
							<ul class="social-icons">
								<li><a href="#" target="_blank" data-toggle="tooltip" data-placement="top" title="" data-original-title="Facebook"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#" target="_blank" data-toggle="tooltip" data-placement="top" title="" data-original-title="Twitter"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#" target="_blank" data-toggle="tooltip" data-placement="top" title="" data-original-title="Google Plus"><i class="fa fa-google-plus"></i></a></li>
								<li><a href="#" target="_blank" data-toggle="tooltip" data-placement="top" title="" data-original-title="Instagram"><i class="fa fa-instagram"></i></a></li>
								<!-- <li><a href="#" target="_blank" data-toggle="tooltip" data-placement="top" title="" data-original-title="Flickr"><i class="fa fa-flickr"></i></a></li>-->
							</ul>
						</div>
						<div class="col-md-31">
							<h4 class="foooterTitle">Payment Methods</h4>
							<span class="footrtitlebgimg"><img src="<?php echo base_url()?>images/footerTitleArrow.png" class="footerimg"/></span>
							<ul class="card-icons">
									<li><a href="#" target="_blank" data-toggle="tooltip" data-placement="top" title="" data-original-title="Paypal"><i class="fa fa-cc-paypal"></i></a><div class="tooltip fade top" role="tooltip" id="tooltip453013" style="top: 146px; left: 99.703125px; display: block;"><div class="tooltip-arrow"></div><div class="tooltip-inner">Paypal</div></div></li>
									<li><a href="#" target="_blank" data-toggle="tooltip" data-placement="top" title="" data-original-title="Mastercard"><i class="fa fa-cc-mastercard"></i></a></li>
									<li><a href="#" target="_blank" data-toggle="tooltip" data-placement="top" title="" data-original-title="Visa"><i class="fa fa-cc-visa"></i></a></li>
									<li><a href="#" target="_blank" data-toggle="tooltip" data-placement="top" title="" data-original-title="Discover"><i class="fa fa-cc-discover"></i></a></li>
									<li><a href="#" target="_blank" data-toggle="tooltip" data-placement="top" title="" data-original-title="AMEX"><i class="fa fa-cc-amex"></i></a></li>
								</ul>
						</div>
						
						
					</div>
				</div>				
</div>
</footer>
		
		<!-- Begin Style Switcher -->
	
		<!-- Begin Style Switcher -->
	
		<!-- Vendor -->
		<script type="text/javascript" src="<?php echo base_url()?>admin/bootstrap-fileupload/bootstrap-fileupload.js"></script>
		<?php
		
		if(isset($gallery))
		{
			?>
			<!-- For Gallery -->
		<script src="<?php echo base_url() ?>ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js" type="text/javascript"></script>
		<script src="<?php echo base_url() ?>scripts/jquery.masonry.min.js" type="text/javascript"></script>
		<script src="<?php echo base_url() ?>scripts/jquery.easing.1.3.js" type="text/javascript"></script>
		<script src="<?php echo base_url() ?>scripts/MetroJs.lt.js" type="text/javascript"></script>
		<script src="<?php echo base_url() ?>scripts/jquery.fancybox-1.3.4.js" type="text/javascript" charset="utf-8"></script>
		<script src="<?php echo base_url() ?>scripts/jquery.flexslider-min.js" type="text/javascript" charset="utf-8"></script>
		<script src="<?php echo base_url() ?>scripts/hoverintent.js" type="text/javascript" charset="utf-8"></script>
		<script src="<?php echo base_url() ?>scripts/jquery.jplayer.min.js" type="text/javascript" charset="utf-8"></script>
		<script src="<?php echo base_url() ?>scripts/organictabs.jquery.js" type="text/javascript" charset="utf-8"></script>
		<script src="<?php echo base_url() ?>scripts/javascript.js" type="text/javascript"></script>
		<script src="<?php echo base_url() ?>scripts/mediaplayer.js" type="text/javascript"></script>
		<script src="<?php echo base_url() ?>vendor/magnific-popup/jquery.magnific-popup.js"></script>
		<script src="<?php echo base_url() ?>vendor/uikit/uikit.js"></script>
			<?php 
		}
		else if(isset($measurement))
		{
			?>
			
			 <script type="text/javascript">
        var _qevents = _qevents || [];

        (function() {

          var elem = document.createElement('script');
              elem.src = (document.location.protocol == "https:" ?  "https://secure" : "http://edge") + ".quantserve.com/quant.js";
              elem.async = true;
              elem.type = "text/javascript";

          var scpt = document.getElementsByTagName('script')[0];
          scpt.parentNode.insertBefore(elem, scpt);
        })();

        function p2l(pathname,query,hash){
          pathname = pathname.replace(/\//gi,"__")

          if(pathname === "__") { pathname = "homepage"; }

          pathname = pathname.replace(/\./gi,"_");
          query = query.replace(/\?/gi,'­');
          params = query.split('&');
          args = []

          for(arg = 0; arg < params.length; arg++){
            args.push(params[arg].split('=')[0]);
          }

          pathname += args.join('­');
          pathname += hash.replace(/#/gi,"­");
          return pathname;
        };

        _qevents.push({
          qacct:"p-VJ6J4nQgte0MN",
          labels: "_fp.event." + p2l(document.location.pathname,
          document.location.search, document.location.hash)
        });
    </script>

    
    <!--End Quantcast tag-->


<!-- Crazy Egg-->
<script type="text/javascript">
setTimeout(function(){var a=document.createElement("script");
var b=document.getElementsByTagName("script")[0];
a.src=document.location.protocol+"//dnn506yrbagrg.cloudfront.net/pages/scripts/0024/6012.js?"+Math.floor(new Date().getTime()/3600000);
a.async=true;a.type="text/javascript";b.parentNode.insertBefore(a,b)}, 1);
</script>
<!-- // Crazy Egg-->
<script type="text/javascript" src="js/customize3.js" global_footer></script>
<div class="ajaxLoginWrapper"></div>
<script type="text/javascript">
//<![CDATA[
    BL.AJAXLOGIN.LOGINLINK = '/ajax_login/ajax/fetchForm';
//]]>
</script>
	

	<script type="text/javascript">
		(function($){
			$(document).ready(function() {
				var triggers = '';
				
				$('a.jqm').each(function(){
					//prevent staring of wedding form in default jqm wrapper
					if($(this).hasClass('weddings-btn')){
						return true;
					} else {
						//add ids as triggers of default jqm wrapper
						triggers += '#'+$(this).attr('id')+', ';
					}
					
				});
				
				$('a.jqm').click(function(event){
					event.preventDefault();
				});
				
				$('.conciergeFormWrap').jqm({
					trigger: triggers,
					ajax: '@href',
					ajaxText: '<br>Please wait...',
					modal: true
				});
			});
		})(jQuery);
	</script>
<script type="text/javascript">window.NREUM||(NREUM={});NREUM.info={"beacon":"beacon-5.newrelic.com","licenseKey":"721f623b5d","applicationID":"1404437","transactionName":"b1dbbUdUXRdYUUMPWFYdeFpBXFwKFkJFCVRdQUpmRUdcAExRQzlUTUFNVlhcSQEWW1kCUkAdT1BQQg==","queueTime":0,"applicationTime":811,"atts":"QxBYGw9OThk=","errorBeacon":"bam.nr-data.net","agent":"js-agent.newrelic.com\/nr-476.min.js"}</script>
			<?php 
		}
		else if(isset($customize))
		{
			?>
			<script type="text/javascript">
        var _qevents = _qevents || [];

        (function() {

          var elem = document.createElement('script');
              elem.src = (document.location.protocol == "https:" ?  "https://secure" : "http://edge") + ".quantserve.com/quant.js";
              elem.async = true;
              elem.type = "text/javascript";

          var scpt = document.getElementsByTagName('script')[0];
          scpt.parentNode.insertBefore(elem, scpt);
        })();

        function p2l(pathname,query,hash){
          pathname = pathname.replace(/\//gi,"__")

          if(pathname === "__") { pathname = "homepage"; }

          pathname = pathname.replace(/\./gi,"_");
          query = query.replace(/\?/gi,'­');
          params = query.split('&');
          args = []

          for(arg = 0; arg < params.length; arg++){
            args.push(params[arg].split('=')[0]);
          }

          pathname += args.join('­');
          pathname += hash.replace(/#/gi,"­");
          return pathname;
        };

        _qevents.push({
          qacct:"p-VJ6J4nQgte0MN",
          labels: "_fp.event." + p2l(document.location.pathname,
          document.location.search, document.location.hash)
        });
    </script>

    <noscript>
      <div style="display:none;">
        <img src="../../../../../../pixel.quantserve.com/pixel/p-VJ6J4nQgte0MN.gif" border="0" height="1" width="1" alt="Quantcast"/>
      </div>
    </noscript>
    <!--End Quantcast tag-->
</footer>

<!-- Crazy Egg-->
<script type="text/javascript">
setTimeout(function(){var a=document.createElement("script");
var b=document.getElementsByTagName("script")[0];
a.src=document.location.protocol+"//dnn506yrbagrg.cloudfront.net/pages/scripts/0024/6012.js?"+Math.floor(new Date().getTime()/3600000);
a.async=true;a.type="text/javascript";b.parentNode.insertBefore(a,b)}, 1);
</script>
<!-- // Crazy Egg-->
<script type="text/javascript" src="<?php echo base_url()?>js/84ea5b321ee1a92169fbd48ceb5b61c4.js" global_footer></script>
<div class="ajaxLoginWrapper"></div>
<script type="text/javascript">
//<![CDATA[
    BL.AJAXLOGIN.LOGINLINK = '/ajax_login/ajax/fetchForm';
//]]>
</script>
	<div class="conciergeFormWrap"></div>

	<script type="text/javascript">
		(function($){
			$(document).ready(function() {
				var triggers = '';
				
				$('a.jqm').each(function(){
					//prevent staring of wedding form in default jqm wrapper
					if($(this).hasClass('weddings-btn')){
						return true;
					} else {
						//add ids as triggers of default jqm wrapper
						triggers += '#'+$(this).attr('id')+', ';
					}
					
				});
				
				$('a.jqm').click(function(event){
					event.preventDefault();
				});
				
				$('.conciergeFormWrap').jqm({
					trigger: triggers,
					ajax: '@href',
					ajaxText: '<br>Please wait...',
					modal: true
				});
			});
		})(jQuery);
	</script>
<script type="text/javascript">window.NREUM||(NREUM={});NREUM.info={"beacon":"beacon-5.newrelic.com","licenseKey":"721f623b5d","applicationID":"1404437","transactionName":"b1dbbUdUXRdYUUMPWFYdeFpBXFwKFkJFCVRdQUpmRUdcAExRQzlUTUFNVlhcSQEWW1kCUkAdT1BQQg==","queueTime":0,"applicationTime":916,"atts":"QxBYGw9OThk=","errorBeacon":"bam.nr-data.net","agent":"js-agent.newrelic.com\/nr-476.min.js"}</script>
			<?php
		}
		else{
			?>
		<script src="<?php echo base_url()?>js/jquery-2.1.1.min.js"></script>
		<script src="<?php echo base_url()?>js/component.js"></script>
		<script src="<?php echo base_url()?>vendor/jquery/jquery.js"></script>
		<script src="<?php echo base_url()?>vendor/bootstrap/bootstrap.js"></script>
		<script src="<?php echo base_url()?>vendor/jquery.validation/jquery.validation.js"></script>
		<script src="<?php echo base_url()?>vendor/owlcarousel/owl.carousel.js"></script>
		<script src="<?php echo base_url()?>vendor/flexslider/jquery.flexslider-min.js"></script>
		<script src="<?php echo base_url()?>vendor/countdown/countdown.min.js"></script>
		<script src="<?php echo base_url()?>vendor/chosen/chosen.jquery.min.js"></script>
		<script src="<?php echo base_url()?>vendor/pricefilter/jquery.pricefilter.js"></script>
		<script src="<?php echo base_url()?>vendor/masonry/imagesloaded.pkgd.min.js"></script>
		<script src="<?php echo base_url()?>vendor/masonry/masonry.pkgd.min.js"></script>
		<script src="<?php echo base_url()?>vendor/uikit/uikit.js"></script>
		<script src="<?php echo base_url()?>vendor/magnific-popup/jquery.magnific-popup.js"></script>
		<script src="<?php echo base_url()?>Vistaprint_files/Footer_min.js" type="text/javascript"></script>
		<script src="<?php echo base_url()?>js/theme.js"></script>
		<script src="<?php echo base_url()?>js/jquery-1.8.3.min.js"></script>
		<script src="<?php echo base_url()?><?php echo base_url() ?>style-switcher/js/switcher.js" type="text/javascript"></script>
		<?php } ?>
	</body>

<!-- Mirrored from pixelgeeklab.com/html/marvel/index-4.html by HTTrack Website Copier/3.x [XR&CO'2013], Thu, 08 Jan 2015 07:52:26 GMT -->
</html>