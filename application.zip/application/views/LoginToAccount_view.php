<section class="main-content-wrap">
					<div class="container">
						<div class="row">
							<div class="col-md-12 main-content main-content-full">
								<div class="row featured-box featured-box-secondary">
								<div class="col-md-12 text-center" style="border-bottom:1px solid #eed;">
								<h5><a style="border-bottom:1px solid #999;">LOGIN TO YOUR ACCOUNT</a></h5>
								<span>Dont Have One? <a href="<?php echo base_url()?>createAccount" style="color:#ba5a02">Create An Account</a></span>
								</div>
								<div class="col-md-12">
								
								</div>
								
								<div class="col-md-2">
								&nbsp;
								</div>
									<div class="col-md-4">
										<div class="col-md-12">&nbsp;</div>
										<div class="col-md-12">&nbsp;</div>
										<div class="featured-box featured-box-secondary featured-box-cart">
											<div class="box-content">
												
												<form action="<?php echo base_url()?>userregistration" method="post">
												<div class="form-horizontal">
										
												
													
													<div class="form-group">
													
														<label for="inputEmail3" class="col-sm-4 control-label">Email Address <span class="required">*</span></label>
														<div class="col-sm-8">
															<input type="email" class="form-control" name="inputEmail3" id="inputEmail3" required>
														</div>
													</div>
													<div class="form-group">
														<label for="inputEmail3" class="col-sm-4 control-label">Password<span class="required">*</span></label>
														<div class="col-sm-8">
															<input type="password" class="form-control" name="inputPassword" id="inputEmail3" required>
														</div>
													</div>
													
													
													<div class="form-group">
														<label for="textNotes" class="col-sm-4 control-label"></label>
														<div class="col-sm-8 thumb-act thumb-act-more text-center">
															<button type="submit" class="col-sm-12 btn-cart" style="color:#fff;">Login</button>
														</div>
													</div>
													
												</div>
												</form>
											</div>
										</div>

									</div>
									
									<div class="col-md-6">
									
										<div class="featured-box featured-box-secondary">
											<div class="box-content social_buttons">
												
												<ul>
												
<li>
<a class="social_btn facebook_btn" href="/auth/facebook">Sign In using facebook</a>
</li>
<li>
<a class="social_btn google_btn" href="/auth/google_oauth2">Sign In using google</a>
</li>
</ul>
												
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</section>