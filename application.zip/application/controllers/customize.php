<?php 
session_start();
 class Customize extends CI_Controller{

		function __Construct(){
		
				parent::__construct();
               $this->load->model('customize_model');
			  // $this->load->model('header_model');
			}
      
	
	function SaveCustomizations()
	 {
		 $customizations=$this->input->post('options');
		 $prod_id_for_cust_measurement=$this->input->post('prod_id');//custom_price
		 $customPrices=$this->input->post('custom_price');
		// print_r($customPrices); die;
		$_SESSION['prod_id']=$prod_id_for_cust_measurement;
		$_SESSION['cusomizations_for_product'][$prod_id_for_cust_measurement]=array($prod_id_for_cust_measurement=>$customizations); 
		$_SESSION['custom_prices_for_product'][$prod_id_for_cust_measurement]=array($prod_id_for_cust_measurement=>$customPrices);
		//print_r($_SESSION['cusom_prices_for_product']); die;
		if(isset($_SESSION['cusomizations_for_product']))
		{
		redirect('ContinueCheckout');
		}
		else
		{
			echo "Please follow the customization steps first";
		}
		
		 
	 }
	 function getCustomizations($ctid=null,$prodid=null)
	 {
		 
		 $reslt=$this->customize_model->get_Customizations($ctid);
		  $custmreslt=$reslt[0];
		  $cout=$reslt[1];
		  foreach($cout as $rw)
		  {
			  $custmcout=$rw['cnt'];
		  }
		  $types=$reslt[2];
		  $type_names=$reslt[3];
		  $data['custmreslt']=$custmreslt;
		  $data['custmcout']=$custmcout;
		  $data['types']=$types;//$type_names
		  $data['type_names']=$type_names;
		  $data['customize']="89898989";
		  $data['catid']=$ctid;
		  $data['prodid']=$prodid;
		 // print_r($data['custmreslt']); die;
		 $this->load->view('header_view', $data);
		 $this->load->view('customize_view',$data);
		 $this->load->view('footer_view', $data);
		
	 }
	 
   
}
?>