<?php 
class Products extends CI_COntroller
{
			function __Construct(){
			parent::__construct();
			$this->load->model('common_model');
			}
			function getProducts($id=null,$prodType=null)
			{
				//echo $prodType; die;
				
				
				
				if(isset($prodType) && $prodType!="custm" && $prodType!="printready")
				{
					$arr7['where']="";
					$arr7['table']='products';
					$arr7['order_by']='';
					$data['page_data']=$this->common_model->getAllDetails($arr7);
					$data['prodType']=$prodType;
					
					$arr8['where']="where ready_to_deliver=$prodType and deleted=0";
					$arr8['table']='categories';
					$arr8['order_by']='order by cat_position';
					$data['page_data8']=$this->common_model->getAllDetails($arr8);
					$subcatArr="";
				//	print_r($data['page_data8']); die;
				foreach ($data['page_data8'] as $row)
				{
					$catid= $row['cat_id'];
					$arr9['where']="where cat_id=$catid and deleted=0";
					$arr9['table']='subcategories';
					$arr9['order_by']='';
					$subcatArr[]=$this->common_model->getAllDetails($arr9);
				}
				
				$data['page_data9']=$subcatArr;
					/*
					if($prodType==1)
					{
					$data['category_name']="Retail";
					}
					if($prodType==2)
					{
						$data['category_name']="Offers";
					}
					if($prodType==3)
					{
						$data['category_name']="Wholesale";
					}
					foreach($data['page_data'] as $row)
					{
						$catid=$row['cat_id'];
					}
					*/
					//print_r($data['page_data7']); die;
				}
				else {
					
					
					$arr5="";
					if($prodType=='custm')
					{
						$arr5['where']="where cat_id=$id and customize_now=1 and deleted=0";
						$arr6['where']="where IsHome=1 and customize_now=1 and deleted=0";
						$data['ProdType']=$prodType;
					}
					if($prodType=='printready')
					{
						$arr5['where']="where cat_id=$id and ready_to_print=1 and deleted=0";
						$arr6['where']="where IsHome=1 and ready_to_print=1 and deleted=0";
						$data['ProdType']=$prodType;
					}
					
					
				$arr1['where']="where cat_id=$id and deleted=0";
				$arr1['table']='subcategories';
				$arr1['order_by']='';
				$data['page_data1']=$this->common_model->getAllDetails($arr1);
				
			//	print_r($data['page_data1']); die;
				
				$arr11['table']='subcategories';
				$arr11['order_by']='';
				$arr11['where']="where cat_id=$id and deleted=0";
				$data['page_data11']=$this->common_model->getAllDetails($arr11);
				
				//$subcatid=intval($data['page_data11']['sub_cat_id']);
				$subcategoryArr=$data['page_data11'];
				$pagedata10Arr="";
				if(!empty($subcategoryArr))
				{
				foreach ($subcategoryArr as $row)
				{
					$subcatid=intval($row['sub_cat_id']);
					
				$arr10['where']="where sub_cat_id=$subcatid and deleted=0";
				$arr10['table']='sub_subcategories';
				$arr10['order_by']='';
				$pagedata10Arr[]=$this->common_model->getAllDetails($arr10);
				}
				}
				
			//print '<pre>'; print_r($pagedata10Arr); die;
				$subsubcatArr="";
				if(!empty($pagedata10Arr))
				{
				foreach($pagedata10Arr as $row){
					//print_r($row);
					$subsubcatArr[]=$row;
				} 
				}
				//print_r($subsubcatArr); die;
				$arr5['table']='categories';
				$arr5['order_by']='';
				$data['page_data3']=$this->common_model->getDetail($arr5);
				
				
				$cnt=sizeof($data['page_data1']);
				$subcatpage_dataArr="";
				$subcat_pagidArr="";
				$data_totalArr="";
				$data_limitArr="";
				//echo $cnt; die;
				if($cnt!=0)
				{
				for($i=0;$i<$cnt; $i++)
				{
				$subcatid=$data['page_data1'][$i]['sub_cat_id'];
				
				$arr3['where']="where cat_id=$id and prod_sub_categories=$subcatid and deleted=0";
				$arr3['table']='products';
				$arr3['order_by']='';
				
				
				$arr4['where']="where cat_id=$id and prod_sub_categories=$subcatid and deleted=0";
				$arr4['table']='products';
				$arr4['order_by']='';
				
				$prodArr=$this->common_model->getAllProducts($arr3);
				$pagination=$this->common_model->getPagination($arr4);
				
				$subcatpage_dataArr[]=$prodArr[0];
				$subcat_pagidArr[]=$prodArr[1];
				$data_totalArr[]=$pagination[0];
				$data_limitArr[]=$pagination[1];
				
				}
				}
				else {
					$arr3['where']="where cat_id=$id and deleted=0";
					$arr3['table']='products';
					$arr3['order_by']='';
					
					
					$arr4['where']="where cat_id=$id and deleted=0";
					$arr4['table']='products';
					$arr4['order_by']='';
					
					$prodArr=$this->common_model->getAllProducts($arr3);
					$pagination=$this->common_model->getPagination($arr4);
					
					$subcatpage_dataArr[]=$prodArr[0];
					$subcat_pagidArr[]=$prodArr[1];
					$data_totalArr[]=$pagination[0];
					$data_limitArr[]=$pagination[1];
				}
			//	print_r($subcatpage_dataArr[1]);
				//die;
				
				$data['page_data2']=$subcatpage_dataArr;
				$data['pagid2']=$subcat_pagidArr;
				$data['total2']=$data_totalArr;
				$data['limit2']=$data_limitArr;
				
				$arr['where']="where cat_id=$id and deleted=0";
				$arr['table']='products';
				$arr['order_by']='';
				
				
				$arr2['where']="where cat_id=$id and deleted=0";
				$arr2['table']='products';
				$arr2['order_by']='';
				
				$prodArr=$this->common_model->getAllProducts($arr);
				$pagination=$this->common_model->getPagination($arr2);
				$data['page_data']=$prodArr[0];
				$data['pagid']=$prodArr[1];
				$data['total']=$pagination[0];
				$data['limit']=$pagination[1];
				
				
				
				
				$arr6['table']='categories';
				$arr6['order_by']='order by cat_position';
				$data['page_data6']=$this->common_model->getAllDetails($arr6);
				}
				
				$this->load->view("header_view", $data);
				$this->load->view("product_view", $data);
				$this->load->view("footer_view");
			}
			function get_client_ip_server() {
				$ipaddress = '';
				if ($_SERVER['HTTP_CLIENT_IP'])
					$ipaddress = $_SERVER['HTTP_CLIENT_IP'];
				else if($_SERVER['HTTP_X_FORWARDED_FOR'])
					$ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
				else if($_SERVER['HTTP_X_FORWARDED'])
					$ipaddress = $_SERVER['HTTP_X_FORWARDED'];
				else if($_SERVER['HTTP_FORWARDED_FOR'])
					$ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
				else if($_SERVER['HTTP_FORWARDED'])
					$ipaddress = $_SERVER['HTTP_FORWARDED'];
				else if($_SERVER['REMOTE_ADDR'])
					$ipaddress = $_SERVER['REMOTE_ADDR'];
				else
					$ipaddress = 'UNKNOWN';
			
				return $ipaddress;
			}
			
			
}
?>