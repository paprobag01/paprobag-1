		<section class="main-content-wrap">
			<div class="container">
				<div class="col-md-12">
					<div class="row text-center" style="height:100px;margin-top:50px">
						<h4>Paper Bags</h4>
					</div>
				</div>
			</div>
			<div class="container">
				<div class="col-md-12" style="border-bottom:1px solid #eed">
						<div class="col-md-6" style="padding:10px">
									<div class="row" style="border-right:1px solid #eed; margin:10px;">
										<div class="col-xs-5">
											<div class="thumb-item-img">
												<a href="shop-product-detail-classic.html" class="btn-detail">
													<img class="img-responsive" src="images/products/product-1.jpg" alt="">
													<img class="img-responsive" src="images/products/product-1-over.jpg" alt="">
												</a>
											</div>
										</div>
										<div class="col-xs-7">
											<div class="thumb-item-content">
												<h3><a href="#">Silver Stainless Steel</a></h3>
												<ul class="list-review">
													<li>
														<p class="product-price"><ins>$280.00</ins></p>
													</li>
													
													<li class="btn-add-review"><a href="#">Add Your Review</a></li>
												</ul>
												
												<p>Nam ullamcorper neque non erat elementum vulputate. Nullam dignissim lobortis interdum. Donec nisi est, tempus eget. Nam ullamcorper neque non erat elementum vulputate. Nullam dignissim lobortis interdum.</p>
												<p class="thumb-act thumb-act-more">
													<!--  <a href="#" class="btn-customize"><i class="fa fa-shopping-cart"></i> <span>Add to Cart</span></a> -->
													
													<a href="#" class="full-detail"><span>View Full detail</span></a>
													<a href="#" class="btn-customize"><i class="fa fa-cogs"></i><span>Customize</span></a>
													
												</p>
											</div>
										</div>
									</div>
								</div>
								
								<div class="col-md-6">
									<div class="row">
										<div class="col-xs-5">
											<div class="thumb-item-img">
												<a href="shop-product-detail-classic.html" class="btn-detail">
													<img class="img-responsive" src="images/products/product-2.jpg" alt="">
													<img class="img-responsive" src="images/products/product-2-over.jpg" alt="">
												</a>
											</div>
										</div>
										<div class="col-xs-7">
											<div class="thumb-item-content">
												<h3><a href="#">Silver Stainless Steel</a></h3>
												<ul class="list-review">
													<li>
														<p class="product-price"><ins>$280.00</ins></p>
													</li>
													
													<li class="btn-add-review"><a href="#">Add Your Review</a></li>
												</ul>
												
												<p>Nam ullamcorper neque non erat elementum vulputate. Nullam dignissim lobortis interdum. Donec nisi est, tempus eget. Nam ullamcorper neque non erat elementum vulputate. Nullam dignissim lobortis interdum.</p>
												<p class="thumb-act thumb-act-more">
													<!--  <a href="#" class="btn-customize"><i class="fa fa-shopping-cart"></i> <span>Add to Cart</span></a> -->
													
													<a href="#" class="full-detail"><span>View Full detail</span></a>
													<a href="#" class="btn-customize"><i class="fa fa-cogs"></i><span>Customize</span></a>
													
												</p>
											</div>
										</div>
									</div>
								</div>
							</div>
							
							
							
							<div class="col-md-12">
							<div class="row" style="height:100px;">
							&nbsp;
							</div>
							</div>
							
							
							<div class="col-md-12" style="border-bottom:1px solid #eed">
						<div class="col-md-6" style="padding:10px">
									<div class="row" style="border-right:1px solid #eed; margin:10px;">
										<div class="col-xs-7">
											<div class="thumb-item-content">
												<h3><a href="#">Silver Stainless Steel</a></h3>
												<ul class="list-review">
													<li>
														<p class="product-price"><ins>$280.00</ins></p>
													</li>
													
													<li class="btn-add-review"><a href="#">Add Your Review</a></li>
												</ul>
												
												<p>Nam ullamcorper neque non erat elementum vulputate. Nullam dignissim lobortis interdum. Donec nisi est, tempus eget. Nam ullamcorper neque non erat elementum vulputate. Nullam dignissim lobortis interdum.</p>
												<p class="thumb-act thumb-act-more">
													<!--  <a href="#" class="btn-customize"><i class="fa fa-shopping-cart"></i> <span>Add to Cart</span></a> -->
													
													<a href="#" class="full-detail"><span>View Full detail</span></a>
													<a href="#" class="btn-customize"><i class="fa fa-cogs"></i><span>Customize</span></a>
													
												</p>
											</div>
										</div>
										<div class="col-xs-5">
											<div class="thumb-item-img">
												<a href="shop-product-detail-classic.html" class="btn-detail">
													<img class="img-responsive" src="images/products/product-1.jpg" alt="">
													<img class="img-responsive" src="images/products/product-1-over.jpg" alt="">
												</a>
											</div>
										</div>
										
									</div>
								</div>
								
								<div class="col-md-6">
									<div class="row">
									<div class="col-xs-7">
											<div class="thumb-item-content">
												<h3><a href="#">Silver Stainless Steel</a></h3>
												<ul class="list-review">
													<li>
														<p class="product-price"><ins>$280.00</ins></p>
													</li>
													
													<li class="btn-add-review"><a href="#">Add Your Review</a></li>
												</ul>
												
												<p>Nam ullamcorper neque non erat elementum vulputate. Nullam dignissim lobortis interdum. Donec nisi est, tempus eget. Nam ullamcorper neque non erat elementum vulputate. Nullam dignissim lobortis interdum.</p>
												<p class="thumb-act thumb-act-more">
													<!--  <a href="#" class="btn-customize"><i class="fa fa-shopping-cart"></i> <span>Add to Cart</span></a> -->
													
													<a href="#" class="full-detail"><span>View Full detail</span></a>
													<a href="#" class="btn-customize"><i class="fa fa-cogs"></i><span>Customize</span></a>
													
												</p>
											</div>
										</div>
										<div class="col-xs-5">
											<div class="thumb-item-img">
												<a href="shop-product-detail-classic.html" class="btn-detail">
													<img class="img-responsive" src="images/products/product-2.jpg" alt="">
													<img class="img-responsive" src="images/products/product-2-over.jpg" alt="">
												</a>
											</div>
										</div>
										
									</div>
								</div>
							</div>
							
							
							<div class="col-md-12">
							<div class="row" style="height:100px;">
							&nbsp;
							</div>
							</div>
							
							
							
							
							<div class="col-md-12" style="border-bottom:1px solid #eed"> 
						<div class="col-md-6" style="padding:10px">
									<div class="row" style="border-right:1px solid #eed; margin:10px;">
										<div class="col-xs-7">
											<div class="thumb-item-content">
												<h3><a href="#">Silver Stainless Steel</a></h3>
												<ul class="list-review">
													<li>
														<p class="product-price"><ins>$280.00</ins></p>
													</li>
													
													<li class="btn-add-review"><a href="#">Add Your Review</a></li>
												</ul>
												
												<p>Nam ullamcorper neque non erat elementum vulputate. Nullam dignissim lobortis interdum. Donec nisi est, tempus eget. Nam ullamcorper neque non erat elementum vulputate. Nullam dignissim lobortis interdum.</p>
												<p class="thumb-act thumb-act-more">
													<!--  <a href="#" class="btn-customize"><i class="fa fa-shopping-cart"></i> <span>Add to Cart</span></a> -->
													
													<a href="#" class="full-detail"><span>View Full detail</span></a>
													<a href="#" class="btn-customize"><i class="fa fa-cogs"></i><span>Customize</span></a>
													
												</p>
											</div>
										</div>
										<div class="col-xs-5">
											<div class="thumb-item-img">
												<a href="shop-product-detail-classic.html" class="btn-detail">
													<img class="img-responsive" src="images/products/product-1.jpg" alt="">
													<img class="img-responsive" src="images/products/product-1-over.jpg" alt="">
												</a>
											</div>
										</div>
										
									</div>
								</div>
								
								<div class="col-md-6">
									<div class="row">
									<div class="col-xs-7">
											<div class="thumb-item-content">
												<h3><a href="#">Silver Stainless Steel</a></h3>
												<ul class="list-review">
													<li>
														<p class="product-price"><ins>$280.00</ins></p>
													</li>
													
													<li class="btn-add-review"><a href="#">Add Your Review</a></li>
												</ul>
												
												<p>Nam ullamcorper neque non erat elementum vulputate. Nullam dignissim lobortis interdum. Donec nisi est, tempus eget. Nam ullamcorper neque non erat elementum vulputate. Nullam dignissim lobortis interdum.</p>
												<p class="thumb-act thumb-act-more">
													<!--  <a href="#" class="btn-customize"><i class="fa fa-shopping-cart"></i> <span>Add to Cart</span></a> -->
													
													<a href="#" class="full-detail"><span>View Full detail</span></a>
													<a href="#" class="btn-customize"><i class="fa fa-cogs"></i><span>Customize</span></a>
													
												</p>
											</div>
										</div>
										<div class="col-xs-5">
											<div class="thumb-item-img">
												<a href="shop-product-detail-classic.html" class="btn-detail">
													<img class="img-responsive" src="images/products/product-2.jpg" alt="">
													<img class="img-responsive" src="images/products/product-2-over.jpg" alt="">
												</a>
											</div>
										</div>
										
									</div>
								</div>
							</div>
							
							
							
							
							<div class="col-md-12">
							<div class="row" style="height:100px;">
							&nbsp;
							</div>
							</div>
							
							
							
							
							
							<div class="col-md-12" style="border-bottom:1px solid #eed">
						<div class="col-md-6" style="padding:10px">
									<div class="row" style="border-right:1px solid #eed; margin:10px;">
										<div class="col-xs-5">
											<div class="thumb-item-img">
												<a href="shop-product-detail-classic.html" class="btn-detail">
													<img class="img-responsive" src="images/products/product-1.jpg" alt="">
													<img class="img-responsive" src="images/products/product-1-over.jpg" alt="">
												</a>
											</div>
										</div>
										<div class="col-xs-7">
											<div class="thumb-item-content">
												<h3><a href="#">Silver Stainless Steel</a></h3>
												<ul class="list-review">
													<li>
														<p class="product-price"><ins>$280.00</ins></p>
													</li>
													
													<li class="btn-add-review"><a href="#">Add Your Review</a></li>
												</ul>
												
												<p>Nam ullamcorper neque non erat elementum vulputate. Nullam dignissim lobortis interdum. Donec nisi est, tempus eget. Nam ullamcorper neque non erat elementum vulputate. Nullam dignissim lobortis interdum.</p>
												<p class="thumb-act thumb-act-more">
													<!--  <a href="#" class="btn-customize"><i class="fa fa-shopping-cart"></i> <span>Add to Cart</span></a> -->
													
													<a href="#" class="full-detail"><span>View Full detail</span></a>
													<a href="#" class="btn-customize"><i class="fa fa-cogs"></i><span>Customize</span></a>
													
												</p>
											</div>
										</div>
									</div>
								</div>
								
								<div class="col-md-6">
									<div class="row">
										<div class="col-xs-5">
											<div class="thumb-item-img">
												<a href="shop-product-detail-classic.html" class="btn-detail">
													<img class="img-responsive" src="images/products/product-2.jpg" alt="">
													<img class="img-responsive" src="images/products/product-2-over.jpg" alt="">
												</a>
											</div>
										</div>
										<div class="col-xs-7">
											<div class="thumb-item-content">
												<h3><a href="#">Silver Stainless Steel</a></h3>
												<ul class="list-review">
													<li>
														<p class="product-price"><ins>$280.00</ins></p>
													</li>
													
													<li class="btn-add-review"><a href="#">Add Your Review</a></li>
												</ul>
												
												<p>Nam ullamcorper neque non erat elementum vulputate. Nullam dignissim lobortis interdum. Donec nisi est, tempus eget. Nam ullamcorper neque non erat elementum vulputate. Nullam dignissim lobortis interdum.</p>
												<p class="thumb-act thumb-act-more">
													<!--  <a href="#" class="btn-customize"><i class="fa fa-shopping-cart"></i> <span>Add to Cart</span></a> -->
													
													<a href="#" class="full-detail"><span>View Full detail</span></a>
													<a href="#" class="btn-customize"><i class="fa fa-cogs"></i><span>Customize</span></a>
													
												</p>
											</div>
										</div>
									</div>
								</div>
							</div>
							
						</section>