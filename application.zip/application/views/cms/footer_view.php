<!-- BEGIN FOOTER -->
   <div class="footer">
      2013 &copy;Softbunch.com
      <div class="span pull-right">
         <span class="go-top"><i class="icon-angle-up"></i></span>
      </div>
   </div>
   <!-- END FOOTER -->
   <!-- BEGIN JAVASCRIPTS -->    
   <!-- Load javascripts at bottom, this will reduce page load time -->
       
   <script type="text/javascript" src="<?php echo base_url()?>admin/ckeditor/ckeditor.js"></script>  
   <script src="<?php echo base_url()?>admin/breakpoints/breakpoints.js"></script>       
   <script src="<?php echo base_url()?>admin/bootstrap/js/bootstrap.min.js"></script>   
   <script type="text/javascript" src="<?php echo base_url()?>admin/bootstrap-fileupload/bootstrap-fileupload.js"></script>
   <script src="<?php echo base_url()?>admin/js/jquery.blockui.js"></script>
   <script src="<?php echo base_url()?>admin/js/jquery.cookie.js"></script>
   <!-- ie8 fixes -->
   <!--[if lt IE 9]>
   <script src="<?php echo base_url()?>admin/js/excanvas.js"></script>
   <script src="<?php echo base_url()?>admin/js/respond.js"></script>
   <![endif]-->
   <script type="text/javascript" src="<?php echo base_url()?>admin/chosen-bootstrap/chosen/chosen.jquery.min.js"></script>
   <script type="text/javascript" src="<?php echo base_url()?>admin/uniform/jquery.uniform.min.js"></script>
   <script type="text/javascript" src="<?php echo base_url()?>admin/bootstrap-wysihtml5/wysihtml5-0.3.0.js"></script> 
   <script type="text/javascript" src="<?php echo base_url()?>admin/bootstrap-wysihtml5/bootstrap-wysihtml5.js"></script>
   <script type="text/javascript" src="<?php echo base_url()?>admin/jquery-tags-input/jquery.tagsinput.min.js"></script>
   <script type="text/javascript" src="<?php echo base_url()?>admin/bootstrap-toggle-buttons/static/js/jquery.toggle.buttons.js"></script>
   <script type="text/javascript" src="<?php echo base_url()?>admin/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
   <script type="text/javascript" src="<?php echo base_url()?>admin/clockface/js/clockface.js"></script>
   <script type="text/javascript" src="<?php echo base_url()?>admin/bootstrap-daterangepicker/date.js"></script>
   <script type="text/javascript" src="<?php echo base_url()?>admin/bootstrap-daterangepicker/daterangepicker.js"></script> 
   <script type="text/javascript" src="<?php echo base_url()?>admin/bootstrap-colorpicker/js/bootstrap-colorpicker.js"></script>  
   <script type="text/javascript" src="<?php echo base_url()?>admin/bootstrap-timepicker/js/bootstrap-timepicker.js"></script>
   <script src="<?php echo base_url()?>admin/js/app.js"></script>   
   <script type="text/javascript" src="<?php echo base_url()?>admin/data-tables/jquery.dataTables.js"></script>
	<script type="text/javascript" src="<?php echo base_url()?>admin/data-tables/DT_bootstrap.js"></script>
 	<script>
		jQuery(document).ready(function() {			
			// initiate layout and plugins
			App.setPage("table_managed");
			App.init();
			  FormSamples.init();
		});
	</script> 

<!-- END JAVASCRIPTS -->
<script type="text/javascript">  var _gaq = _gaq || [];  _gaq.push(['_setAccount', 'UA-37564768-1']);  _gaq.push(['_setDomainName', 'keenthemes.com']);  _gaq.push(['_setAllowLinker', true]);  _gaq.push(['_trackPageview']);  (function() {    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;    ga.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'stats.g.doubleclick.net/dc.js';    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);  })();</script>
   <!-- END JAVASCRIPTS -->   
</body>
<!-- END BODY -->
</html>