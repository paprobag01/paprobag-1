<?php 
 class Custmizations extends CI_Controller{

		function __Construct(){
		
				parent::__construct();
               $this->load->model('customize_model');
			}
      
	  function index(){
		  $data['page']='customization';
		 $this->load->view('cms/header_view', $data);
		 $this->load->view('cms/Customization_Listing');
		 $this->load->view('cms/footer_view');
		
     }
	
}
?>