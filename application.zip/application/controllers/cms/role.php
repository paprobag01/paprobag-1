<?php
class role extends CI_Controller{
	
	function __Construct(){

		parent::__construct();
		$this->load->library('site_sentry');
		//$this->load->model('role_model');
	}

	function index(){

		$data['page']='role';
		
		$arr['table']='roles';
		$arr['where']="";
		$arr['and']="";
		$arr['order_by']="order by role_id desc";

		$data['page_data']=$this->site_sentry->get_all($arr);

		$this->load->view('cms/header_view',$data);
		$this->load->view('cms/role_view',$data);
		$this->load->view('cms/footer_view',$data);
	} 

	 
	function role_view(){

		$data['page']='role';
		
		$arr['table']='roles';
		$arr['where']="";
		$arr['and']="";
		$arr['order_by']="order by role_id desc";

		$data['page_data']=$this->site_sentry->get_all($arr);
		
		$this->load->view('cms/header_view',$data);
		$this->load->view('cms/role_view',$data);
		$this->load->view('cms/footer_view',$data);
	}

	function save_role(){ 
		 
		$data['table']="roles"; 
		$view=$this->input->post('view');
		$add=$this->input->post('add');
		$edit=$this->input->post('edit');
		$delete=$this->input->post('delete');
			
			if($view==""){
				$view="off";
			}
			if($add==""){
				$add="off";
			}
			if($edit==""){
				$edit="off";
			}
			if($delete==""){
				$delete="off";
			}

		$data['role_rights']=$view.",".$add.",".$edit.",".$delete;
		 
		$this->site_sentry->Save_records($data);
		redirect('role/role_view');
	}

	function add_role($role_id=null,$type=null){
		
		$data['primary_id']=$role_id;
		$data['table']="roles";
		$arr['page_data']=$this->site_sentry->PopulateValues($data);
		$arr['page']="role";
		$arr['type']=$type;
		$this->load->view('cms/header_view',$data);
		$this->load->view('cms/add_role',$data);
		$this->load->view('cms/footer_view',$data);

	}


	function delete_rec(){

		$this->role_model->delete_rec();
	}

}?>