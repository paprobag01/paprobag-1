<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
session_start();
    class Ajaxupload extends CI_Controller {
        public function __construct(){
            parent::__construct();
        }
        public function index(){
            $this->load->view('upload_view.php');
    }
        public function process_ajax(){
        	if(isset($_SESSION['imageUpload']))
        	{
        		unset($_SESSION['imageUpload']);
        	}
        	$html="";
            if(is_array($_FILES)) {
                if(is_uploaded_file($_FILES['userImage']['tmp_name'])) {
                    $sourcePath = $_FILES['userImage']['tmp_name'];
                    $targetPath = "upload/customimages/".$_FILES['userImage']['name'];
                if(move_uploaded_file($sourcePath,$targetPath)) {
    $html=$html.base_url().$targetPath;
   
    $_SESSION['imageUpload']=$html;
            }
        }
    }
    echo $html;
    }
 }
 ?>  