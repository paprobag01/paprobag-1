<?php 
class Index extends CI_Controller
{
	function __Construct(){
		
				parent::__construct();
                $this->load->model('common_model');
				
			}
	function index()
	{
		
		$arr['where']="where deleted=0";
		$arr['table']='products';
		$arr['order_by']='';
		$data['page_data']=$this->common_model->getAllDetails($arr);
		$arr1['where']="where ready_to_print!=0 and deleted=0";
		$arr1['table']='categories';
		$arr1['order_by']='order by cat_position, ready_to_print';
		$data['page_data1']=$this->common_model->getAllDetails($arr1);
		
		$arr2['where']="where customize_now=1 and deleted=0";
		$arr2['table']='categories';
		$arr2['order_by']='order by cat_position, customize_now';
		$data['page_data2']=$this->common_model->getAllDetails($arr2);
		$this->load->view('header_view', $data);
		 $this->load->view('index_view', $data);
		 $this->load->view('footer_view');
	}
}
?>