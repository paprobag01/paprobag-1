	<!--<div class="navbar-header" style="margin-left:5.5%">
					<nav class="nav-main pull-left" style="width:1200px;">
							<ul class="nav nav-pills nav-main-menu">
					
					<li style="width:80%;">
								
<img style="width:100%;height:39px" src="http://www.printvenue.com/static/hstrip-val-her">


					
								
								</li>
								<li style="width:19.5%;margin-left:5px;">
								<img style="width:100%;height:39px" src="http://www.printvenue.com/static/hstrip-val-her">
								</li>
					</ul>
					</nav>
					</div> -->
				<!-- </div> <div style="float:left;width:49%;margin-left:5px;"><a><img style="width:100%;height:50px" src="<?php echo base_url() ?>http://www.printvenue.com/static/hstrip-val-him"></a></div> -->
				
			

			<div role="main" class="main">
				<section class="main-content-wrap">
				
						<div class="container" style="">
						
						<!-- <div class="owl-carousel main-slides first-slides" data-plugin-options='{"items": 1, "autoPlay": false, "navigation": true}' style="width:83%;height:350px;float:left;">-->
						<div class="owl-carousel main-slides first-slides" data-plugin-options='{"items": 1, "autoPlay": false, "navigation": true}' style="border:1px solid #eed;10px">
							<div class="slide-item">
								<img class="img-responsive" style="width:900px;height:350px;" src="<?php echo base_url() ?>images/slides/slider_digDeep.jpg" alt="">
								<div class="slide-item-caption-wrap">
									<div class="slide-item-caption-cont">
										<div class="slide-item-caption-info">
											<p class="product-cat">Lookbook</p>
											<span class="divider bg-color1"></span>
											<h1>Fall/Winter<br>
											2014 new<br>
											collection</h1>
											<!-- <p class="btn-group"><a href="#" class="btn btn-default">Shop Now</a> <!-- <a href="#" class="btn btn-default">Shop Women's</a>  --></p>
										</div>
									</div>
								</div>
							</div>
							<div class="slide-item">
								<img class="img-responsive" style="width:900px;height:350px;" src="<?php echo base_url() ?>images/slides/slider_glastonbury.jpg" alt="">
								<div class="slide-item-caption-wrap">
									<div class="slide-item-caption-cont">
										<div class="slide-item-caption-info">
											<p class="product-cat">Winter Style</p>
											<span class="divider bg-color1"></span>
											<h1>All The Trends You Need This Season</h1>
											<!-- <p class="btn-group"><a href="#" class="btn btn-default">Shop Now</a> <!-- <a href="#" class="btn btn-default">Shop Women's</a>  --></p>
										</div>
									</div>
								</div>
							</div>
							<div class="slide-item">
								<img class="img-responsive" style="width:900px;height:350px;" src="<?php echo base_url() ?>images/slides/slider_maryTreacy.jpg" alt="">
								<div class="slide-item-caption-wrap">
									<div class="slide-item-caption-cont">
										<div class="slide-item-caption-info">
											<p class="product-cat">Lookbook</p>
											<span class="divider bg-color1"></span>
											<h1>20% Off New!<br>
											Limited Edition<br>
											collection</h1>
											<!-- <p class="btn-group"><a href="#" class="btn btn-default">Shop Now</a> <!-- <a href="#" class="btn btn-default">Shop Women's</a>  --></p>
										</div>
									</div>
								</div>
							</div>
						</div>
					
					</div>
					
					
					<!-- <div class="main-wrap">
					
					
					
					<div id="accordion" class="panel-group"> 
									
									<div>
									<div class="transparent" href="#collapseTwo" data-parent="#accordion" data-toggle="collapse" >
										
											<div class="text-center collapsed" style="float:left;width:70%;height:100%;position:absolute;border-right:1px solid #999;background: #feffff; /* Old browsers */
/* IE9 SVG, needs conditional override of 'filter' to 'none' */
background: url(data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiA/Pgo8c3ZnIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgdmlld0JveD0iMCAwIDEgMSIgcHJlc2VydmVBc3BlY3RSYXRpbz0ibm9uZSI+CiAgPGxpbmVhckdyYWRpZW50IGlkPSJncmFkLXVjZ2ctZ2VuZXJhdGVkIiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgeDE9IjAlIiB5MT0iMCUiIHgyPSIwJSIgeTI9IjEwMCUiPgogICAgPHN0b3Agb2Zmc2V0PSIwJSIgc3RvcC1jb2xvcj0iI2ZlZmZmZiIgc3RvcC1vcGFjaXR5PSIxIi8+CiAgICA8c3RvcCBvZmZzZXQ9IjM1JSIgc3RvcC1jb2xvcj0iI2RkZjFmOSIgc3RvcC1vcGFjaXR5PSIxIi8+CiAgICA8c3RvcCBvZmZzZXQ9IjEwMCUiIHN0b3AtY29sb3I9IiNhMGQ4ZWYiIHN0b3Atb3BhY2l0eT0iMSIvPgogIDwvbGluZWFyR3JhZGllbnQ+CiAgPHJlY3QgeD0iMCIgeT0iMCIgd2lkdGg9IjEiIGhlaWdodD0iMSIgZmlsbD0idXJsKCNncmFkLXVjZ2ctZ2VuZXJhdGVkKSIgLz4KPC9zdmc+);
background: -moz-linear-gradient(top,  #feffff 0%, #ddf1f9 35%, #a0d8ef 100%); /* FF3.6+ */
background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#feffff), color-stop(35%,#ddf1f9), color-stop(100%,#a0d8ef)); /* Chrome,Safari4+ */
background: -webkit-linear-gradient(top,  #feffff 0%,#ddf1f9 35%,#a0d8ef 100%); /* Chrome10+,Safari5.1+ */
background: -o-linear-gradient(top,  #feffff 0%,#ddf1f9 35%,#a0d8ef 100%); /* Opera 11.10+ */
background: -ms-linear-gradient(top,  #feffff 0%,#ddf1f9 35%,#a0d8ef 100%); /* IE10+ */
background: linear-gradient(to bottom,  #feffff 0%,#ddf1f9 35%,#a0d8ef 100%); /* W3C */
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#feffff', endColorstr='#a0d8ef',GradientType=0 ); /* IE6-8 */
" >
											<h4 class="text-center" style="margin-top: 30px;"> Now you can customize your </h4>
											<img src="<?php echo base_url() ?>images/icons/bags.png" style="margin:2px;width:20px;"/>
											<img src="<?php echo base_url() ?>images/icons/boxes.png" style="margin:2px;width:20px;"/>
											<img src="<?php echo base_url() ?>images/icons/pouch.png" style="margin:2px;width:20px;"/> 
											
											</div >
								
											<div class="collapsed text-center" style="float:right;width:31%;height:100%;position:relative;margin-top: -40px;margin-right: -20px;background: #fcfff4; /* Old browsers */
/* IE9 SVG, needs conditional override of 'filter' to 'none' */
background: url(data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiA/Pgo8c3ZnIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgdmlld0JveD0iMCAwIDEgMSIgcHJlc2VydmVBc3BlY3RSYXRpbz0ibm9uZSI+CiAgPGxpbmVhckdyYWRpZW50IGlkPSJncmFkLXVjZ2ctZ2VuZXJhdGVkIiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgeDE9IjAlIiB5MT0iMCUiIHgyPSIwJSIgeTI9IjEwMCUiPgogICAgPHN0b3Agb2Zmc2V0PSIwJSIgc3RvcC1jb2xvcj0iI2ZjZmZmNCIgc3RvcC1vcGFjaXR5PSIxIi8+CiAgICA8c3RvcCBvZmZzZXQ9IjQwJSIgc3RvcC1jb2xvcj0iI2RmZTVkNyIgc3RvcC1vcGFjaXR5PSIxIi8+CiAgICA8c3RvcCBvZmZzZXQ9IjEwMCUiIHN0b3AtY29sb3I9IiNiM2JlYWQiIHN0b3Atb3BhY2l0eT0iMSIvPgogIDwvbGluZWFyR3JhZGllbnQ+CiAgPHJlY3QgeD0iMCIgeT0iMCIgd2lkdGg9IjEiIGhlaWdodD0iMSIgZmlsbD0idXJsKCNncmFkLXVjZ2ctZ2VuZXJhdGVkKSIgLz4KPC9zdmc+);
background: -moz-linear-gradient(top,  #fcfff4 0%, #dfe5d7 40%, #b3bead 100%); /* FF3.6+ */
background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#fcfff4), color-stop(40%,#dfe5d7), color-stop(100%,#b3bead)); /* Chrome,Safari4+ */
background: -webkit-linear-gradient(top,  #fcfff4 0%,#dfe5d7 40%,#b3bead 100%); /* Chrome10+,Safari5.1+ */
background: -o-linear-gradient(top,  #fcfff4 0%,#dfe5d7 40%,#b3bead 100%); /* Opera 11.10+ */
background: -ms-linear-gradient(top,  #fcfff4 0%,#dfe5d7 40%,#b3bead 100%); /* IE10+ */
background: linear-gradient(to bottom,  #fcfff4 0%,#dfe5d7 40%,#b3bead 100%); /* W3C */
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#fcfff4', endColorstr='#b3bead',GradientType=0 ); /* IE6-8 */
" href="#collapseTwo" data-parent="#accordion" data-toggle="collapse">
											<h4  style="margin-top: 30px;"> Customize Now </h4>
											
											</div>											
											
											
										</div>
										<div class="panel-collapse collapse" id="collapseTwo">
											
												<div>
												<div class="post-block post-leave-comment">
																		
		<div class="container services" style="background: #e9f6fd; /* Old browsers */
/* IE9 SVG, needs conditional override of 'filter' to 'none' */
background: url(data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiA/Pgo8c3ZnIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgdmlld0JveD0iMCAwIDEgMSIgcHJlc2VydmVBc3BlY3RSYXRpbz0ibm9uZSI+CiAgPGxpbmVhckdyYWRpZW50IGlkPSJncmFkLXVjZ2ctZ2VuZXJhdGVkIiBncmFkaWVudFVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgeDE9IjAlIiB5MT0iMCUiIHgyPSIwJSIgeTI9IjEwMCUiPgogICAgPHN0b3Agb2Zmc2V0PSIwJSIgc3RvcC1jb2xvcj0iI2U5ZjZmZCIgc3RvcC1vcGFjaXR5PSIxIi8+CiAgICA8c3RvcCBvZmZzZXQ9IjEwMCUiIHN0b3AtY29sb3I9IiNkM2VlZmIiIHN0b3Atb3BhY2l0eT0iMSIvPgogIDwvbGluZWFyR3JhZGllbnQ+CiAgPHJlY3QgeD0iMCIgeT0iMCIgd2lkdGg9IjEiIGhlaWdodD0iMSIgZmlsbD0idXJsKCNncmFkLXVjZ2ctZ2VuZXJhdGVkKSIgLz4KPC9zdmc+);
background: -moz-linear-gradient(top,  #e9f6fd 0%, #d3eefb 100%); /* FF3.6+ */
background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#e9f6fd), color-stop(100%,#d3eefb)); /* Chrome,Safari4+ */
background: -webkit-linear-gradient(top,  #e9f6fd 0%,#d3eefb 100%); /* Chrome10+,Safari5.1+ */
background: -o-linear-gradient(top,  #e9f6fd 0%,#d3eefb 100%); /* Opera 11.10+ */
background: -ms-linear-gradient(top,  #e9f6fd 0%,#d3eefb 100%); /* IE10+ */
background: linear-gradient(to bottom,  #e9f6fd 0%,#d3eefb 100%); /* W3C */
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#e9f6fd', endColorstr='#d3eefb',GradientType=0 ); /* IE6-8 */
">
		<div class="col-md-31 service-content">
			<div class="icon-surround-1"><span>1</span><i class="icon-search3"></i></div>
			<h4>Choose a Product</h4>
			
		</div>
		<div class="col-md-31 service-content">
			<div class="icon-surround-1"><span>2</span><i class="icon-hammer"></i></div>
			<h4>Customize</h4>
			
		</div>
		<div class="col-md-31 service-content">
			<div class="icon-surround-1"><span>3</span><i class="icon-upload"></i></div>
			<h4>Upload Your Art-Work</h4>
			
		</div>
		<div class="col-md-31 service-content">
			<div class="icon-surround-1"><span>4</span><i class="icon-users"></i></div>
			<h4>Place Order</h4>
			
		</div>
		<div class="col-md-31 service-content" >
			<div class="icon-surround-1" style="background: url('./images/media_playback_start.png');background-size: 100px 100px;"></div>
			<h4>Start Now</h4>
			
		</div>
	</div> 	
												</div>
											</div>
										</div>
									</div>
							 </div> 
					
					
					
					
					
					

</div> -->
					</section> 
							
							 <section  style="margin-top:-55px">
							<div class="container" style="margin-top:110px;">
								<h2  class="transparent1 text-center" >  --- Customize Now !--- </h2>
								<?php foreach($page_data2 as $row){?>
								<?php if($row['cat_position']<3){?>
								<div class="col-md-6 text-center">
									<a href="<?php echo base_url() ?>products/getProducts/<?php echo $row['cat_id']?>/custm"><img style="width:99%;height:395px;" class="lazy-load" data-src="<?php echo base_url().$row['image_url'] ?>" src="<?php echo base_url().$row['image_url'] ?>"></a>
									<h3><a href="#"><?php if($row['cat_position']==1){ echo $row['category_name']; } else if($row['cat_position']==2){ echo $row['category_name'];}?></a></h3>
								</div>
								<?php } ?>
								<?php }?>
								
							
								</div>
								<div class="container home-mission text-center">
								<?php foreach($page_data2 as $row){
									if($row['cat_position']>2)
									{
								?>
								<div class="col-md-4">
								<a href="<?php echo base_url() ?>products/getProducts/<?php echo $row['cat_id']?>/custm"><img style="width:99%;height:395px;" class="lazy-load" data-src="<?php echo base_url().$row['image_url'] ?>" src="<?php echo base_url().$row['image_url'] ?>"></a>
								<h3><a href="#"><?php if($row['cat_position']==3){ echo $row['category_name'];} else if($row['cat_position']==4){ echo $row['category_name'];} else if($row['cat_position']==5){ echo $row['category_name'];} ?></a></h3>
								</div>
								<?php } }?>
								
								
								</div>
							</section> 
							
						<!-- <div class="container">
							<div class="row row-fluid" style="border:1px solid #000">
								<div class="col-xs-6">
									<div class="row row-fluid cat-thumb-item">
										<div class="col-xs-6 col-xs-offset-6 cat-thumb-item-img">
											<div class="thumb-item" style="height:300px;">
												<div class="thumb-item-img">
													<a href="shop-product-detail-classic.html" class="btn-detail">
														<img class="img-responsive" src="<?php echo base_url() ?>images/products/bag5.jpg" alt="">
														<img class="img-responsive" src="<?php echo base_url() ?>images/products/bag5.jpg" alt="">
													</a>
													
												</div>
												
											</div>
										</div>
										<div class="col-xs-6 cat-thumb-item-content-wrap bg-color1">
											<div class="cat-thumb-item-content">
												<div class="cat-thumb-item-content-inner">
													<!-- <p class="product-cat">Online Sale</p> -->
													<!-- <h3><a href="#">BAGS</a></h3>
													<p><a href="#">Shop now</a></p>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="col-xs-6">
									<div class="row row-fluid cat-thumb-item">
										<div class="col-xs-6 col-xs-offset-6 cat-thumb-item-content-wrap">
											<div class="cat-thumb-item-content">
												<div class="cat-thumb-item-content-inner">
													<p class="product-cat"></p>
													<h3><a href="#">BOXES</a></h3>
													<p><a href="#">See the collection</a></p>
												</div>
											</div>
										</div>
										<div class="col-xs-6 cat-thumb-item-img">
										<div class="thumb-item" style="height:300px;">
												<div class="thumb-item-img">
													<a href="shop-product-detail-classic.html" class="btn-detail">
														<img class="img-responsive" src="<?php echo base_url() ?>images/products/bag3.jpg" alt="">
														<img class="img-responsive" src="<?php echo base_url() ?>images/products/bag3.jpg" alt="">
													</a>
													
												</div>
												
											</div>
										
										
											<!-- <img class="img-responsive" src="<?php echo base_url() ?>images/products/bag3.jpg" alt=""> -->
										<!-- </div>
									</div>
								</div>
								<div class="col-xs-6">
									<div class="row row-fluid cat-thumb-item">
										<div class="col-xs-6 col-xs-offset-6 cat-thumb-item-img">
											<div class="thumb-item" style="height:300px;">
												<div class="thumb-item-img">
													<a href="shop-product-detail-classic.html" class="btn-detail">
														<img class="img-responsive" src="<?php echo base_url() ?>images/products/bag7.jpg" alt="">
														<img class="img-responsive" src="<?php echo base_url() ?>images/products/bag7.jpg" alt="">
													</a>
													
												</div>
												
											</div>
										</div>
										<div class="col-xs-6 cat-thumb-item-content-wrap bg-color1">
											<div class="cat-thumb-item-content">
												<div class="cat-thumb-item-content-inner">
													<p class="product-cat">Online Sale</p>
													<h3><a href="#">Pouches</a></h3>
													<p><a href="#">Shop now</a></p>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="col-xs-6">
									<div class="row row-fluid cat-thumb-item">
										<div class="col-xs-6 col-xs-offset-6 cat-thumb-item-content-wrap">
											<div class="cat-thumb-item-content">
												<div class="cat-thumb-item-content-inner">
													<p class="product-cat"></p>
													<h3><a href="#">Office Stuff</a></h3>
													<p><a href="#">See the collection</a></p>
												</div>
											</div>
										</div>
										<div class="col-xs-6 cat-thumb-item-img">
											<div class="thumb-item" style="height:300px;">
												<div class="thumb-item-img">
													<a href="shop-product-detail-classic.html" class="btn-detail">
														<img class="img-responsive" src="<?php echo base_url() ?>images/products/bag13.jpg" alt="">
														<img class="img-responsive" src="<?php echo base_url() ?>images/products/bag13.jpg" alt="">
													</a>
													
												</div>
												
											</div>
										</div>
									</div>
								</div>
							
								<!-- <div class="col-xs-6">
									<div class="row row-fluid cat-thumb-item">
										<div class="col-xs-6 col-xs-offset-6 cat-thumb-item-img">
											<div class="thumb-item" style="height:300px;">
												<div class="thumb-item-img">
													<a href="shop-product-detail-classic.html" class="btn-detail">
														<img class="img-responsive" src="<?php echo base_url() ?>images/products/bag4.jpg" alt="">
														<img class="img-responsive" src="<?php echo base_url() ?>images/products/bag4.jpg" alt="">
													</a>
													
												</div>
												
											</div>
										</div>
										<div class="col-xs-6 cat-thumb-item-content-wrap bg-color1">
											<div class="cat-thumb-item-content">
												<div class="cat-thumb-item-content-inner">
													<p class="product-cat">Online Sale</p>
													<h3><a href="#">Nonwoven Bags</a></h3>
													<p><a href="#">Shop now</a></p>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="col-xs-6">
									<div class="row row-fluid cat-thumb-item">
										<div class="col-xs-6 col-xs-offset-6 cat-thumb-item-content-wrap">
											<div class="cat-thumb-item-content">
												<div class="cat-thumb-item-content-inner">
													<p class="product-cat"></p>
													<h3><a href="#">Woven Bags</a></h3>
													<p><a href="#">See the collection</a></p>
												</div>
											</div>
										</div>
										<div class="col-xs-6 cat-thumb-item-img">
										<div class="thumb-item" style="height:300px;">
												<div class="thumb-item-img">
													<a href="shop-product-detail-classic.html" class="btn-detail">
														<img class="img-responsive" src="<?php echo base_url() ?>images/products/bag27.jpg" alt="">
														<img class="img-responsive" src="<?php echo base_url() ?>images/products/bag27.jpg" alt="">
													</a>
													
												</div>
												
											</div>
										
										
											
										</div>
									</div>
								</div>
								<div class="col-xs-6">
									<div class="row row-fluid cat-thumb-item">
										<div class="col-xs-6 col-xs-offset-6 cat-thumb-item-img">
											<div class="thumb-item" style="height:300px;">
												<div class="thumb-item-img">
													<a href="shop-product-detail-classic.html" class="btn-detail">
														<img class="img-responsive" src="<?php echo base_url() ?>images/products/bag28.jpg" alt="">
														<img class="img-responsive" src="<?php echo base_url() ?>images/products/bag28.jpg" alt="">
													</a>
													
												</div>
												
											</div>
										</div>
										<div class="col-xs-6 cat-thumb-item-content-wrap bg-color1">
											<div class="cat-thumb-item-content">
												<div class="cat-thumb-item-content-inner">
													<p class="product-cat">Online Sale</p>
													<h3><a href="#">Cotton Bags</a></h3>
													<p><a href="#">Shop now</a></p>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="col-xs-6">
									<div class="row row-fluid cat-thumb-item">
										<div class="col-xs-6 col-xs-offset-6 cat-thumb-item-content-wrap">
											<div class="cat-thumb-item-content">
												<div class="cat-thumb-item-content-inner">
													<p class="product-cat"></p>
													<h3><a href="#">Bamboo Bags</a></h3>
													<p><a href="#">See the collection</a></p>
												</div>
											</div>
										</div>
										<div class="col-xs-6 cat-thumb-item-img">
											<div class="thumb-item" style="height:300px;">
												<div class="thumb-item-img">
													<a href="shop-product-detail-classic.html" class="btn-detail">
														<img class="img-responsive" src="<?php echo base_url() ?>images/products/bag29.jpg" alt="">
														<img class="img-responsive" src="<?php echo base_url() ?>images/products/bag29.jpg" alt="">
													</a>
													
												</div>
												
											</div>
										</div>
									</div>
								</div>-->
							<!-- </div>
						</div> -->
					</section>
							
							
							<section class="latest highlight-slide">
							
					<div class="container bg-img-1" style="margin-top:5px;">
						
							
							<h2 class="transparent1 text-center"> --- Ready to Print --- </h2>
						
		<div class="home-mission home-blog">
			<div class="row">
				<div class="owl-carousel multi-slides multi-slides-right" data-plugin-options='{"items": 4, "singleItem": false, "pagination": false, "navigation": true}'>
					<?php foreach($page_data1 as $row){ ?>
					<div class="col-md-12">
						<div class="thumb-item">
							<div class="thumb-item-img">
							<a href="<?php echo base_url() ?>products/getProducts/<?php echo $row['cat_id']?>/printready"><img src="<?php echo base_url().$row['image_url'] ?>" class="img-responsive" alt="img"/></a>
							</div>
							<a href="<?php echo base_url() ?>products/getProducts/<?php echo $row['cat_id']?>/printready">
								<h4><?php echo $row['category_name']?></h4>
							</a>
						</div>
					</div>
					<?php 
					}
					?>
				</div>
			</div>
					</div>
				</section>
							
							
							
					
					
							<section class="banner">
							<div class="container text-center">
							<h2  class="transparent1 text-center">--- Ready to Deliver ---</h2>
							</div>
							</section>
							
							
					
					
				
					<section>
						<div class="container">
							
							
							

							<!-- Tab panes -->
							
							<div class="tab-content col-md-9" style="">
							<ul class="nav1 nav-tabs1 grid-tabs text-center" role="tablist" style="margin-left:300px;margin-bottom:40px;">
								<li style="width:149px" ><a id="retail1" href="#tshirt" role="tab"  data-toggle="tab">Retail</a></li>
								<li style="width:150px"  class="active"><a id="outerwear1" href="#outerwaer" role="tab" style="width:149px;border-top:2px solid #DD4E4E; border-left:1px solid #000;border-right:1px solid #000;border-bottom-color:transparent;" data-toggle="tab">Offers</a></li>
								<li style="width:149px" ><a id="suits1" href="#suits" role="tab"  data-toggle="tab">Wholesale</a></li>
								
							</ul>
							<script>
							$(document).ready(function() {

    $("#retail1").click(function(){

       $("#outerwear1").css("border-top-color","#000");
    });
$("#suits1").click(function(){

       $("#outerwear1").css("border-top-color","#000");
    });
$("#outerwear1").click(function(){

       $("#outerwear1").css("border-top-color","#dd4e4e");
    });
  
});
							</script>
							
								<div class="tab-pane" id="tshirt">
								
									<div class="row" style="margin-left:0px;margin-right:-300px;">
									
										
										<?php 
									foreach($page_data as $row)
									{
										if($row['ready_to_deliver_tabs']==1)
										{
									?>
										<div class="col-xs-6 col-sm-3">
											<div class="thumb-item">
												<div class="thumb-item-img">
													<a href="<?php echo base_url()?>productDetails/getDetails/<?php echo $row['prod_id'] ?>" class="btn-detail">
														<img class="img-responsive" src="<?php echo base_url().$row['prod_image'] ?>" alt="" style="
    
    background-color: rgba(0,0,0,.5);">
														<img class="img-responsive" src="<?php echo base_url().$row['prod_image'] ?>" alt="">
													</a>
													<span class="thumb-act thumb-act-first">
														<a href="#" class="btn-cart"><i class="fa fa-shopping-cart"></i></a>
														<!-- <a data-target="#quickview-detail" data-toggle="modal" href="javascript:void(0);"><i class="fa fa-eye"></i></a>
														<a href="#"><i class="fa fa-heart-o"></i></a>
														<a href="#"><i class="fa fa-exchange"></i></a>  -->
													</span>
												</div>
												<div class="thumb-item-content">
													<div class="star-rating pull-right" title="Rated 5.00 out of 5">
														<span style="width:100%"><strong class="rating">5.00</strong> out of 5</span>
													</div> 
													<h3><a href="#"><?php echo $row['prod_name']?></a></h3>
													
													 <p class="product-cat"><a href="#">Bags</a>, <a href="#">Accessories</a></p>
													<p class="product-price"><ins>Rs.<?php echo $row['prod_price']?></ins></p>
												</div>
											</div>
										</div>
									<?php 
										}
									}
									?>
									<div class="container home-mission">
										<p class="thumb-act thumb-act-more text-center">
											<a href="<?php echo base_url()?>products/getProducts/readyToDeliver/1" class="btn-cart"><span>See More</span></a>	
										</p>
									</div>	
									</div>
									
									
								</div>
								
								<div class="tab-pane active" id="outerwaer">
							<div class="row" style="margin-left:0px;margin-right:-300px;">
									<?php 
									foreach($page_data as $row)
									{
										if($row['ready_to_deliver_tabs']==2)
										{
									?>
										<div class="col-xs-6 col-sm-3">
											<div class="thumb-item">
												<div class="thumb-item-img">
													<a href="<?php echo base_url()?>productDetails/getDetails/<?php echo $row['prod_id'] ?>" class="btn-detail">
														<img class="img-responsive" src="<?php echo base_url().$row['prod_image'] ?>" alt="">
														<img class="img-responsive" src="<?php echo base_url().$row['prod_image'] ?>" alt="">
													</a>
													<span class="thumb-act thumb-act-first">
														<a href="#" class="btn-cart"><i class="fa fa-shopping-cart"></i></a>
														<!-- <a data-target="#quickview-detail" data-toggle="modal" href="javascript:void(0);"><i class="fa fa-eye"></i></a>
														<a href="#"><i class="fa fa-heart-o"></i></a>
														<a href="#"><i class="fa fa-exchange"></i></a> -->
													</span>
												</div>
												<div class="thumb-item-content">
													<div class="star-rating pull-right" title="Rated 5.00 out of 5">
														<span style="width:100%"><strong class="rating">5.00</strong> out of 5</span>
													</div> 
													<h3><a href="#"><?php echo $row['prod_name']?></a></h3>
													
													 <p class="product-cat"><a href="#">Bags</a>, <a href="#">Accessories</a></p>
													<p class="product-price"><ins>Rs.<?php echo $row['prod_price']?></ins></p>
												</div>
											</div>
										</div>
									<?php 
										}
									}
									?>
									<div class="container home-mission">
							<p class="thumb-act thumb-act-more text-center">
								<a href="<?php echo base_url()?>products/getProducts/readyToDeliver/2" class="btn-cart"><span>See More</span></a>	
							</p>
						</div>
								</div>
								</div>
								<div class="tab-pane" id="suits">
							<div class="row" style="margin-left:0px;margin-right:-300px;">
									<?php 
									foreach($page_data as $row)
									{
										if($row['ready_to_deliver_tabs']==3)
										{
									?>
										<div class="col-xs-6 col-sm-3">
											<div class="thumb-item">
												<div class="thumb-item-img">
													<a href="<?php echo base_url()?>productDetails/getDetails/<?php echo $row['prod_id'] ?>" class="btn-detail">
														<img class="img-responsive" src="<?php echo base_url().$row['prod_image'] ?>" alt="">
														<img class="img-responsive" src="<?php echo base_url().$row['prod_image'] ?>" alt="">
													</a>
													<span class="thumb-act thumb-act-first">
														<a href="#" class="btn-cart"><i class="fa fa-shopping-cart"></i></a>
														<!-- <a data-target="#quickview-detail" data-toggle="modal" href="javascript:void(0);"><i class="fa fa-eye"></i></a>
														<a href="#"><i class="fa fa-heart-o"></i></a>
														<a href="#"><i class="fa fa-exchange"></i></a>  -->
													</span>
												</div>
												<div class="thumb-item-content">
													<div class="star-rating pull-right" title="Rated 5.00 out of 5">
														<span style="width:100%"><strong class="rating">5.00</strong> out of 5</span>
													</div> 
													<h3><a href="#"><?php echo $row['prod_name']?></a></h3>
													 
													 <p class="product-cat"><a href="#">Bags</a>, <a href="#">Accessories</a></p>
													<p class="product-price"><ins>Rs.<?php echo $row['prod_price']?></ins></p>
												</div>
											</div>
										</div>
									<?php 
										}
									}
									?>
									<div class="container home-mission">
									<p class="thumb-act thumb-act-more text-center">
										<a href="<?php echo base_url()?>products/getProducts/readyToDeliver/3" class="btn-cart"><span>See More</span></a>	
									</p>
								</div>
								</div>
								</div>
								
							</div>
							
						</div>
						
					</section>
					
					
					
					<section class="highlight-thumbs">
					
							
						
						<div class="container">
						<div id="footer1"  style="margin-left:10px;margin-right:10px;background:whitesmoke;padding:20px;color:#555;">
						<p class="text-center">Paprobag.com give you the best customize experience of online ecological promotional products.
						</p>
					<div class="row">
						<div class="col-md-4">
						<ul>
							<li class="text-center">We stand with</li>
							<li class="text-center">Quality </li>
							<li class="text-center">Price</li>
							<li class="text-center">Service</li>
						</ul>
						</div>
						<div class="col-md-4">
							<ul>
							<li>&nbsp;</li>
							<li><input type="text" class="form-control" placeholder="Email Id"/></li>
							<li><input type="submit" class="btn btn-cart" value="Join The Mailing List" style="width:100%;font-size:16px;"/></li>
							</ul>
						</div>
						<div class="col-md-4">
						<ul>
						
							<li class="text-center">--Absolutely--</li>
							<li class="text-center"><img src="<?php echo base_url()?>images/ecofriendly.jpg" width="100"/></li>
							<li class="text-center">--Products--</li>
							<li>&nbsp;</li>
						</ul>
						</div>
				
					</div>
				</div>				
						</div>
						<div class="container home-mission">
						
						<div class="col-md-4" style="border-bottom:1px solid #eed;border-right:1px solid #eed;">
						<h2 class="transparent1">Brands</h2>
						</div>
						<div class="col-md-4" style="border-top: 1px solid #eed;border-right:1px solid #eed;">
						<h2 class="transparent1 text-center">Social</h2>
						</div>
						<div class="col-md-4" style="border-bottom:1px solid #eed;">
						<h2 class="transparent1 text-right">Client Board</h2>
						</div>
						</div>
					</section>
						<section class="latest-posts highlight-latest-post">
					<div class="container">
							<article style="margin-bottom:-20px;">
								<div class="row row-fluid">
									
									<div>
										
										<div>
											<p class="text-center">Paprobag.com - Online ecological promotional product store</p>
											<p class="text-justify" style="margin-top:0px;color: #000;">
											Paprobag An ecological promotional product store where you can check, customize and order promotional shopping carry bags, paperbags, Handmade paperbags,
											Gift bags, News Paper Bags, Grossery bags, Food parcel bags, Medical Bags & Eco bags, Non Woven Bags, Woven Bags, Jute Bags, Cotton Bags, Canvas bags, Khadi Bags, Bamboo bags & Boxes, Mailing boxes, packaging and courier boxes, food boxes, sweet boxes, chocolate boxes, corporate gift boxes, FMCG product boxes & Pouches, Non Woven Pouches, woven pouches, jute pouches, cotton pouches, canvas pouches, mix pouches & Office products envelopes, mailing boxes, corporate gift boxes, Handmade Dairies, Stickers, Pamphlets, Mascot with your brand Name. 
											Through our customize, ready to print and ready to deliver.
											
											<br />
											<p class="text-center">We deliver all the corner of India</p>
												<p class="thumb-act thumb-act-more text-center">
													<a href="#" class="btn-cart"><span>How It Works</span></a>
													
												</p>
											</p>
										</div>
										
									</div>
									
								</div>	
							</article>
						</div>
					</section>	
			