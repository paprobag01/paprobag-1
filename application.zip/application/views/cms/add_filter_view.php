<?php 
extract($page_data);
extract($page_data1);//page_data1
?>
<!-- BEGIN PAGE -->  
      <div class="page-content"> 
         <!-- BEGIN PAGE CONTAINER-->
         <div class="container-fluid">
            <!-- BEGIN PAGE HEADER-->   
            <div class="row-fluid">
               <div class="span12"> 
                  <h3 class="page-title">
                     Create Filters
                  </h3> 
				  <!-- <p style="text-align:right"><button type="button" id="add_new" class="btn blue">View Subcategory Details</button></p> -->	
               </div>
            </div>
            <!-- END PAGE HEADER-->
            <!-- BEGIN PAGE CONTENT-->
            <div class="row-fluid">
               <div class="span12">
                  <!-- BEGIN SAMPLE FORM PORTLET-->   
				 
                  <div class="portlet box blue">
                     <div class="portlet-title">
                        <h4><i class="icon-reorder"></i>Add Filter details</h4>
                        <div class="tools">
                           <a href="javascript:;" class="collapse"></a> 
                           <a href="javascript:;" class="remove"></a>
                        </div>
                     </div>
                     <div class="portlet-body form">
                        <!-- BEGIN FORM-->

                        <form action="<?php echo base_url()?>cms/filters/save_filters" class="form-horizontal" method="post" enctype="multipart/form-data" />
							<input type="hidden" name="filter_id" value="<?php echo $filter_id;?>"/>
							<input type="hidden" name="created_on" value="<?php echo date('d-m-Y')?>"/>
						   <!-- <div class="control-group">
                              <label class="control-label">Image :</label>
                              <div class="controls">
                                <div class="fileupload fileupload-new" data-provides="fileupload">
                                    <div class="fileupload-new thumbnail" style="width: 200px; height: 150px;">
                                       <?php if($air_image!=""){?>
										<img src="<?php echo base_url().$air_image;?>" /> 
										<?php } else {?>
									   <img src="<?php echo base_url()?>assets/img/noimage.gif" alt="" />
									   <?php }?>
									   <input type="hidden" value="<?php echo $air_image; ?>" name="img_url">	
                                    </div>
                                    <div class="fileupload-preview fileupload-exists thumbnail" style="max-width: 200px; max-height: 150px; line-height: 20px;"></div>
                                    <div>
                                       <span class="btn btn-file"><span class="fileupload-new">Select image</span>
                                       <span class="fileupload-exists">Change</span>
                                       <input type="file" name="fileinput" <?php if($type=='view'){?>disabled<?php }?> class="default" /></span>
                                       <a href="#" class="btn fileupload-exists" data-dismiss="fileupload">Remove</a>
                                    </div>
									
                                 </div> 
                              </div>
                           </div> 
						    <!-- <div class="control-group">
                              <label class="control-label">Date</label>
                              <div class="controls">
                                 <input type="text" <?php if($type=='view'){?>disabled<?php }?>  name="paper_date" id="paper_date" class="span4  m-wrap" value="<?php 
								 if($paper_date!='')
								 {
									echo date("d/m/Y",strtotime($paper_date)); 
								}?>" /> 
                              </div>
                           </div>-->	 
						    
						   <div class="control-group">
                              <label class="control-label">Create New Filter</label>
                              <div class="controls">
                                <!-- <textarea  name="details"  id="ai" class="span12 ckeditor m-wrap" cols="30" rows="10">  </textarea> -->
									
								  <input type="text" <?php if($type=='view'){?>disabled<?php }?> name="filter_name" id="filter_name" value="<?php echo $filter_name?>" class="span4  m-wrap" /> 
                              </div>
                           </div>
						    <div class="control-group">
                              <label class="control-label">Filter Value</label>
                              <div class="controls">
                                <!-- <textarea  name="details"  id="ai" class="span12 ckeditor m-wrap" cols="30" rows="10">  </textarea> -->
									
								  <p id="inputEl" style="margin-bottom:5px;"><input type="text" <?php if($type=='view'){?>disabled<?php }?> name="filter_values[]" id="filter_values" value="<?php echo $filter_values?>" class="span4  m-wrap" /><button type="button" id="add_new" class="btn blue">+</button> <button onclick="RemInput()" type="button" class="btn blue" style="display:none" id="remScnt">-</button></p>
								  <script type="text/javascript">
						    $(document).ready(function() {
								var rembtn = $('#remScnt');//
						   var inputel = $('#inputEl');
									var i = $('#inputEl').size() + 1;
									
									$('#add_new').on('click', function() {
										rembtn.fadeIn();
											$('<p id="inputEl'+i+'"><input type="text" id="filter_values" <?php if($type=='view'){?>disabled<?php }?> size="20" name="filter_values[]" class="span4  m-wrap" value="<?php echo $filter_values?>" placeholder="Input Value" /></p>').appendTo(inputel);
											
											return false;
									});
									
									
							});
							
							
							function RemInput(){ 
							var i = $('#inputEl'+i+'').size() + 1;
							
									i++;
											if( i >= 2 ) {
												
													$('#inputEl'+i+'').remove();
													i--;
											}
											return false;
									};
						   </script>
                              </div>
                           </div>
						   
						   <div class="control-group">
                              <label class="control-label">Select Categories</label>
							  <div class="control-group" style="border:1px solid #4b8df8;margin-left:180px;margin-bottom:-80px;">
							  <?php 
							  $cnt=0;
							  foreach($page_data1 as $rw) 
							  {
							  ?>
                              <span class="control-label"><?php echo $rw['category_name']?><input type="checkbox" name="cat_ids[]" value="<?php echo $rw['cat_id'];?>" id="category<?php echo $cnt;?>"/></span>
							  <script type="text/javascript">
							  $(document).ready(function() {
								  var img = $('#subcategories<?php echo $cnt;?>');//subcatdiv
									var img1 = $('#subcatdiv0');//
								  $('#category<?php echo $cnt;?>').on('click', function() {
									  	  if($('#category<?php echo $cnt;?>').attr('checked')) {
											  img.fadeIn();
											  img1.fadeIn();
											  var categories = $('#category<?php echo $cnt;?>').val();
									console.log(categories);
									$.ajax({   
									   url: "<?php echo base_url()?>cms/getSubCategories",
										async: false,
										type: "POST", 
										data: "categories="+categories,
										dataType: "html",
										
										success: function(data) {
											
											if(data=="")
											{
												$('#subcategories<?php echo $cnt;?>').html();
											
											}
											else{
												$('#subcategories<?php echo $cnt;?>').html(data);
											}
										}
									})
								  }
								  else
								  {
									 img.fadeOut(); 
									 
								  }
									 
								  });
								});
									
								
								
								/*  $('#category<?php echo $cnt;?>').on('click', function() {
										img.fadeOut();
								  });
								  
								  $('#toggle').on('click', function() {
									img.fadeToggle();  
								  }); */
							  </script>
							  <?php 
							   $cnt++;
							  }
							  $cnt1=0;
							  ?>
							  <div style="background:#4b8df8;width:100%;margin-top:35px;" >
							  <?php
							   foreach($page_data1 as $rw) 
							  {
								  if($cnt1==0)
								  {
							  ?>
							  <label class="control-label" style="display:none" id="subcatdiv0">Subcategories</label>
							  <?php 
								  }
							  ?>
							   <span id="subcategories<?php echo $cnt1;?>" style="display:none;">
							
						  
								</span>
							  <?php
							  $cnt1++;
							  }
							  ?>
							  </div>
							  </div>
							  
                           </div>
						   
						  <?php if($type!='view'){ ?>
                           <div class="form-actions">
                           <button type="submit" class="btn blue">Save</button>
                              <button type="button" class="cancel btn">Cancel</button>
                           </div>
						   <?php }?>
                        </form>
                        <!-- END FORM-->           
                     </div>
                  </div>
                  <!-- END SAMPLE FORM PORTLET-->
               </div>
            </div>
			<script type="text/javascript">
			/* $(document).ready(function(){
				 $("#add_new").click(function(){

				document.location="<?php echo base_url()?>cms/subcategories";
				
			}); */
			
				$(".cancel").click(function()
					{

					document.location="<?php echo base_url()?>cms/home_page/home_page_view";
				});             

				
		  });	
		  </script>	
			</div>
            </div>
			</div>