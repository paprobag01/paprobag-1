<?php
class Packages extends CI_Controller{
	
	function __Construct(){

		parent::__construct();
		if(!$this->session->userdata('user_id')){
				   redirect("cms/login");
				}
		$this->load->library('site_sentry');
		//$this->load->model('users_model');
	}

	function index(){

		$data['page']='packages';
		
		$arr['table']='packages';
		$arr['where']="";
		$arr['and']="";
		$arr['order_by']="order by pack_id desc";
		
		$data['page_data']=$this->site_sentry->get_all($arr); 
		
	  

		$this->load->view('cms/header_view',$data);
		$this->load->view('cms/packages_view',$data);
		$this->load->view('cms/footer_view',$data);
	}

	 
	function packages_view(){

		$data['page']='packages';
		
		$arr['table']='packages';
		$arr['where']="";
		$arr['and']="";
		$arr['order_by']="order by pack_id desc"; 
		$data['page_data']=$this->site_sentry->get_all($arr); 
		$this->load->view('cms/header_view',$data);
		$this->load->view('cms/packages_view',$data);
		$this->load->view('cms/footer_view',$data);
	}

	function save_packages(){ 
		
		$img_url=$this->input->post('img_url');		
		
		if($_FILES['fileinput']['name']!=" " && $_FILES['fileinput']['name']!=null &&					$_FILES['fileinput']['name']!=""){
			
			if($img_url!=" " && $img_url!="" && $img_url!=null){
				
				if(file_exists($img_url)){
					unlink($img_url);
				}
			}
		
			$arr=$_FILES['fileinput']['name'];
			$path_parts = pathinfo($arr);
			$ext=$path_parts['extension'];			 

			$_FILES['fileinput']['name']=rand().'.'.$ext;
			$config['upload_path'] ='upload/domestic';
			$config['allowed_types'] = '*';
			$config['max_size'] = '0';
			$config['max_width'] = '0';
			$config['max_height'] = '0';

			//$index = $this->session->userdata('indexgbr');

			$this->load->library('upload', $config);
							
		if ( ! $this->upload->do_upload("fileinput")){

				echo("{errors: {id:'name', msg:'" . $this->upload->display_errors(). "'}}");
			
				return;
			}    
			else{

				$link=$config['upload_path'].'/'.$_FILES['fileinput']['name'];
				
			}
		}
		else {
					
				$link=$img_url;
		}

		$data['pack_images']=$link;
			
		
			$data['table']="packages"; 
		$this->site_sentry->Save_records($data);
		redirect('cms/packages/packages_view');
	}

	function add_packages($D_Id=null,$type=null){ 

		$data['primary_id']=$D_Id;
		$data['table']="packages";
		$arr['page_data']=$this->site_sentry->PopulateValues($data); 
		$arr['page']="packages";
	
		
		$arr['type']=$type;

		$this->load->view('cms/header_view',$arr);
		$this->load->view('cms/add_packages',$arr);
		$this->load->view('cms/footer_view',$arr);

	} 


	
   
   
    
}?>