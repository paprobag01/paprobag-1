<?php class Offer_model extends CI_Model{ 
	

	function save_offer($link){

		//print'<pre>';print_R($_POST);exit;
		
		$offer_id=$this->input->post('offer_id');

		$data=array(
			
			'new_offer'=>$this->input->post('new_offer'),
			'percentage'=>$this->input->post('percentage'),
			'description'=>$this->input->post('description'),
			'offer_image'=>$link,
			'active'=>$this->input->post('active')
		);
		if($offer_id=="" || $offer_id==" " || $offer_id==null){
			
			$this->db->insert('offer',$data);
		
		}else{

			$this->db->where('offer_id',$offer_id);
			$this->db->update('offer',$data);
		}
	}

	function get_all_offers(){

		$sql=$this->db->query("select * from offer order by offer_id desc");
		return $sql->result_array();
	}

	function PopulateValues($offer_id=null){
		
		if($offer_id==""){

		$sql=$this->db->query("SELECT column_name,column_type
								FROM information_schema.columns
								WHERE table_schema = DATABASE()
								AND table_name='offer'
								ORDER BY ordinal_position");
			
			return  $sql->result();
		}else if($offer_id!=""){

			$sql=$this->db->query("select * from offer  where offer_id='$offer_id'");
			$arr=$sql->result();
			foreach($arr as $row){
				$data=array(
						
					'offer_id'=>$row->offer_id,
					'new_offer'=>$row->new_offer,
					'percentage'=>$row->percentage,
					'offer_image'=>$row->offer_image,
					'description'=>$row->description,
					'active'=>$row->active 
				);
			}
			return $data;
		}
	}

	function delete_rec(){

		$offer_id=$this->input->post('offer_id');
		$sql1=$this->db->query("select * from offer where offer_id='$offer_id'");
		$arr=$sql1->row_array();
		$offer_image=$arr['offer_image'];
		if(file_exists($offer_image)){
			unlink($offer_image);
		}
		$sql=$this->db->query("delete from offer where offer_id='$offer_id'");
		print_R($this->db->affected_rows());
 	}



} 
?>