<?php 
 class Subcategories extends CI_Controller{

		function __Construct(){
		parent::__construct();
		if(!$this->session->userdata('user_id')){
				   redirect("cms/login");
				}
				
               $this->load->library('site_sentry');
			    $this->load->model('cms/subcategories_model');
			}
      
	  function index(){
		  $data['page']='subcategories';
		  $arr['table']='subcategories';
		$arr['where']="where deleted=0";
		$arr['and']="";
		$arr['order_by']=""; 
		$arr1['table']='categories';
		$arr1['where']="where deleted=0";//
		$arr1['and']="";
		$arr1['order_by']="";
		$arr1['fields']="cat_id, category_name";
		  $data['page_data']=$this->site_sentry->get_all($arr); 
		  $data['page_data1']=$this->subcategories_model->getCategories($arr1);
		 // print_r($data['page_data1']); die;
		 $this->load->view('cms/header_view', $data);
		 $this->load->view('cms/subcategories_list');
		 $this->load->view('cms/footer_view');
		
     }
	 function add_subcategories($id=null, $type=null)
	 {
		 $data['page']='subcategories';
		 $arr['primary_id']=$id;
		  $arr['table']='subcategories';
		$arr['where']="where deleted=0";
		$arr['and']="";
		$arr['order_by']=""; 
		
		$arr1['table']='categories';
		
		$arr1['and']="";
		$arr1['order_by']="";
		$arr1['fields']="cat_id, category_name";
		
		
		
		$arr1['where']="";
		  $data['page_data']=$this->site_sentry->PopulateValues($arr); 
		  
		 
		  
		  if($id!="")
		  {
		  $cat_id=$data['page_data']['cat_id'];
		  $arr1['where']="where cat_id=$cat_id";
		  $data['page_data1']=$this->subcategories_model->getCategories($arr1);
		  $arr1['where']="";
			$data['page_data2']=$this->subcategories_model->getCategories($arr1);
		  }
		  else
		  {
			$arr1['where']="";
			$data['page_data2']=$this->subcategories_model->getCategories($arr1);
		  }
		  
		 
		 

		  $data['type']=$type;
		  //print_r($data['page_data']); die;
		 $this->load->view('cms/header_view', $data);
		 $this->load->view('cms/add_subcategories_view', $data);
		 $this->load->view('cms/footer_view', $data);
	 }
	 function save_subcategories()
	 {
		 $id=$this->input->post('sub_cat_id');
		 $data['table']="subcategories"; 
		$this->site_sentry->Save_records($data);
		redirect('cms/subcategories/add_subcategories/'.$id.'');
	 }
	 function deleteSubCategory($id=null)
	 {
		 $this->db->where('sub_cat_id', $id);	
		$data= array(
		
		'deleted'=>1,
		'created_on'=>date('d-m-Y')
		
		);
		$this->db->update('subcategories', $data); 
		redirect('cms/subcategories');
	 }
	
		
	
}
?>