<?php 
extract($page_data);
//print($first_name);exit;
?>
<!-- BEGIN PAGE -->  
      <div class="page-content"> 
         <!-- BEGIN PAGE CONTAINER-->
         <div class="container-fluid">
            <!-- BEGIN PAGE HEADER-->   
            <div class="row-fluid">
               <div class="span12"> 
                  <h3 class="page-title">
                      Contact us deatails                     
                  </h3> 
               </div>
            </div>
            <!-- END PAGE HEADER-->
            <!-- BEGIN PAGE CONTENT-->
            <div class="row-fluid">
               <div class="span12">
                  <!-- BEGIN SAMPLE FORM PORTLET-->   
                  <div class="portlet box blue">
                     <div class="portlet-title">
                        <h4><i class="icon-reorder"></i>Add  Contact us deatails</h4>
                        <div class="tools">
                           <a href="javascript:;" class="collapse"></a> 
                           <a href="javascript:;" class="remove"></a>
                        </div>
                     </div>
                     <div class="portlet-body form">
                        <!-- BEGIN FORM-->
                        <form action="<?php echo base_url()?>cms/contact_us/save_contact_us" class="form-horizontal" method="post" enctype="multipart/form-data" />
						<input type="hidden" name="Id" value="<?php echo $Id;?>">
                         
						   <!-- <div class="control-group">
                              <label class="control-label">Image :</label>
                              <div class="controls">
                                <div class="fileupload fileupload-new" data-provides="fileupload">
                                    <div class="fileupload-new thumbnail" style="width: 200px; height: 150px;">
                                       <?php if($deals_image!=""){?>
										<img src="<?php echo base_url().$deals_image;?>" /> 
										<?php } else {?>
									   <img src="<?php echo base_url()?>assets/img/noimage.gif" alt="" />
									   <?php }?>
									   <input type="hidden" value="<?php echo $deals_image; ?>" name="img_url">	
                                    </div>
                                    <div class="fileupload-preview fileupload-exists thumbnail" style="max-width: 200px; max-height: 150px; line-height: 20px;"></div>
                                    <div>
                                       <span class="btn btn-file"><span class="fileupload-new">Select image</span>
                                       <span class="fileupload-exists">Change</span>
                                       <input type="file" name="fileinput" <?php if($type=='view'){?>disabled<?php }?> class="default" /></span>
                                       <a href="#" class="btn fileupload-exists" data-dismiss="fileupload">Remove</a>
                                    </div>
									
                                 </div> 
                              </div>
                           </div>  -->
						   <!-- <div class="control-group">
                              <label class="control-label">Date</label>
                              <div class="controls">
                                 <input type="text" <?php if($type=='view'){?>disabled<?php }?>  name="paper_date" id="paper_date" class="span4  m-wrap" value="<?php 
								 if($paper_date!='')
								 {
									echo date("d/m/Y",strtotime($paper_date)); 
								}?>" /> 
                              </div>
                           </div>	 -->
						    <div class="control-group">
                              <label class="control-label">Name</label>
                              <div class="controls">
                                 <input type="text" <?php if($type=='view'){?>disabled<?php }?>  name="Name" id="Name" class="span4  m-wrap" value="<?php echo $Name;?>" /> 
                              </div>
                           </div>
						   <div class="control-group">
                              <label class="control-label">Mobile</label>
                              <div class="controls">
                                 <input type="text"  name="Mobile" <?php if($type=='view'){?>disabled<?php }?> id="Mobile" class="span4  m-wrap" value="<?php echo $Mobile;?>" />  
								 
                              </div>
                           </div>
						   <div class="control-group">
                              <label class="control-label">Email</label>
                              <div class="controls">
                                 <input type="text"  name="Email" <?php if($type=='view'){?>disabled<?php }?> id="Email" class="span4  m-wrap" value="<?php echo $Email;?>" />  
								 
                              </div>
							  </div>
							  <div class="control-group">
                              <label class="control-label">Message</label>
                              <div class="controls">
                                 <textarea  name="Message" <?php if($type=='view'){?>disabled<?php }?> id="Message" class="span12 ckeditor  m-wrap" cols="30" rows="10"> <?php echo $Message;?> </textarea> 
								 
                              </div>
                           </div>
                           <div class="form-actions">
                              <?php if($type!='view'){?><button type="submit" class="btn blue">Save</button><?php }?>
                              <button type="button" class="cancel btn">Cancel</button>
                           </div>
                        </form>
                        <!-- END FORM-->           
                     </div>
                  </div>
                  <!-- END SAMPLE FORM PORTLET-->
               </div>
            </div>
			<script type="text/javascript">
			 $(document).ready(function(){
				$(".cancel").click(function()
					{

					document.location="<?php echo base_url()?>cms/contact_us/contact_us_view";
				});             

				
		  });	
		  </script>	
			</div>
            </div>
			</div>
             
   
  });

<script src="<?php echo base_url()?>js/nicEdit-latest.js" type="text/javascript"></script>
<script type="text/javascript">bkLib.onDomLoaded(nicEditors.allTextAreas);</script>
