<?php
class About_us extends CI_Controller{
	
	function __Construct(){

		parent::__construct();
		if(!$this->session->userdata('user_id')){
				   redirect("cms/login");
				}
		$this->load->library('site_sentry');
		//$this->load->model('users_model');
	}

	function index(){

		$data['page']='about_us';
		
		$arr['table']='about_us';
		$arr['where']="";
		$arr['and']="";
		$arr['order_by']="order by about_id desc";
		
		$data['page_data']=$this->site_sentry->get_all($arr); 
		
	  /*  $role['table']='roles';
		$role['where']="where active='yes'";
		$role['and']="";
		$role['order_by']="order by role_id desc";
		$data['role_arr']=$this->site_sentry->get_all($role); */

		$this->load->view('cms/header_view',$data);
		$this->load->view('cms/about_us_view',$data);
		$this->load->view('cms/footer_view',$data);
	}

	 
	function about_us_view(){

		$data['page']='about_us';
		
		$arr['table']='about_us';
		$arr['where']="";
		$arr['and']="";
		$arr['order_by']="order by about_id desc"; 
		$data['page_data']=$this->site_sentry->get_all($arr); 
		$this->load->view('cms/header_view',$data);
		$this->load->view('cms/about_us_view',$data);
		$this->load->view('cms/footer_view',$data);
	}

	function save_about_us(){ 
		
		$img_url=$this->input->post('img_url');		
		
		if($_FILES['fileinput']['name']!=" " && $_FILES['fileinput']['name']!=null &&					$_FILES['fileinput']['name']!=""){
			
			if($img_url!=" " && $img_url!="" && $img_url!=null){
				
				if(file_exists($img_url)){
					unlink($img_url);
				}
			}
		
			$arr=$_FILES['fileinput']['name'];
			$path_parts = pathinfo($arr);
			$ext=$path_parts['extension'];			 

			$_FILES['fileinput']['name']=rand().'.'.$ext;
			$config['upload_path'] ='upload/about_us';
			$config['allowed_types'] = '*';
			$config['max_size'] = '0';
			$config['max_width'] = '0';
			$config['max_height'] = '0';

			//$index = $this->session->userdata('indexgbr');

			$this->load->library('upload', $config);
							
		if ( ! $this->upload->do_upload("fileinput")){

				echo("{errors: {id:'name', msg:'" . $this->upload->display_errors(). "'}}");
			
				return;
			}    
			else{

				$link=$config['upload_path'].'/'.$_FILES['fileinput']['name'];
				
			}
		}
		else {
					
				$link=$img_url;
		}

		$data['about_image']=$link;
			
		
			$data['table']="about_us"; 
		$this->site_sentry->Save_records($data);
		redirect('cms/about_us/about_us_view');
	}

	function add_about_us($about_id=null,$type=null){ 

		$data['primary_id']=$about_id;
		$data['table']="about_us";
		$arr['page_data']=$this->site_sentry->PopulateValues($data); 
		$arr['page']="about_us";
	/*	$role['table']='roles';
		$role['where']="where active='yes'";
		$role['and']="";
		$role['order_by']="order by role_id desc";
		$arr['role_arr']=$this->site_sentry->get_all($role); */
		
		$arr['type']=$type;

		$this->load->view('cms/header_view',$arr);
		$this->load->view('cms/add_about_us',$arr);
		$this->load->view('cms/footer_view',$arr);

	} 


	function delete_rec(){
			

			$about_id=$this->input->post('about_id');
			$sql=$this->db->query("select * from about_us where about_id='$about_id'");
			$arr=$sql->row_array();
				if(count($arr)>0){
					$img=$arr['about_image'];
					if(file_exists($img)){
						unlink($img);
					}
				}
				$sql_delete=$this->db->query("delete from about_us  where  about_id='$about_id'");
				print_R($this->db->affected_rows());
	}
   
   
    
}?>