<?php 
extract($page_data);
extract($page_data3);
//print_r($page_data3); die;

?>
<div role="main" class="main shop with-sidebar">
			
			
			
				
			
			
			
		
				<section class="main-content-wrap">
					<div class="container">
						<div class="row">
						<?php if($ready_to_print==1){ ?>
							<div class="col-md-12 main-content">
							<?php } else { ?>
							 <div class="col-md-9 main-content">
								<?php }?>
								<div class="row">
									<div class="col-sm-6" id="frameBorder" style="border:1px solid #777;height:400px;background:url('<?php echo base_url().$prod_image?>');">
										<div class="product-preview" id="imagePreview">
											<!-- <div class="flexslider flexsliderPro">
												<ul class="slides">
													<li data-thumb="<?php echo base_url().$prod_image?>">
														<a class="popup-img" title="The Product 1" href="<?php echo base_url().$prod_image?>"><img src="<?php echo base_url().$prod_image?>" alt=""></a>
													</li>
													<li data-thumb="<?php echo base_url().$prod_image1?>">
														<a class="popup-img" title="The Product 2" href="<?php echo base_url().$prod_image1?>"><img src="<?php echo base_url().$prod_image1?>" alt=""></a>
													</li>
													<li data-thumb="<?php echo base_url().$prod_image2?>">
														<a class="popup-img" title="The Product 3" href="<?php echo base_url().$prod_image2?>"><img src="<?php echo base_url().$prod_image2?>" alt=""></a>
													</li>
													<li data-thumb="<?php echo base_url().$prod_image3?>">
														<a class="popup-img" title="The Product 4" href="<?php echo base_url().$prod_image3?>"><img src="<?php echo base_url().$prod_image3?>" alt=""></a>
													</li>
												</ul>
											</div> -->
											
											
											
											<!-- <form id="uploadForm" method="post" enctype="multipart/form-data">-->
												<div id="imgArea" style="width: 100%;height: 400px;overflow:hidden;">
												<div class="component" style="width:60%; height:60%; margin:20%">
				
					
					<!-- <img class="resize-image" src="<?php echo base_url()?>img/image.jpg" alt="image for resizing"> -->
					<img class="resize-image" id="uploadedImage" src="<?php if(isset($_SESSION['imageUpload'])){ echo $_SESSION['imageUpload']; }?>"/>
					
					<!-- <button class="btn-crop js-crop">Crop<img class="icon-crop" src="img/crop.svg"></button> -->
												</div>
												</div>
												
												<div id="uploadFormLayer">
												
												
												</div>
<!-- 											</form> -->
											
 

<script type="text/javascript">
$(document).ready(function(){
        $('#uploadedImage[src=""]').hide();
        $('#uploadedImage:not([src=""])').show();
    });
</script>

 <script type="text/javascript">



 function UploadImage()
 {
 var formdata=document.getElementById("uploadForm");
 alert(formdata);
 $.ajax({
            url: "<?php echo base_url(); ?>ajaxupload/process_ajax",
            type: "POST",
            data:  new FormData(formdata),
            mimeType:"multipart/form-data",
            contentType: false,
            cache: false,
            processData:false,
            success: function(data)
            {
           // alert(data);
            $("#uploadedImage").attr("src", data);
            location.reload();
            
            
            },
            error: function() 
            {
            }           
       });
 }

        
       
   
</script>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="thumb-item thumb-item-list summary">
											<div class="thumb-item-content">
												<h2><?php echo $prod_name?></h2>
												<?php if ($ready_to_print==1){?>
												<div class="col-sm-12 list-review">
												<div class="col-sm-12">&nbsp;</div>
													<div class="col-sm-12">
													<div class="col-sm-6">
														<div class="col-sm-6">GSM</div><div class="col-sm-6">: <select><option>60</option><option>70</option></select></div>
													</div>
													<div class="col-sm-6">
														<div class="col-sm-6">Bag Color</div><div class="col-sm-6">: <select><option>Red</option><option>Blue</option></select></div>
													</div>
													</div>
												</div>
												<div class="col-sm-12 list-review">
												<div class="col-sm-12">&nbsp;</div>
													<div class="col-sm-12">
													<div class="col-sm-6">
														<div class="col-sm-6">No Of Colors</div><div class="col-sm-6">: <select><option>60</option><option>70</option></select></div>
													</div>
													<div class="col-sm-6">
														<div class="col-sm-6">Print Colors</div><div class="col-sm-6">: <select><option>Red</option><option>Blue</option></select></div>
													</div>
													</div>
												</div>
												
												<div class="col-sm-12 list-review">
												<div class="col-sm-12">&nbsp;</div>
													<div class="col-sm-12">
													<div class="col-sm-6">
														<div class="col-sm-6">Quantity:</div><div class="col-sm-6"><input type="text" name="quantity" id="quantity" value="1" class="col-sm-6"/></div>
													</div>
													<div class="col-sm-6">
														<div class="col-sm-6">Price :</div><div class="col-sm-6"></div>
													</div>
													</div>
													<div class="col-sm-12">&nbsp;</div>
												</div>
												
												<div class="col-sm-12 list-review" style="height:35px;">
												
													<div class="col-sm-12">
													<div class="col-sm-6">
														<div class="col-sm-12">
															<div class="imgChange"><span>Upload Your Image/Logo</span>
															<!--  <input name="userImage" id="userImage" type="file" onchange="UploadImage()" class="inputFile" />-->
															<form id="uploadForm" method="post" enctype="multipart/form-data">
															 <input name="userImage" id="userImage" type="file" onchange="UploadImage()" class="inputFile" />
															 </form>
															</div>
														</div>
														
													</div>
													<div class="col-sm-6">
														<div class="col-sm-12">
														<div class="imgChange">
															<a onclick="AddToCart()" style="cursor:pointer"><i class="fa fa-shopping-cart"></i> <span>Add to Cart</span></a>
															</div>
														</div>
													</div>
													</div>
													
												</div>
												<?php }else {?>
												<div class="col-sm-12 list-review">
												<div class="col-sm-12">&nbsp;</div>
												<div class="col-sm-4">
														<div class="star-rating" title="Rated 5.00 out of 5">
															<span><strong class="rating">5.00</strong> out of 5</span>
														</div>
													</div>
													<div class="col-sm-4">0 Review</div>
													<div class="col-sm-4"><a href="#">Add Your Review</a></div>
												</div>
												
												
												
												<div class="col-sm-12"><ins>Rs. <?php echo $prod_price; ?></ins></div>
												<div class="col-sm-12">Short Description:<?php echo $prod_description; ?>.</div>
												<div class="col-sm-12">Sold By:</div>
												<div class="col-sm-12"><p class="quan">
													<?php if($ready_to_print==0){?><label>MOQ:</label><?php } else{?><label>Qty:</label><?php }?>
													<input type="text" name="quantity" id="quantity" value="1" title="" class="input-text qty">
												</p>
												</div>
												
												<div class="col-sm-12">
												<p class="thumb-act thumb-act-more">
													<a class="btn-cart" onclick="AddToCart()" style="cursor:pointer"><i class="fa fa-shopping-cart"></i> <span>Add to Cart</span></a>
													<!-- <a href="#"><i class="fa fa-heart-o"></i></a>
													<a href="#"><i class="fa fa-exchange"></i></a> -->
													&nbsp;
														<?php if(isset($customize_now) && $customize_now==1){?>
												
													<a class="btn-cart" href="<?php echo base_url()?>customize/getCustomizations/<?php echo $cat_id?>/<?php echo $prod_id?>" style="cursor:pointer"><i class="fa fa-cogs"></i> <span>Customize Now</span></a>
													<!-- <a href="#"><i class="fa fa-heart-o"></i></a>
													<a href="#"><i class="fa fa-exchange"></i></a> -->
												
												<?php }?>
												</p>
												
												</div>
												
												<hr>
												<!-- <p class="product-cat">Category: <a href="#"><?php ?></a>.</p>-->
												<div class="col-sm-12">
												<ul class="social-icons-share">
													<li><label>Share on:</label></li>
													<li><a href="#" target="_blank" data-toggle="tooltip" data-placement="top" title="Facebook"><i class="fa fa-facebook"></i></a></li>
													<li><a href="#" target="_blank" data-toggle="tooltip" data-placement="top" title="Twitter"><i class="fa fa-twitter"></i></a></li>
													<li><a href="#" target="_blank" data-toggle="tooltip" data-placement="top" title="Google Plus"><i class="fa fa-google-plus"></i></a></li>
													<li><a href="#" target="_blank" data-toggle="tooltip" data-placement="top" title="Pinterest"><i class="fa fa-pinterest"></i></a></li>
													<li><a href="#" target="_blank" data-toggle="tooltip" data-placement="top" title="Email"><i class="fa fa-envelope-o"></i></a></li>
												</ul>
												</div>
												<?php }?>
											</div>
											<input type="hidden" name="prodqty" id="prodqty" value="0"/>
												<input type="hidden" name="prod_id" id="prod_id" value="<?php echo $prod_id?>"/>
												<script>
												function AddToCart()
												{
													
													var cartqty=document.getElementById("cartqty").innerHTML;
													
													//document.getElementById("counter").value=counter*1 +1;
													var quantity=document.getElementById("quantity").value
													
													var prod_id=document.getElementById("prod_id").value;
													var prodqty=document.getElementById("prodqty").value;
													
														if(prodqty==quantity)
														{
															alert("Item with same quantity is already added to cart")
														}
														else
														{
														
													
													
													//alert(counter);
													
													
													
													var xmlhttp;
							if (window.XMLHttpRequest)
							  {// code for IE7+, Firefox, Chrome, Opera, Safari
							  xmlhttp=new XMLHttpRequest();
							  }
							else
							  {// code for IE6, IE5
							  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
							  }
							xmlhttp.onreadystatechange=function()
							  {
							  if (xmlhttp.readyState==4 && xmlhttp.status==200)
								{
								
								var html=xmlhttp.response;
								var htmlresult=html.split("|");
								document.getElementById("minicartProds").innerHTML=htmlresult[0];
								document.getElementById("cartqty").innerHTML=htmlresult[1];
								document.getElementById("prodqty").value=quantity;
								
								//document.getElementById("minicartProds").innerHTML=xmlhttp.response;
								}
							  }
							 
							 totalCartQty=0;
							 counter=0;
								 // alert("Added To Cart");
							xmlhttp.open("POST","<?php echo base_url()?>cartSessVal/setSession/"+prod_id+"/"+quantity+"/"+totalCartQty+"/"+counter,true);
							xmlhttp.send();
								}
													
							
												}
												</script>
										</div>
									</div>
								</div>
								<?php if($ready_to_print==1){?>
								</div>
								
								<div class="col-sm-9" style="margin-top: 50px">
								<?php }?>
								<div id="accordion" class="panel-group">
									<div class="panel panel-default pgl-panel">
										<div class="panel-heading">
											<h4 class="panel-title"> <a href="#collapseOne" data-parent="#accordion" data-toggle="collapse">Description</a> </h4>
										</div>
										<div class="panel-collapse collapse in" id="collapseOne">
											<div class="panel-body" style="color:#555;background:rgb(195, 195, 195);">
												<hr>
												<p><?php echo $prod_description; ?></p>
											</div>
										</div>
									</div>
									<div class="panel panel-default pgl-panel">
										<div class="panel-heading">
											<h4 class="panel-title"> <a class="collapsed" href="#collapseTwo" data-parent="#accordion" data-toggle="collapse">Reviews (2)</a> </h4>
										</div>
										<div class="panel-collapse collapse" id="collapseTwo">
											<div class="panel-body"> 
												<div class="post-block post-comments clearfix">
													<ul class="comments">
														<li>
															<div class="comment">
																<div class="img-circle"> <img class="avatar" width="50" alt="" src="images/blog/avatar.png"> </div>
																<div class="comment-block">
																	<span class="comment-by"> <strong>Frank Reman</strong></span>
																	<span class="date"><small><i class="fa fa-clock-o"></i> January 12, 2013</small></span>
																	<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
																</div>
															</div>
														</li>
														<li>
															<div class="comment">
																<div class="img-circle"> <img class="avatar" width="50" alt="" src="images/blog/avatar.png"> </div>
																<div class="comment-block">
																	<span class="comment-by"> <strong>Frank Reman</strong></span>
																	<span class="date"><small><i class="fa fa-clock-o"></i> July 11, 2014</small></span>
																	<p>Nam viverra euismod odio, gravida pellentesque urna varius vitae, gravida pellentesque urna varius vitae</p>
																</div>
															</div>
														</li>
													</ul>
												</div>
												<div class="post-block post-leave-comment">
													<h3>Leave a review</h3>
													<form>
														<div class="form-group">
															<div class="row">
																<div class="col-xs-6">
																	<label>Your name *</label>
																	<input type="text" value="" maxlength="100" class="form-control" name="name2" id="name2">
																</div>
																<div class="col-xs-6">
																	<label>Your email address *</label>
																	<input type="email" value="" maxlength="100" class="form-control" name="email" id="email">
																</div>
															</div>
														</div>
														<div class="form-group">
															<div class="row">
																<div class="col-sm-12">
																	<label>Comment *</label>
																	<textarea maxlength="5000" rows="10" class="form-control" name="comment" id="comment"></textarea>
																</div>
															</div>
														</div>
														<div class="row">
															<div class="col-md-12">
																<input type="submit" value="Submit Review" class="btn btn-grey" data-loading-text="Loading...">
															</div>
														</div>
													</form>
												</div>
											</div>
										</div>
									</div>
								</div>
								
								<div class="related">
									<h2>Related Products</h2>
									<div class="row">
										<div class="owl-carousel multi-slides multi-slides-right" data-plugin-options='{"items": 3, "singleItem": false, "pagination": false, "navigation": true}'>
											<?php 
											foreach($page_data1 as $row)
											{
											?>
											<div class="col-md-12">
												<div class="thumb-item">
													<div class="thumb-item-img">
														<a href="<?php echo base_url()?>productDetails/getDetails/<?php echo $row['prod_id']?>" class="btn-detail">
															<img class="img-responsive" src="<?php echo base_url().$row['prod_image']?>" alt="">
															<img class="img-responsive" src="<?php echo base_url().$row['prod_image']?>" alt="">
														</a>
														<span class="thumb-act thumb-act-first">
															<a href="#" class="btn-cart"><i class="fa fa-shopping-cart"></i></a>
															<!-- <a data-target="#quickview-detail" data-toggle="modal" href="javascript:void(0);"><i class="fa fa-eye"></i></a>
															<a href="#"><i class="fa fa-heart-o"></i></a>
															<a href="#"><i class="fa fa-exchange"></i></a> -->
														</span>
													</div>
													<div class="thumb-item-content">
														<div class="star-rating pull-right" title="Rated 5.00 out of 5">
															<span style="width:100%"><strong class="rating">5.00</strong> out of 5</span>
														</div>
														<h3><a href="#"><?php echo $row['prod_name'] ?></a></h3>
														
														<p class="product-cat"><a href="#">Bags</a>, <a href="#">Accessories</a></p>
														<p class="product-price"><ins>$280.00</ins></p>
													</div>
												</div>
											</div>
											<?php }?>
											
										</div>
									</div>
								</div>						
							</div>
							
							<div class="col-md-3 sidebar">
							<?php if($ready_to_print!=1){ ?>
								  <aside class="block blk-categories">
									<h3>Categories</h3>
									<ul class="list-categories">
									<?php 
									foreach($page_data2 as $row)
									{
									?>
										<li><a href="#"><?php echo $row['category_name']?></a></li>
									<?php 
									}
									?>
										
									</ul>
								</aside>
								<?php }?>
								<aside class="block blk-thmbs-pro">
									<h3>You Recently Viewd</h3>
									<ul class="list-thumbs-pro">
									<li class="product">
											<div class="thumb-item">
												<div class="thumb-item-img">
													<a href="<?php echo base_url().'productDetails/getDetails/'.$prod_id ;?>"><img width="80" src="<?php  echo base_url().$prod_image;?>" alt=""></a>
												</div>
												
												<div class="thumb-item-content">
													<h3><a href="#"><?php echo $prod_name; ?></a></h3>
													<div class="star-rating" title="Rated 5.00 out of 5">
														<span style="width:100%"><strong class="rating">5.00</strong> out of 5</span>
													</div>
													<p class="product-price"><ins><?php  echo $prod_price; ?></ins></p>
												</div>
											</div>
										</li>
									<?php
									$i=0;
									if(isset($_COOKIE))
									{
									foreach ($_COOKIE as $key=>$val)
										{
											if($key!='PHPSESSID' && $key!='ci_session' && $key!='count')
											{
												
										//	echo $key.' is '.$val."<br>\n";
												if('prodId'.$val==$key){
													if(isset($_COOKIE['prodId'.$val.'']) && $prod_id!=$_COOKIE['prodId'.$val.''])
													{
											?>
											<li class="product">
											<div class="thumb-item">
												<div class="thumb-item-img">
													<a href="<?php if(isset($_COOKIE['prodImage'.$val.''])){ echo base_url().'productDetails/getDetails/'.$_COOKIE['prodId'.$val.''] ;}?>"><img width="80" src="<?php if(isset($_COOKIE['prodImage'.$val.''])){ echo base_url().$_COOKIE['prodImage'.$val.''];}?>" alt=""></a>
												</div>
												
												<div class="thumb-item-content">
													<h3><a href="#"><?php if(isset($_COOKIE['prodName'.$val.''])){echo $_COOKIE['prodName'.$val.''];} ?></a></h3>
													<div class="star-rating" title="Rated 5.00 out of 5">
														<span style="width:100%"><strong class="rating">5.00</strong> out of 5</span>
													</div>
													<p class="product-price"><ins><?php if(isset($_COOKIE['prodPrice'.$val.''])){ echo $_COOKIE['prodPrice'.$val.''];} ?></ins></p>
												</div>
											</div>
										</li>
											<?php }
												}
											}
										}
									}
											
											?>
												
													
											
										
										
									</ul>
								</aside>
								
							</div>
						</div>	
					</div>
				</section>
</div>