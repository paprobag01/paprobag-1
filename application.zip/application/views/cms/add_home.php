<?php 
extract($page_data);
//print($first_name);exit;
?>
<!-- BEGIN PAGE -->  
      <div class="page-content"> 
         <!-- BEGIN PAGE CONTAINER-->
         <div class="container-fluid">
            <!-- BEGIN PAGE HEADER-->   
            <div class="row-fluid">
               <div class="span12"> 
                  <h3 class="page-title">
                     Add Home page Images                     
                  </h3> 
               </div>
            </div>
            <!-- END PAGE HEADER-->
            <!-- BEGIN PAGE CONTENT-->
            <div class="row-fluid">
               <div class="span12">
                  <!-- BEGIN SAMPLE FORM PORTLET-->   
                  <div class="portlet box blue">
                     <div class="portlet-title">
                        <h4><i class="icon-reorder"></i>Add Home page Images</h4>
						<?php echo $type; ?>
                        <div class="tools">
                           <a href="javascript:;" class="collapse"></a> 
                           <a href="javascript:;" class="remove"></a>
                        </div>
                     </div>
                     <div class="portlet-body form">
                        <!-- BEGIN FORM-->
                        <form action="<?php echo base_url()?>cms/detail/save_home" class="form-horizontal" method="post" enctype="multipart/form-data" />
						<input type="hidden" name="home_id" value="<?php echo $home_id;?>">
                         
						   <div class="control-group">
                              <label class="control-label">Image :</label>
                              <div class="controls">
                                <div class="fileupload fileupload-new" data-provides="fileupload">
                                    <div class="fileupload-new thumbnail" style="width: 200px; height: 150px;">
                                       <?php if($home_image!=""){?>
										<img src="<?php echo base_url().$home_image;?>" /> 
										<?php } else {?>
									   <img src="<?php echo base_url()?>assets/img/noimage.gif" alt="" />
									   <?php }?>
									   <input type="hidden" value="<?php echo $home_image; ?>" name="img_url">	
                                    </div>
                                    <div class="fileupload-preview fileupload-exists thumbnail" style="max-width: 200px; max-height: 150px; line-height: 20px;"></div>
                                    <div>
                                       <span class="btn btn-file"><span class="fileupload-new">Select image</span>
                                       <span class="fileupload-exists">Change</span>
                                       <input type="file" name="fileinput" <?php if($type=='view'){?>disabled<?php }?> class="default" /></span>
                                       <a href="#" class="btn fileupload-exists" data-dismiss="fileupload">Remove</a>
					<p> image resolution size should be 370*188</p>
                                    </div>
									
                                 </div> 
                              </div>
                           </div> 
						   <!-- <div class="control-group">
                              <label class="control-label">Date</label>
                              <div class="controls">
                                 <input type="text" <?php if($type=='view'){?>disabled<?php }?>  name="paper_date" id="paper_date" class="span4  m-wrap" value="<?php 
								 if($paper_date!='')
								 {
									echo date("d/m/Y",strtotime($paper_date)); 
								}?>" /> 
                              </div>
                           </div>	 -->
						    <div class="control-group">
                              <label class="control-label">Name</label>
                              <div class="controls">
                                 <input type="text" <?php if($type=='view'){?>disabled<?php }?>  name="home_name" id="home_name" class="span4  m-wrap" value="<?php echo $home_name;?>" /> 
                              </div>
                           </div>
				<div class="control-group">
                              <label class="control-label">Price</label>
                              <div class="controls">
                                 <input type="text" <?php if($type=='view'){?>disabled<?php }?>  name="price" id="price" class="span4  m-wrap" value="<?php echo $price;?>" /> 
                              </div>
                           </div>
						   <div class="control-group">
                              <label class="control-label">Section</label>
                              <div class="controls">
							  <select name="section" id="section" <?php if($type=='view'){?>disabled<?php }?>>
							    
								<?php if($section!=null || $section!=""){?>
								<option><?php echo $section ?></option>
								<?php }
								else
								{
								?>
								<option value="" selected>Select</option>
								<?php 
								}
								?>
							  <option>1</option>
							  <option>2</option>
							  <option>3</option>
							  </select>
							  </div>
							</div>
						   <div class="control-group">
                              <label class="control-label">Description</label>
                              <div class="controls">
                                 <textarea  name="home_description" <?php if($type=='view'){?>disabled<?php }?> id="home_description" class="span12 ckeditor  m-wrap" cols="30" rows="10"> <?php echo $home_description;?> </textarea> 
								 
                              </div>
                           </div>
						   <div class="control-group">
                              <label class="control-label">Meta Title</label>
                              <div class="controls">
                                 <input type="text" name="m_title" <?php if($type=='view'){?>disabled<?php }?> id="m_title" class="span12   m-wrap" value="<?php echo $m_title;?>" />
							   </div>
                           </div>
						   <div class="control-group">
                              <label class="control-label">Meta Keywords</label>
                              <div class="controls">
                                 <textarea name="m_key" <?php if($type=='view'){?>disabled<?php }?> id="m_key" class="span12   m-wrap" ><?php echo $m_key;?></textarea>
							   </div>
                           </div>
						   <div class="control-group">
                              <label class="control-label">Meta Description</label>
                              <div class="controls">
                                 <textarea name="m_desc" <?php if($type=='view'){?>disabled<?php }?> id="m_desc" class="span12   m-wrap" ><?php echo $m_desc;?></textarea>
							   </div>
                           </div>
						   <div class="control-group">
                              <label class="control-label">status</label>
                              <div class="controls">
                                 <select name="home_status" <?php if($type=='view'){?>disabled<?php }?> class="span3 m-wrap">
									<option value="" selected>Select
									<option <?php if($home_status=='Active'){?>selected<?php }?> value="Active">Active
									<option value="In-Active" <?php if($home_status=='In-Active'){?>selected<?php }?>>In Active
                                 </select> 
                              </div>
                           </div>
                           <div class="form-actions">
                              <?php if($type!='view'){?><button type="submit" class="btn blue">Save</button><?php }?>
                              <button type="button" class="cancel btn">Cancel</button>
                           </div>
                        </form>
                        <!-- END FORM-->           
                     </div>
                  </div>
                  <!-- END SAMPLE FORM PORTLET-->
               </div>
            </div>
			<script type="text/javascript">
			 $(document).ready(function(){
				$(".cancel").click(function()
					{

					document.location="<?php echo base_url()?>cms/detail/home_view";
				});             

				
		  });	
		  </script>	
			</div>
            </div>
			</div>
             
   
  });

