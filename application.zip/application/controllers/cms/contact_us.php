<?php
class Contact_us extends CI_Controller{
	
	function __Construct(){

		parent::__construct();
		if(!$this->session->userdata('user_id')){
				   redirect("cms/login");
				}
		$this->load->library('site_sentry');
		//$this->load->model('contact_model');
	}

	function index(){

		$data['page']='contact_us';
		
		$arr['table']='contact';
		$arr['where']="";
		$arr['and']="";
		$arr['order_by']="order by Id desc"; 
		$data['page_data']=$this->site_sentry->get_all($arr); 
		$this->load->view('cms/header_view',$data);
		$this->load->view('cms/contact_us_view',$data);
		$this->load->view('cms/footer_view',$data);
	
	}

	 
	

	 function save_contact_us(){ 
		
		$data['table']="contact"; 
		$this->site_sentry->Save_records($data);
		redirect('cms/contact_us/contact_us_view');
	}

	function add_contact_us($Id=null,$type=null){ 

		$data['primary_id']=$Id;
		$data['table']="contact";
		$arr['page_data']=$this->site_sentry->PopulateValues($data); 
		$arr['page']="contact_us";
	/*	$role['table']='roles';
		$role['where']="where active='yes'";
		$role['and']="";
		$role['order_by']="order by role_id desc";
		$arr['role_arr']=$this->site_sentry->get_all($role); */
		
		$arr['type']=$type;

		$this->load->view('cms/header_view',$arr);
		$this->load->view('cms/add_contact_us',$arr);
		$this->load->view('cms/footer_view',$arr);

	}  


	function delete_rec(){
			

			$Id=$this->input->post('Id');
			$sql=$this->db->query("select * from contact where Id='$Id'");
			$arr=$sql->row_array();
				  
				$sql_delete=$this->db->query("delete from contact  where  Id='$Id'");
				print_R($this->db->affected_rows());
	}
   
   
    
}?>