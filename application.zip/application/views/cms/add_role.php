 <?php 
extract($page_data);
?>
<!-- BEGIN PAGE -->  
      <div class="page-content">&nbsp;  
         <!-- BEGIN PAGE CONTAINER-->
         <div class="container-fluid">
            <!-- BEGIN PAGE HEADER-->   
            <div class="row-fluid">
               <div class="span12"> 
                  <h3 class="page-title">
                     Add role                     
                  </h3> 
               </div>
            </div>
            <!-- END PAGE HEADER-->
            <!-- BEGIN PAGE CONTENT-->
            <div class="row-fluid">
               <div class="span12">
                  <!-- BEGIN SAMPLE FORM PORTLET-->   
                  <div class="portlet box blue">
                     <div class="portlet-title">
                        <h4><i class="icon-reorder"></i>Add role</h4>
                        <div class="tools">
                           <a href="javascript:;" class="collapse"></a> 
                           <a href="javascript:;" class="remove"></a>
                        </div>
                     </div>
                     <div class="portlet-body form">
                        <!-- BEGIN FORM-->
                        <form action="<?php echo base_url()?>role/save_role" class="form-horizontal" method="post" enctype="multipart/form-data" />
						<input type="hidden" name="role_id" value="<?php echo $role_id;?>">
                           <div class="control-group">
                              <label class="control-label">Role</label>
                              <div class="controls">
                                 <input type="text" <?php if($type=='view'){?>disabled<?php }?> name="role" class="span6 m-wrap" value="<?php echo $role;?>" /> 
                              </div>
                           </div>
						   <?php  
								$arr=explode(",",$role_rights);
								
								$view="";$add="";$edit="";$delete="";
								
									if(isset($arr[0])){
										$view=$arr[0];
									}
									if(isset($arr[1])){
										$add=$arr[1];
									}
									if(isset($arr[2])){
										$edit=$arr[2];
									}
									if(isset($arr[3])){
										$delete=$arr[3];
									} 
						   ?>
						   <div class="control-group">
                              <label class="control-label">User Rights :</label>
                              <div class="controls"> 
								<label class="control-label">View  :</label>
                                <div class="info-toggle-button">
                                   <input type="checkbox" <?php if($type=='view'){?>disabled<?php }?> name="view" class="toggle" <?php if($view=="on"){?>checked="checked"<?php }?> />
                                </div>
								<label class="control-label">Add  :</label>
                                <div class="warning-toggle-button">
                                   <input type="checkbox" <?php if($type=='view'){?>disabled<?php }?> name="add" class="toggle" <?php if($add=="on"){?>checked="checked"<?php }?> />
                                </div>
								<label class="control-label">Edit  :</label>
                                <div class="success-toggle-button">
                                   <input type="checkbox" <?php if($type=='view'){?>disabled<?php }?> class="toggle" name="edit" <?php if($edit=="on"){?>checked="checked"<?php }?> />
                                </div>
								<label class="control-label">Delete  :</label>
                                <div class="danger-toggle-button">
                                   <input type="checkbox" <?php if($type=='view'){?>disabled<?php }?> class="toggle" name="delete" <?php if($delete=="on"){?>checked="checked"<?php }?> />
                                </div> 
                              </div>
                           </div>
						   <div class="control-group">
                              <label class="control-label">Active</label>
                              <div class="controls">
                                 <select name="active" <?php if($type=='view'){?>disabled<?php }?> class="span6 m-wrap">
									<option value="" selected>Select
									<option <?php if($active=='yes'){?>selected<?php }?> value="yes">Yes
									<option value="no" <?php if($active=='no'){?>selected<?php }?>>No
                                 </select> 
                              </div>
                           </div>
                           <div class="form-actions">
                              <?php if($type!='view'){?><button type="submit" class="btn blue">Save</button><?php }?>
                              <button type="button" class="cancel btn">Cancel</button>
                           </div>
                        </form>
                        <!-- END FORM-->           
                     </div>
                  </div>
                  <!-- END SAMPLE FORM PORTLET-->
               </div>
            </div>
			<script type="text/javascript">
			 $(document).ready(function(){
				$(".cancel").click(function(){

					document.location="<?php echo base_url()?>role/role_view";
				});
			 });	
			</script>
			</div>
            </div>
			</div>
            