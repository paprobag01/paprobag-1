<?php 
 class Filters extends CI_Controller{

		function __Construct(){
		parent::__construct();
		if(!$this->session->userdata('user_id')){
				   redirect("cms/login");
				}
				
               $this->load->library('site_sentry');
			   $this->load->model('cms/filter_model');
			}
      
	  function index(){
		  $data['page']='filters';
		  
		  $arr['table']='filters';
		$arr['where']="where deleted=0";
		$arr['and']="";
		$arr['order_by']=""; 

		  $data['page_data']=$this->site_sentry->get_all($arr); 
		 $this->load->view('cms/header_view', $data);
		 $this->load->view('cms/filters_list');
		 $this->load->view('cms/footer_view');
		
     }
	 function save_filters(){ 
		
		$data['table']="filters"; 
		$this->filter_model->Save_records($data);
		redirect('cms/filters');
	}
	function viewFilters($id=null,$type=null)
	{
		
		  $arr['primary_id']=$id;
		  $arr['table']='filters';
		$arr['where']="";
		$arr['and']="";
		$arr['order_by']="order by filter_id desc";
		  $data['page_data']=$this->site_sentry->PopulateValues($arr); 
		  
		  $data['page']='filters';
		  
		  $data['type']=$type;
		  
		  $arr['table']='categories';
		$arr['where']="where deleted=0";
		$arr['and']="";
		$arr['order_by']=""; 

		  $data['page_data1']=$this->site_sentry->get_all($arr); 
		  
		 $this->load->view('cms/header_view', $data);
		 $this->load->view('cms/add_filter_view', $data);
		 $this->load->view('cms/footer_view', $data);
		 
		 
		
	}
	
	function deleteFilter($id=null)
	{
		$this->db->where('filter_id', $id);	
		$data= array(
		
		'deleted'=>1,
		'created_on'=>date('d-m-Y')
		
		);
		$this->db->update('filters', $data); 
		redirect('cms/filters');
	}
		
	
}
?>