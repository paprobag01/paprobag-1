<?php 
class about_model extends CI_Model{

			function get_all_about(){

			    $sql=$this->db->query("select * from about_us where about_status='Active'");
			    return $sql->result_array();
			
			}
			



}?>		