<?php 
class home_model extends CI_Model{

			

}
?>		