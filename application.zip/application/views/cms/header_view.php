<?php
$profile_pic="";
$profile_pic=$this->session->userdata("profile_pic"); 
//print'<pre>';print_r($this->session->all_userdata());exit;
//print($profile_pic);exit;
?>
<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
   <meta charset="utf-8" />
   <title>Paprobag.com</title>
   <link href="<?php echo base_url()?>admin/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
   <link href="<?php echo base_url()?>admin/css/metro.css" rel="stylesheet" />
   <link href="<?php echo base_url()?>admin/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" />
   <link href="<?php echo base_url()?>admin/bootstrap-fileupload/bootstrap-fileupload.css" rel="stylesheet" />
   <link href="<?php echo base_url()?>admin/font-awesome/css/font-awesome.css" rel="stylesheet" />
   <link href="<?php echo base_url()?>admin/css/style.css" rel="stylesheet" />
   <link href="<?php echo base_url()?>admin/css/style_responsive.css" rel="stylesheet" />
   <link href="<?php echo base_url()?>admin/css/style_default.css" rel="stylesheet" id="style_color" />
   <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>admin/gritter/css/jquery.gritter.css" />
   <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>admin/chosen-bootstrap/chosen/chosen.css" />
   <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>admin/jquery-tags-input/jquery.tagsinput.css" />
   <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>admin/clockface/css/clockface.css" />
   <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>admin/bootstrap-wysihtml5/bootstrap-wysihtml5.css" />
   <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>admin/bootstrap-datepicker/css/datepicker.css" />
   <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>admin/bootstrap-timepicker/compiled/timepicker.css" />
   <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>admin/bootstrap-colorpicker/css/colorpicker.css" />
   <link rel="stylesheet" href="<?php echo base_url()?>admin/bootstrap-toggle-buttons/static/stylesheets/bootstrap-toggle-buttons.css" />
   <link rel="stylesheet" href="<?php echo base_url()?>admin/data-tables/DT_bootstrap.css" />
   <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>admin/bootstrap-daterangepicker/daterangepicker.css" />
   <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>admin/uniform/css/uniform.default.css" />
   <link rel="shortcut icon" href="favicon.ico" />
   <script src="<?php echo base_url()?>admin/js/jquery-1.8.3.min.js"></script>
</head>
<!-- END HEAD -->
<!-- BEGIN BODY -->
<body class="fixed-top">
	<!-- BEGIN HEADER -->
	<div class="header navbar navbar-inverse navbar-fixed-top">
		<!-- BEGIN TOP NAVIGATION BAR -->
		<div class="navbar-inner">
			<div class="container-fluid">
				<!-- BEGIN LOGO -->
				<a class="brand" href="<?php echo base_url()?>index.php/cms/dashboard">
				<!-- <img src="<?php echo base_url()?>images/logo.png" style="height: 70px;margin-top: -32px;" alt="logo" /> -->
				</a>
				<!-- END LOGO -->
				<!-- BEGIN RESPONSIVE MENU TOGGLER -->
				<a href="javascript:;" class="btn-navbar collapsed" data-toggle="collapse" data-target=".nav-collapse">
				<img src="<?php echo base_url()?>admin/img/menu-toggler.png" alt="" />
				</a>          
				<!-- END RESPONSIVE MENU TOGGLER -->				
				<!-- BEGIN TOP NAVIGATION MENU -->					
				<ul class="nav pull-right">					
					<!-- BEGIN USER LOGIN DROPDOWN -->
					<li class="dropdown user">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">
						<!-- <img alt="" src="<?php echo base_url()?>admin/img/avatar1_small.jpg" /> -->
						<span class="username"><?php echo $this->session->userdata('first_name');?></span>
						<i class="icon-angle-down"></i>
						</a>
						<ul class="dropdown-menu">							
							<li><a href="<?php echo base_url()?>index.php/cms/login/logout"><i class="icon-key"></i> Log Out</a></li>
						</ul>
					</li>
					<!-- END USER LOGIN DROPDOWN -->
				</ul>
				<!-- END TOP NAVIGATION MENU -->	
			</div>
		</div>
		<!-- END TOP NAVIGATION BAR -->
	</div>
	<!-- END HEADER -->
	<!-- BEGIN CONTAINER -->
	<div class="page-container row-fluid">
		<!-- BEGIN SIDEBAR -->
		<div class="page-sidebar nav-collapse collapse">
			<!-- BEGIN RESPONSIVE QUICK SEARCH FORM -->
			<div class="slide hide">
				<i class="icon-angle-left"></i>
			</div>
			<!-- <form class="sidebar-search" />
				<div class="input-box">
					<input type="text" class="" placeholder="Search" />
					<input type="button" class="submit" value=" " />
				</div>
			</form> -->
			<div class="clearfix"></div>
			<!-- END RESPONSIVE QUICK SEARCH FORM -->
			<!-- BEGIN SIDEBAR MENU -->
			<ul>
<!-- <li <?php if(isset($page) && $page=="dashboard"){?> class="active"<?php }?>>
					<a href="<?php echo base_url()?>index.php/cms/dashboard">
					<i class="icon-home"></i>Dashboard
					<span class="selected"></span>
					</a>					
				</li> -->
				<!-- <li class="has-sub">
					<a href="javascript:;" <?php if(isset($page) && $page=="users"){?> class="active"<?php }?>>
					<i class="icon-bookmark-empty"></i>Admin
					<span class="arrow"></span>
					</a>
					<ul class="sub">
						<li><a class="" href="ui_general.html">Users</a></li> 
					</ul>
				</li> -->
				<!--<li <?php if(isset($page) && $page=="users"){?> class="active"<?php }?>>
					<a href="<?php echo base_url()?>cms/users">
					<i class="icon-home"></i> Users
					<span class="selected"></span>
					</a>					
				</li> -->
			    <li <?php if(isset($page) && $page=="home_page"){?> class="active"<?php }?>>
				    <a href="<?php echo base_url()?>index.php/cms/home_page">
					<i class="icon-home"></i>Home Page
					<span class="selected"></span>
					</a>					
			    </li>
				<li <?php if(isset($page) && $page=="slider"){?> class="active"<?php }?>>
				    <a href="<?php echo base_url()?>index.php/cms/slider">
					<i class="icon-home"></i> Home Slider
					<span class="selected"></span>
					</a>					
			    </li>
				<li <?php if(isset($page) && $page=="detail"){?> class="active"<?php }?>>
				    <a href="<?php echo base_url()?>index.php/cms/detail">
					<i class="icon-home"></i>Home Page Images
					<span class="selected"></span>
					</a>					
			    </li>
				<li <?php if(isset($page) && $page=="productList"){?> class="active"<?php }?>>
				    <a href="<?php echo base_url()?>index.php/cms/productList">
					<i class="icon-home"></i>Product
					<span class="selected"></span>
					</a>					
			    </li>
				<li <?php if(isset($page) && $page=="categories"){?> class="active"<?php }?>>
				    <a href="<?php echo base_url()?>index.php/cms/categories">
					<i class="icon-home"></i>Categories
					<span class="selected"></span>
					</a>					
			    </li>
				<li <?php if(isset($page) && $page=="subcategories"){?> class="active"<?php }?>>
				    <a href="<?php echo base_url()?>index.php/cms/subcategories">
					<i class="icon-home"></i>Subcategories
					<span class="selected"></span>
					</a>					
			    </li>
			    <li <?php if(isset($page) && $page=="subsubcategories"){?> class="active"<?php }?>>
				    <a href="<?php echo base_url()?>index.php/cms/subSubCategories">
					<i class="icon-home"></i>Sub-Subcategories
					<span class="selected"></span>
					</a>					
			    </li>
				<li <?php if(isset($page) && $page=="customization"){?> class="active"<?php }?>>
				    <a href="<?php echo base_url()?>index.php/cms/customize/listCustomizations">
					<i class="icon-home"></i>Customizations
					<span class="selected"></span>
					</a>					
			    </li>
				<li <?php if(isset($page) && $page=="filters"){?> class="active"<?php }?>>
				    <a href="<?php echo base_url()?>index.php/cms/filters">
					<i class="icon-home"></i>Filters
					<span class="selected"></span>
					</a>					
			    </li>
				
				
				
<!-- <li <?php if(isset($page) && $page=="packages"){?> class="active"<?php }?>>
				    <a href="<?php echo base_url()?>index.php/cms/packages">
					<i class="icon-home"></i>Packages Description
					<span class="selected"></span>
					</a>					
			    </li>
				<li <?php if(isset($page) && $page=="domestic"){?> class="active"<?php }?>>
				    <a href="<?php echo base_url()?>index.php/cms/domestic">
					<i class="icon-home"></i>Domestic Package
					<span class="selected"></span>
					</a>					
			    </li>
				 <li <?php if(isset($page) && $page=="international"){?> class="active"<?php }?>>
				    <a href="<?php echo base_url()?>index.php/cms/international">
					<i class="icon-home"></i>International Pakage
					<span class="selected"></span>
					</a>					
			    </li>
				<li <?php if(isset($page) && $page=="honeymoon"){?> class="active"<?php }?>>
				    <a href="<?php echo base_url()?>index.php/cms/honeymoon">
					<i class="icon-home"></i>Honeymoon Pakage
					<span class="selected"></span>
					</a>					
			    </li>
				<li <?php if(isset($page) && $page=="deals"){?> class="active"<?php }?>>
				    <a href="<?php echo base_url()?>index.php/cms/deals">
					<i class="icon-home"></i>Best Deals Pakage
					<span class="selected"></span>
					</a>					
			    </li>
				
				<li <?php if(isset($page) && $page=="service"){?> class="active"<?php }?>>
				    <a href="<?php echo base_url()?>index.php/cms/service">
					<i class="icon-home"></i>Our Services
					<span class="selected"></span>
					</a>					
			    </li>
				
			
				<li <?php if(isset($page) && $page=="gallery"){?> class="active"<?php }?>>
				    <a href="<?php echo base_url()?>index.php/cms/gallery">
					<i class="icon-home"></i>Gallery
					<span class="selected"></span>
					</a>					
			    </li>
				<li <?php if(isset($page) && $page=="about_us"){?> class="active"<?php }?>>
				    <a href="<?php echo base_url()?>index.php/cms/about_us">
					<i class="icon-home"></i>About Us
					<span class="selected"></span>
					</a>					
			    </li>
				<li <?php if(isset($page) && $page=="contact_us"){?> class="active"<?php }?>>
				    <a href="<?php echo base_url()?>index.php/cms/contact_us">
					<i class="icon-home"></i>feedback
					<span class="selected"></span>
					</a>					
			    </li> -->
				<!-- <li <?php if(isset($page) && $page=="feedback"){?> class="active"<?php }?>>
				    <a href="<?php echo base_url()?>index.php/cms/feedback">
					<i class="icon-home"></i>Feedback View
					<span class="selected"></span>
					</a>					
			    </li>  -->
			</ul>
			<!-- END SIDEBAR MENU -->
		</div>
		<!-- END SIDEBAR -->