<?php 
if(isset($page_data3))
{
extract($page_data3);
}

?>
<section>
<div class="container text-center" style="margin-top:2%">
<?php if(isset($prodType)){?>
<?php }else{?>
<h3><?php echo $category_name; ?></h3>
<?php }?>
</div>
</section>
<style>
.button
{
padding: 5px 15px;
text-decoration: none;
background: #333;
color: #F3F3F3;
font-size: 13PX;
border-radius: 2PX;
margin: 0 4PX;
display: block;
float: left;
}
.cart-total{ background:#E8E8E8}

.shopp,.cart-total{ 
	border:solid #ccc 1px; padding:8px; 
	-webkit-border-radius: 8px;
	-moz-border-radius: 8px; font-size:12px;
	background:url(remove.png) center right no-repeat 5px;
	border-radius: 8px; 
	font-family:"LubalGraphBdBTBold",Tahoma; 
	margin-bottom:3px;
	width:260px;
	}
	
div.shopp span{  }	
div.shopp div.label1{ width:242px; font-size:100%; }		
div.shopp div.shopp-price{ width:70px; }
.quantity{ float:left; margin-top:-3px; width:20px;}
img.removeProd{float:right;cursor:pointer;}
.cart-total b{width:130px;}
</style>
<section class="main-content-wrap">
					<div class="container">
						<div class="row">
						<div class="col-sm-2" style="border-right:1px solid #f9ac20; height:100%;">
						
								
								<div class="featured-box featured-box-secondary">
								<?php if(isset($prodType)){?>
								<?php }else{?>
								<h4><?php echo $category_name;?></h4>
								<?php } if(isset($prodType))
									{ ?>
									
										<?php foreach($page_data8 as $row) { ?>
										
										<h4><a href=""><?php echo $row['category_name']?></a></h4>
										<?php for ($i=0;$i<count($page_data9);$i++){
											?>
											<ul style="list-style:none;font-size:14px;margin-left:-40px">
											<?php  
											foreach($page_data9[$i] as $row1)
											{
												if($row['cat_id']==$row1['cat_id'])
												{
										?>
											
												<li><input type="checkbox" class="subcatChkBox" onclick="ShowHide<?php echo $prodType; ?><?php echo $row1['sub_cat_id']?>()" id="subcat<?php echo $row1['sub_cat_id']?>"/> <?php echo $row1['sub_cat_name'];?></li>
												
											<script>
											function ShowHide<?php echo $prodType; ?><?php echo $row1['sub_cat_id']?>()
													{
													
													if($("#subcat<?php echo $row1['sub_cat_id']?>").is(':checked'))
													{
													$(".tabprod").fadeOut();
													$(".prodbysubcat<?php echo $prodType.$row1['sub_cat_id']?>").fadeIn();
													}
													else {
													$(".tabprod").fadeIn();
												
												    }
												
													}
											</script>
										<?php } } ?>
										 </ul>
										<?php
										}?>
										
										<?php }?>
									
									<?php }
									else {
									//echo $ProdType
										?>
									<ul class="text-left" style="list-style:none;font-size:14px;margin-left:-40px">
									<?php
									
										$i=0;
									foreach ($page_data1 as $row){?>
										<li style="margin-top:20px"><input type="checkbox" class="subcatChkBox" onclick="ShowHide<?php echo $row['sub_cat_id']?>()" id="subcat<?php echo $row['sub_cat_id']?>"/> <?php echo $row['sub_cat_name']?></li>
										<?php if(isset($ProdType) && $ProdType=="custm"){?>
										<li>
											<ul style="list-style:none;font-size:14px;margin-left:-20px">
											<?php foreach ($page_data10 as $row){ ?>
												<li style="margin-top:10px"><input type="checkbox" class="subcatChkBox1" onclick="ShowHide<?php echo $row['sub_cat_id'].$row['sub_sub_cat_id']?>()" id="subcat<?php echo $row['sub_sub_cat_id']?>"/> <?php echo $row['sub_sub_cat_name']?></li>
											<?php }?>
											</ul>
										</li>
										<?php }?>
										<script>
										
										function ShowHide<?php echo $row['sub_cat_id']?>()
										{
									//	alert("--");
										
											//$("#categoryId1").show();data("target")).hide()
											if($("#subcat<?php echo $row['sub_cat_id']?>").is(':checked'))
											{
											//
											$(".AllProducts<?php echo $ProdType?>").fadeOut();
											$(".prod_bysubcat<?php echo $row['sub_cat_id']?>").fadeIn();
											//$(".filterpagination<?php echo $i?>").fadeIn();
											
											}
											else
											{
												
												
													$(".AllProducts<?php echo $ProdType?>").fadeIn();
												//	$(".filterpagination<?php echo $i?>").fadeOut();
												
												
											}
										}
										<?php if($ProdType=="custm"){?>
										function ShowHide<?php echo $row['sub_cat_id'].$row['sub_sub_cat_id']?>()
												{
												//alert("--");
												}
										<?php }?>
										</script>
										<?php $i++;  }?>
									</ul>
									
									<ul class="text-left" style="list-style:none;font-size:14px;margin-left:-40px">
									<?php foreach($page_data6 as $row){ 
									if($row['category_name']!=$category_name)
									{
										?>
									<li><h4><a href="<?php echo base_url() ?>products/getProducts/<?php echo $row['cat_id']?>/<?php echo $ProdType?>"><?php echo $row['category_name']?></a></h4></li>
									<?php
									} 
									}?>
									</ul>
									<?php }?>
								</div>
								
						</div>
							<?php if(isset($prodType)){?>
							<div class="tab-content col-md-10" style="">
							<ul class="nav1 nav-tabs1 grid-tabs text-center" role="tablist" style="margin-bottom:40px;">
								<li style="width:149px" <?php if($prodType==1){ ?>class="active"<?php }?> ><a id="retail1" href="<?php echo base_url()?>products/getProducts/readyToDeliver/1" <?php if($prodType==1){?>style="border-bottom:2px solid #DD4E4E"<?php } else{?>style="border-bottom:2px solid #000" <?php }?>>Retail</a></li>
								<li style="width:150px"  <?php if($prodType==2){ ?>class="active"<?php }?>><a id="outerwear1" href="<?php echo base_url()?>products/getProducts/readyToDeliver/2" <?php if($prodType==2){?>style="width:149px;border-top:2px solid #DD4E4E; border-left:1px solid #000;border-right:1px solid #000;border-bottom-color:transparent;"<?php } else{ ?>style="width:149px;border-top:2px solid #000; border-left:1px solid #000;border-right:1px solid #000;border-bottom-color:transparent;"<?php }?>>Offers</a></li>
								<li style="width:149px" <?php if($prodType==3){ ?>class="active"<?php }?>><a id="suits1" href="<?php echo base_url()?>products/getProducts/readyToDeliver/3" <?php if($prodType==3){?>style="border-bottom:2px solid #DD4E4E"<?php } else{?>style="border-bottom:2px solid #000" <?php }?>>Wholesale</a></li>
								
							</ul>
							<script>
							$(document).ready(function() {

    $("#retail1").click(function(){

       $("#outerwear1").css("border-top-color","#000");
    });
$("#suits1").click(function(){

       $("#outerwear1").css("border-top-color","#000");
    });
$("#outerwear1").click(function(){

       $("#outerwear1").css("border-top-color","#dd4e4e");
    });
  
});
							</script>
							
								<div class="tab-pane col-md-12 prodpanel <?php if($prodType==1){?>active<?php }?>" id="tshirt">
								
									
									
										
										<?php 
									foreach($page_data as $row)
									{
										if($row['ready_to_deliver_tabs']==1)
										{
									?>
										<div class="col-xs-6 col-sm-3 tabprod prodbysubcat<?php echo $row['ready_to_deliver_tabs']?><?php echo $row['prod_sub_categories']?>">
											<div class="thumb-item">
												<div class="thumb-item-img">
													<a href="<?php echo base_url()?>productDetails/getDetails/<?php echo $row['prod_id'] ?>" class="btn-detail">
														<img class="img-responsive" src="<?php echo base_url().$row['prod_image'] ?>" alt="" style="
    
    background-color: rgba(0,0,0,.5);">
														<img class="img-responsive" src="<?php echo base_url().$row['prod_image'] ?>" alt="">
													</a>
													<span class="thumb-act thumb-act-first">
														<a href="#" class="btn-cart"><i class="fa fa-shopping-cart"></i></a>
														<!-- <a data-target="#quickview-detail" data-toggle="modal" href="javascript:void(0);"><i class="fa fa-eye"></i></a>
														<a href="#"><i class="fa fa-heart-o"></i></a>
														<a href="#"><i class="fa fa-exchange"></i></a>  -->
													</span>
												</div>
												<div class="thumb-item-content">
													<div class="star-rating pull-right" title="Rated 5.00 out of 5">
														<span style="width:100%"><strong class="rating">5.00</strong> out of 5</span>
													</div> 
													<h3><a href="#"><?php echo $row['prod_name']?></a></h3>
													
													 <p class="product-cat"><a href="#">Bags</a>, <a href="#">Accessories</a></p>
													<p class="product-price"><ins>Rs.<?php echo $row['prod_price']?></ins></p>
												</div>
											</div>
										</div>
									<?php 
										}
									}
									?>
								
									
									
									
								</div>
								
								<div class="tab-pane col-md-12 prodpanel <?php if($prodType==2){?>active<?php }?>" id="outerwaer">
							
									<?php 
									foreach($page_data as $row)
									{
										if($row['ready_to_deliver_tabs']==2)
										{
									?>
										<div class="col-xs-6 col-sm-3">
											<div class="thumb-item">
												<div class="thumb-item-img">
													<a href="<?php echo base_url()?>productDetails/getDetails/<?php echo $row['prod_id'] ?>" class="btn-detail">
														<img class="img-responsive" src="<?php echo base_url().$row['prod_image'] ?>" alt="">
														<img class="img-responsive" src="<?php echo base_url().$row['prod_image'] ?>" alt="">
													</a>
													<span class="thumb-act thumb-act-first">
														<a href="#" class="btn-cart"><i class="fa fa-shopping-cart"></i></a>
														<!-- <a data-target="#quickview-detail" data-toggle="modal" href="javascript:void(0);"><i class="fa fa-eye"></i></a>
														<a href="#"><i class="fa fa-heart-o"></i></a>
														<a href="#"><i class="fa fa-exchange"></i></a> -->
													</span>
												</div>
												<div class="thumb-item-content">
													<div class="star-rating pull-right" title="Rated 5.00 out of 5">
														<span style="width:100%"><strong class="rating">5.00</strong> out of 5</span>
													</div> 
													<h3><a href="#"><?php echo $row['prod_name']?></a></h3>
													
													 <p class="product-cat"><a href="#">Bags</a>, <a href="#">Accessories</a></p>
													<p class="product-price"><ins>Rs.<?php echo $row['prod_price']?></ins></p>
												</div>
											</div>
										</div>
									<?php 
										}
									}
									?>
									
								
								</div>
								<div class="tab-pane col-md-12 prodpanel <?php if($prodType==3){?>active<?php }?>" id="suits">
							
									<?php 
									foreach($page_data as $row)
									{
										if($row['ready_to_deliver_tabs']==3)
										{
									?>
										<div class="col-xs-6 col-sm-3">
											<div class="thumb-item">
												<div class="thumb-item-img">
													<a href="<?php echo base_url()?>productDetails/getDetails/<?php echo $row['prod_id'] ?>" class="btn-detail">
														<img class="img-responsive" src="<?php echo base_url().$row['prod_image'] ?>" alt="">
														<img class="img-responsive" src="<?php echo base_url().$row['prod_image'] ?>" alt="">
													</a>
													<span class="thumb-act thumb-act-first">
														<a href="#" class="btn-cart"><i class="fa fa-shopping-cart"></i></a>
														<!-- <a data-target="#quickview-detail" data-toggle="modal" href="javascript:void(0);"><i class="fa fa-eye"></i></a>
														<a href="#"><i class="fa fa-heart-o"></i></a>
														<a href="#"><i class="fa fa-exchange"></i></a>  -->
													</span>
												</div>
												<div class="thumb-item-content">
													<div class="star-rating pull-right" title="Rated 5.00 out of 5">
														<span style="width:100%"><strong class="rating">5.00</strong> out of 5</span>
													</div> 
													<h3><a href="#"><?php echo $row['prod_name']?></a></h3>
													 
													 <p class="product-cat"><a href="#">Bags</a>, <a href="#">Accessories</a></p>
													<p class="product-price"><ins>Rs.<?php echo $row['prod_price']?></ins></p>
												</div>
											</div>
										</div>
									<?php 
										}
									}
									?>
									
								
								</div>
								
							</div>
							<?php }else{
								
								?>		
						
						<?php if($ProdType=="custm")
								{ ?>
								<div class="col-md-10"  id="AllProducts<?php echo $ProdType?>">
							<div class="col-md-12" style="border-bottom:1px solid #eed">
							<div class="row">
							<?php 
							//echo $ProdType;
							
								$i=1;
								//print_r($page_data);
								foreach ($page_data as $row) {?>
						<div class="col-md-6 AllProducts<?php echo $ProdType?>  prod_bysubcat<?php echo $row['prod_sub_categories']?>" style="padding:10px;">
									<div class="row" style="border-right:1px solid #eed; margin:10px;">
										<div class="col-xs-5">
											<div class="thumb-item-img">
												<a href="<?php echo base_url()?>productDetails/getDetails/<?php echo $row['prod_id'] ?>" class="btn-detail">
													<img class="img-responsive" src="<?php echo base_url().$row['prod_image']?>" alt="">
													<img class="img-responsive" src="<?php echo base_url().$row['prod_image']?>" alt="">
												</a>
											</div>
										</div>
										<div class="col-xs-7">
											<div class="thumb-item-content">
												<h3><a href="<?php echo base_url()?>productDetails/getDetails/<?php echo $row['prod_id'] ?>"><?php echo $row['prod_name']?></a></h3>
												<ul class="list-review">
													<p class="product-price"><ins><?php echo $row['prod_price']?></ins></p>
													
													<li class="btn-add-review"><a href="#">Add Your Review</a></li>
												</ul>
												
												<p>Nam ullamcorper neque non erat elementum vulputate. Nullam dignissim lobortis interdum. Donec nisi est, tempus eget. Nam ullamcorper neque non erat elementum vulputate. Nullam dignissim lobortis interdum.</p>
												<p class="thumb-act thumb-act-more">
													<!--  <a href="#" class="btn-customize"><i class="fa fa-shopping-cart"></i> <span>Add to Cart</span></a> -->
													
													<a href="#" class="full-detail"><span>View Full detail</span></a>
													<a href="#" class="btn-customize"><i class="fa fa-cogs"></i><span>Customize</span></a>
													
												</p>
											</div>
										</div>
									</div>
								</div>
								<?php 
									if($i%2==0)
									{
										?>
										</div>
										<div class="row">
										<?php 
										}
										$i++;
								 } ?>
								
							</div>
							
								<?php if(isset($prodType)){?>
								<?php } else{?>
								<div class="pagination-wrap">
									<div class="row">
										<div class="col-xs-7">
											<?php 
					
										echo "<ul class='pagination'>";
		for($i=1;$i<=$total;$i++)
		{
			if($i==$pagid) { echo "<li class='active'><a href='?pagid=".$i."'>".$i."</a></li>"; }
			
			else { echo "<li><a href='?pagid=".$i."'>".$i."</a></li>"; }
		}
echo "</ul>";
										?>
											
										   <?php 
										if($pagid>1)
										{
											

	echo "<a href='?pagid=".($pagid-1)."' class='btn btn-lightdark' style='margin-top:-60px'>PREVIOUS</a>";
	
}
if($pagid!=$total && $total!=0)
{
	//echo $total;
	echo "<a href='?pagid=".($pagid+1)."' class='btn btn-lightdark' style='margin-top:-60px'>NEXT</a>";
}
?>
									   </div>
									   <div class="col-xs-5 text-right">
											<p>Showing <?php echo $pagid;?>-<?php echo $total?> of <?php echo $limit;?> results</p>
									   </div>
									</div>
								</div>
								<?php }?>
								</div>	
								</div>
							<?php }else {?>
						
						<div class="col-md-10"  id="AllProducts<?php echo $ProdType?>">
							<div class="col-md-12" id="categoryId1">
								<div class="row">
									
								<?php
								//echo $page_data2[0][1];
								for($i=0;$i<sizeof($page_data2);$i++){
									if(isset($page_data2[$i]))
									{
									for($j=0;$j<sizeof($page_data2[$i]);$j++)
									{
									if(isset($page_data2[$i][$j]))
									{
								?>
								
								
								
								<div class="col-xs-6 col-sm-3 AllProducts<?php echo $ProdType?> prod_bysubcat<?php echo $page_data2[$i][$j]['prod_sub_categories']?>" data-target="prod_bysubcat<?php echo $page_data2[$i][$j]['prod_sub_categories']?>">
										<div class="thumb-item">
											<div class="thumb-item-img">
												<a href="<?php echo base_url()?>productDetails/getDetails/<?php echo $page_data2[$i][$j]['prod_id'] ?>" class="btn-detail">
													<img class="img-responsive" src="<?php echo base_url().$page_data2[$i][$j]['prod_image']?>" alt="">
													<img class="img-responsive" src="<?php echo base_url().$page_data2[$i][$j]['prod_image']?>" alt="">
												</a>
												<span class="thumb-act thumb-act-first">
													<a href="#" class="btn-cart"><i class="fa fa-shopping-cart"></i></a>
													<!--<a data-target="#quickview-detail" data-toggle="modal" href="javascript:void(0);"><i class="fa fa-eye"></i></a>
													<a href="#"><i class="fa fa-heart-o"></i></a>
													<a href="#"><i class="fa fa-exchange"></i></a>-->
												</span>
											</div>
											<div class="thumb-item-content">
												<div class="star-rating pull-right" title="Rated 5.00 out of 5">
													<span style="width:100%"><strong class="rating">5.00</strong> out of 5</span>
												</div>
												<h3><a href="<?php echo base_url()?>productDetails/getDetails/<?php echo $page_data2[$i][$j]['prod_id'] ?>"><?php echo $page_data2[$i][$j]['prod_name']?></a></h3>
												<p class="product-cat"><a href="#">Bags</a>, <a href="#">Accessories</a></p>
												<p class="product-price"><ins><?php echo $page_data2[$i][$j]['prod_price']?></ins></p>
											</div>
										</div>
									
									
									</div>
									
								
								<?php } }
									}}?>
								</div>
								<?php if(isset($prodType)){?>
								<?php } else{?>
								<div class="pagination-wrap">
									<div class="row">
										<div class="col-xs-7">
											<?php 
					
										echo "<ul class='pagination'>";
		for($i=1;$i<=$total;$i++)
		{
			if($i==$pagid) { echo "<li class='active'><a href='?pagid=".$i."'>".$i."</a></li>"; }
			
			else { echo "<li><a href='?pagid=".$i."'>".$i."</a></li>"; }
		}
echo "</ul>";
										?>
											
										   <?php 
										if($pagid>1)
										{
											

	echo "<a href='?pagid=".($pagid-1)."' class='btn btn-lightdark' style='margin-top:-60px'>PREVIOUS</a>";
	
}
if($pagid!=$total && $total!=0)
{
	//echo $total;
	echo "<a href='?pagid=".($pagid+1)."' class='btn btn-lightdark' style='margin-top:-60px'>NEXT</a>";
}
?>
									   </div>
									   <div class="col-xs-5 text-right">
											<p>Showing <?php echo $pagid;?>-<?php echo $total?> of <?php echo $limit;?> results</p>
									   </div>
									</div>
								</div>
								<?php }?>
								</div>
								</div>
								
								
								
								<?php }?>
								<?php for($j=0;$j<sizeof($pagid2);$j++){?>
									<div class="pagination-wrap filterpagination<?php echo $j?>" style="display:none;">
									<div class="row">
										<div class="col-xs-7">
											<?php 
					
										echo "<ul class='pagination'>";
		for($i=1;$i<=$total2[$j];$i++)
		{
			if($i==$pagid2[$j]) { echo "<li class='active'><a href='?pagid=".$i."'>".$i."</a></li>"; }
			
			else { echo "<li><a href='?pagid=".$i."'>".$i."</a></li>"; }
		}
echo "</ul>";
										?>
											
										   <?php 
										if($pagid2[$j]>1)
										{
											

	echo "<a href='?pagid=".($pagid2[$j]-1)."' class='btn btn-lightdark' style='margin-top:-60px'>PREVIOUS</a>";
	
}
if($pagid2[$j]!=$total2[$j])
{
	
	echo "<a href='?pagid=".($pagid2[$j]+1)."' class='btn btn-lightdark' style='margin-top:-60px'>NEXT</a>";
}
?>
									   </div>
									   <div class="col-xs-5 text-right">
											<p>Showing <?php echo $pagid2[$j];?>-<?php $total2[$j]?> of <?php echo $limit2[$j];?> results</p>
									   </div>
									</div>
								</div>
							<?php }?>
							
							
							<?php }?>
						</div>
					</div>
				</section>