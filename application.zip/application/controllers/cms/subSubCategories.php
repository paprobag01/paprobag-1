<?php 
 class SubSubCategories extends CI_Controller{

		function __Construct(){
		parent::__construct();
		if(!$this->session->userdata('user_id')){
				   redirect("cms/login");
				}
				
               $this->load->library('site_sentry');
			    $this->load->model('cms/subSubcategories_model');
			}
      
	  function index(){
		  $data['page']='subsubcategories';
		  $arr['table']='sub_subcategories';
		  $arr['where']="where deleted=0";//
		  $arr['and']="";
		  $arr['order_by']="";
		$arr1['table']='categories';
		$arr1['where']="where deleted=0";//
		$arr1['and']="";
		$arr1['order_by']="";
		$arr1['fields']="cat_id, category_name";
		  $data['page_data']=$this->site_sentry->get_all($arr); 
		  $data['page_data1']=$this->subSubcategories_model->getCategories($arr1);
		  
		 
		 
		 // print_r($data['page_data1']); die;
		 $this->load->view('cms/header_view', $data);
		 $this->load->view('cms/sub_subcategories_list');
		 $this->load->view('cms/footer_view');
		
     }
	 function add_sub_subcategories($id=null, $type=null)
	 {
		 $data['page']='subsubcategories';
		 $arr['primary_id']=$id;
		  $arr['table']='sub_subcategories';
		$arr['where']="where deleted=0";
		$arr['and']="";
		$arr['order_by']=""; 
		$data['page_data']=$this->site_sentry->PopulateValues($arr);
		
		$subcatid=$data['page_data']['sub_cat_id'];
		//echo $subcatid;die;
		$arr1['table']='categories';
		
		$arr1['and']="";
		$arr1['order_by']="";
		$arr1['fields']="cat_id, category_name";
		
			$arr2['table']='subcategories';
			$arr2['and']="";
			$arr2['order_by']="";
			$arr2['fields']="sub_cat_id, sub_cat_name";
			$arr2['where']="where deleted=0";
		  $data['page_data3']=$this->subSubcategories_model->getCategories($arr2); 
		  
		  $arr3['table']='subcategories';
		  $arr3['and']="";
		  $arr3['order_by']="";
		  $arr3['primary_id']=$subcatid;
		
		  $data['page_data4']=$this->site_sentry->PopulateValues($arr3);
		 
		 $cat_id=$data['page_data4']['cat_id'];
		 
		 // print_r($data['page_data3']);die;
		  if($id!="")
		  {
		  	$arr1['primary_id']=$cat_id;
		 // $arr1['where']="where cat_id=$cat_id";
			  $data['page_data1']=$this->site_sentry->PopulateValues($arr1);
			  $arr1['where']="";
			  
			  
			  $arr4['table']='categories';
			  $arr4['and']="";
			  $arr4['order_by']="";
			  $arr4['fields']="cat_id, category_name";
			  $arr4['where']="where deleted=0";
			$data['page_data2']=$this->subSubcategories_model->getCategories($arr4);
			
		  }
		  else
		  {
			$arr1['where']="";
			$data['page_data2']=$this->subSubcategories_model->getCategories($arr1);
		  }
		  
		 
		 

		  $data['type']=$type;
		  //print_r($data['page_data']); die;
		 $this->load->view('cms/header_view', $data);
		 $this->load->view('cms/add_sub_subcategories_view', $data);
		 $this->load->view('cms/footer_view', $data);
	 }
	 function save_sub_subcategories()
	 {
		 $id=$this->input->post('sub_sub_cat_id');
		 $data['table']="sub_subcategories"; 
		$this->site_sentry->Save_records($data);
		redirect('cms/subSubCategories/add_sub_subcategories/'.$id.'');
	 }
	 function deleteSubCategory($id=null)
	 {
		 $this->db->where('sub_cat_id', $id);	
		$data= array(
		
		'deleted'=>1,
		'created_on'=>date('d-m-Y')
		
		);
		$this->db->update('sub_subcategories', $data); 
		redirect('cms/subcategories');
	 }
	
		
	
}
?>