<?php
class home_page extends CI_Controller{
	
	function __Construct(){

		parent::__construct();
		if(!$this->session->userdata('user_id')){
				   redirect("cms/login");
				}
		$this->load->library('site_sentry');
		//$this->load->model('contact_model');
	}

	function index(){

		$data['page']='home_page';
		
		$arr['table']='home_details';
		$arr['where']="";
		$arr['and']="";
		$arr['order_by']="order by id desc"; 
		$data['page_data']=$this->site_sentry->get_all($arr); 
		$this->load->view('cms/header_view',$data);
		$this->load->view('cms/home_page_view',$data);
		$this->load->view('cms/footer_view',$data);
	
	}

	 function home_page_view(){

		$data['page']='home_page';
		
		$arr['table']='home_details';
		$arr['where']="";
		$arr['and']="";
		$arr['order_by']="order by id desc"; 
		$data['page_data']=$this->site_sentry->get_all($arr); 
		$this->load->view('cms/header_view',$data);
		$this->load->view('cms/home_page_view',$data);
		$this->load->view('cms/footer_view',$data);
	}
	

	 function save_home_page(){ 
		
		$data['table']="home_details"; 
		$this->site_sentry->Save_records($data);
		redirect('cms/home_page/home_page_view');
	}

	function add_home_page($id=null,$type=null){ 

		$data['primary_id']=$id;
		$data['table']="home_details";
		$arr['page_data']=$this->site_sentry->PopulateValues($data); 
		$arr['page']="home_page";
	/*	$role['table']='roles';
		$role['where']="where active='yes'";
		$role['and']="";
		$role['order_by']="order by role_id desc";
		$arr['role_arr']=$this->site_sentry->get_all($role); */
		
		$arr['type']=$type;

		$this->load->view('cms/header_view',$arr);
		$this->load->view('cms/add_home_page',$arr);
		$this->load->view('cms/footer_view',$arr);

	}  


	function delete_rec(){
			

			$id=$this->input->post('id');
			$sql=$this->db->query("select * from home_details where id='$id'");
			$arr=$sql->row_array();
				  
				$sql_delete=$this->db->query("delete from home_details  where  id='$id'");
				print_R($this->db->affected_rows());
	}
   
   
    
}?>