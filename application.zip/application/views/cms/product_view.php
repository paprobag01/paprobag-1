<?php
if(isset($page_data2))
{
extract($page_data2);
} 
//print_r($page_data2);die;
?>
	<div class="page-content">
		<div class="container-fluid">
		<div class="row-fluid">
			<div class="span12">
				<!-- BEGIN STYLE CUSTOMIZER--> 
				<h3 class="page-title">
					Add Product Details<small></small>
					</h3>
					
				
			</div>
		</div>
			<div class="row-fluid">
				
				<div class="col-md-12">
					<!-- BEGIN PAGE TITLE & BREADCRUMB-->
					
					<!-- END PAGE TITLE & BREADCRUMB-->
				</div>
			</div>
			<!-- END PAGE HEADER-->
			<!-- BEGIN PAGE CONTENT-->
			<div class="row-fluid">
				<div class="span12">
					<div class="tabbable tabbable-custom boxless tabbable-reversed">
						<ul class="nav nav-tabs">
							<li class="active">
								<a href="#tab_0" data-toggle="tab">
									 General
								</a>
							</li>
							<li>
								<a href="#tab_1" data-toggle="tab">
									 Price
								</a>
							</li>
							<li>
								<a href="#tab_2" data-toggle="tab">
									 Images
								</a>
							</li>
							<!--<li>
								<a href="#tab_3" data-toggle="tab">
									 2 Columns View Only
								</a>
							</li>
							<li>
								<a href="#tab_4" data-toggle="tab">
									 Row Seperated
								</a>
							</li>
							<li>
								<a href="#tab_5" data-toggle="tab">
									 Bordered
								</a>
							</li>
							<li>
								<a href="#tab_6" data-toggle="tab">
									 Row Stripped
								</a>
							</li>
							<li>
								<a href="#tab_7" data-toggle="tab">
									 Label Stripped
								</a>
							</li> 
							<li>
								
									
							
							</li>-->
						</ul>
						<form action="<?php echo base_url()?>cms/productList/save_products" class="" method="post" enctype="multipart/form-data" />
						<div class="tab-content">
						
							<div class="tab-pane active" id="tab_0">
								<div class="portlet box blue">
									<div class="portlet-title">
										<div class="caption">
											<i class="fa fa-reorder"></i>Product Details
										
										<div class="tools">
											<a href="javascript:;" class="collapse">
											</a>
											<a href="#portlet-config" data-toggle="modal" class="config">
											</a>
											<a href="javascript:;" class="reload">
											</a>
											<a href="javascript:;" class="remove">
											</a>
										</div>
										</div>
									</div>
									
									<div class="portlet-body form form-horizontal">
										<!-- BEGIN FORM-->
										
										<input type="hidden" value="<?php echo $prod_id;?>" name="prod_id"/>
										<input type="hidden" value="<?php echo $created_on;?>" name="created_on" value="<?php echo date('d-m-Y')?>"/>
											<div class="form-body">
												<div class="control-group">
													<label class="control-label">Product Name</label>
													    <div class="controls">
															<input type="text" name="prod_name" id="prod_name" <?php if($type=='view'){?>disabled<?php }?> value="<?php echo $prod_name;?>" class="span4 m-wrap"> 
													    </div>
												</div>
												<div class="control-group">
												  <label class="control-label">Meta Title</label>
													  <div class="controls">
														<textarea name="prod_meta_title" id="prod_meta_title" <?php if($type=='view'){?>disabled<?php }?> class="span12 m-wrap"><?php echo $prod_meta_title;?></textarea>
													  </div>
												</div>
												<div class="control-group">
												  <label class="control-label">Meta Keywords</label>
													  <div class="controls">
														<textarea name="prod_meta_keyword" id="prod_meta_keyword" <?php if($type=='view'){?>disabled<?php }?> class="span12 m-wrap"><?php echo $prod_meta_keyword;?></textarea>
													  </div>
												</div>
												<div class="control-group">
												  <label class="control-label">Meta Description</label>
												  <div class="controls">
													 <textarea name="prod_meta_description" id="prod_meta_description" <?php if($type=='view'){?>disabled<?php }?>  class="span12 m-wrap"><?php echo $prod_meta_description;?></textarea>
												   </div>
											   </div>
											   
											 <div class="control-group">
												  <label class="control-label">Product Description</label>
												  <div class="controls">
													 <textarea  name="prod_description" id="prod_description" <?php if($type=='view'){?>disabled<?php }?>  class="span12 ckeditor  m-wrap" cols="30" rows="10"><?php echo $prod_description;?> </textarea> 
													 
												  </div>
											</div>
											
											<div class="control-group">
											  <label class="control-label">Categories</label>
											  <div class="controls">
											  <select name="cat_id" id="cat_id" onchange="getFilters()" <?php if($type=='view'){?>disabled<?php }?>>
												<?php if($type=='edit'||$type=='view') {?>
												<option value="<?php echo $cat_id;?>" selected=""><?php echo $category_name; ?></option>
												<?php }?>
											  
											  <?php foreach($page_data1 as $cat){
												  if($cat_id!=$cat['cat_id'])
												  {
												  ?>
											  <option value="<?php echo $cat['cat_id'];?>"><?php echo $cat['category_name'];?></option>
												<?php }}
												?>
											  </select>
											  </div>
								
											</div>
											<div class="control-group" id="subcategories" style="display:none;">
											  
											</div>
											<div class="control-group" id="filters" style="display:none;">
											  
											</div>
											<div class="control-group" id="filterValues" style="display:none;">
											  
											</div>
											<div class="control-group">
											<label class="control-label">Sub-Subcategories</label>
											<div class="controls">
											  <select name="sub_sub_cat_id" id="sub_sub_cat_id" <?php if($type=='view'){?>disabled<?php }?>>
											  <?php if($sub_sub_cat_id!=""){?>
												<option value="<?php echo $sub_sub_cat_id;?>"><?php echo $sub_sub_cat_name;?></option>
												<?php }else{?>
												<option>Select</option>
												<?php } foreach ($page_data3 as $row){
													if($sub_sub_cat_id!=$row['sub_sub_cat_id'])
													{
												?>
												<option value="<?php echo $sub_sub_cat_id; ?>"><?php echo $row['sub_sub_cat_name'];?></option>
												<?php } }?>
											  </select>
											  </div>
											  </div>
											<div class="control-group">
													<label class="control-label">Product Sku</label>
													    <div class="controls">
															<input type="text" name="prod_sku" id="prod_sku" <?php if($type=='view'){?>disabled<?php }?> value="<?php echo $prod_sku;?>" class="span4 m-wrap"> 
													    </div>
												</div>
												<div class="control-group">
													<label class="control-label">Product Status</label>
													    <div class="controls">
															<select name="prod_status" id="prod_status">
																<option value="0">Enable</option>
																<option value="1">Disable</option>
															</select>
													    </div>
												</div>
												<div class="control-group">
													<label class="control-label">Product On Home</label>
													    <div class="controls">
															<select name="prod_on_home" id="prod_on_home">
																<option value="0">Yes</option>
																<option value="1">No</option>
															</select>
													    </div>
												</div>
												<div class="control-group">
													<label class="control-label">Ready To Print</label>
													    <div class="controls">
															<select name="ready_to_print" id="ready_to_print">
																<option value="0">Yes</option>
																<option value="1">No</option>
															</select>
													    </div>
												</div>
												<div class="control-group">
													<label class="control-label">Ready To Deliver</label>
													    <div class="controls">
														<?php
														$tab="";
														if($ready_to_deliver_tabs==1)
														{
															$tab1="Retail";
														}
														if($ready_to_deliver_tabs==2)
														{
															$tab1="Offers";
														}
														if($ready_to_deliver_tabs==3)
														{
															$tab1="Wholesale";
														}
														?>
															<select name="ready_to_deliver_tabs" id="ready_to_deliver_tabs">
															<option value="0">None</option>
																<?php if($type=='edit'||$type=='view') {?>
																<option value="<?php echo $ready_to_deliver_tabs ?>"><?php echo $tab1?></option>
																<?php } 
																for($i=1;$i<4;$i++)
																{
																	if($i==1)
																	{
																		$tab="Retail";
																	}
																	if($i==2)
																	{
																		$tab="Offers";
																	}
																	if($i==3)
																	{
																		$tab="Wholesale";
																	}
																	if($i!=$ready_to_deliver_tabs)
																	{
																?>
																<option value="<?php echo $i?>"><?php echo $tab?></option>
																<?php 
																	}
																}
																?>
																
															</select>
													    </div>
												</div>
											
														   <script type="text/javascript">
							  $(document).ready(function() {
								  
									
								  $('#cat_id').on('click', function() {
									
											 
											  var categories = $('#cat_id').val();
									console.log(categories);
									$.ajax({   
									   url: "<?php echo base_url()?>cms/getSubCategories/dropdown",
										async: false,
										type: "POST", 
										data: "categories="+categories,
										dataType: "html",
										
										success: function(data) {
											var dt=data.split("|");
											//$('#subcategories').html(dt[0]);
											if(dt[0]!='<label class="control-label">Sub Categories</label><div class="controls"><select name="prod_sub_categories" id="prod_sub_categories"></select></div>')
											{
												$('#subcategories').fadeIn();
												$('#subcategories').html(dt[0]);
												
											
											}
											else{
												$('#subcategories').fadeIn();
												$('#subcategories').html('<div class="controls">Subcategory is not found under this category</div>');
											}
											
											if(dt[1]!='<label class="control-label">Filters</label><div class="controls"><select onclick="getFilterVals()" name="filter_id" id="filter_id"></select></div>')
											{
												$('#filters').fadeIn();
												$('#filters').html(dt[1]);
											}
											else{
												$('#filters').fadeIn();
												$('#filters').html('<div class="controls">Filter is not found under this category</div>');
											}
										}
									})
								  
									 
								  });
								//  $('#filterDropdwn').on('click', function() {
									
										
								});
								function getFilterVals()
										{										
											  var filters = $('#filter_id').val();
											  
									console.log(filters);
									$.ajax({   
									   url: "<?php echo base_url()?>cms/getSubCategories/filterdropdown",
										async: false,
										type: "POST", 
										data: "filters="+filters,
										dataType: "html",
										
										success: function(data) {
											var dt=data.split("|");
											
											$("#filterValues").fadeIn();
											$('#filterValues').html(dt[0]);
											
										}
									})
								  
									 
								  }
											  </script>
											<div class="control-group">
												  <label class="control-label">Product Short Description</label>
												  <div class="controls">
													 <textarea name="prod_short_description" id="prod_short_description"  <?php if($type=='view'){?>disabled<?php }?> class="span12   m-wrap"><?php echo $prod_short_description;?></textarea>
												   </div>
											   </div>
											   
											   <div class="control-group">
                              <label class="control-label">Image On Product page:</label>
                              <div class="controls">
                                <div class="fileupload fileupload-new" data-provides="fileupload">
                                    <?php if($type=='edit'){ ?><div class="fileupload-new thumbnail" style="width: 200px; height: 150px;">
                                       <?php if($image_url!=""){?>
										<img src="<?php echo base_url().$image_url?>" /> 
										<?php } else {?>
									   <img src="<?php echo base_url()?>images/noimage.gif" alt="" />
									   <?php }?>
									   <input type="hidden" value="<?php echo $image_url; ?>" name="img_url">	
                                    </div><?php } ?> 
                                    <div class="fileupload-preview fileupload-exists thumbnail" style="max-width: 200px; max-height: 150px; line-height: 20px;"></div>
                                    <div>
                                       <span class="btn btn-file"><span class="fileupload-new">Select image</span>
                                       <span class="fileupload-exists">Change</span>
                                       <input type="file" name="fileinput" <?php if($type=='view'){?>disabled<?php }?> class="default" /></span>
                                       <a href="#" class="btn fileupload-exists" data-dismiss="fileupload">Remove</a>
                                    </div>
									
                                 </div> 
                              </div>
                           </div> 
				
											   
											</div>
											
										
									</div>
								</div>
								
								
							
								
							</div>
							<div class="tab-pane" id="tab_1">
								<div class="portlet box blue">
									<div class="portlet-title">
										<div class="caption">
											<i class="fa fa-reorder"></i>Price Info
										
										<div class="tools">
											<a href="javascript:;" class="collapse">
											</a>
											<a href="#portlet-config" data-toggle="modal" class="config">
											</a>
											<a href="javascript:;" class="reload">
											</a>
											<a href="javascript:;" class="remove">
											</a>
										</div>
									</div>
									</div>
									<div class="portlet-body form form-horizontal">
										<!-- BEGIN FORM-->
										
											<div class="form-body">
												
												
													<div class="control-group">
													<label class="control-label">MRP</label>
													    <div class="controls">
															<input type="text" name="prod_price" id="prod_price" <?php if($type=='view'){?>disabled<?php }?> value="<?php echo $prod_price;?>" class="span4 m-wrap"> 
													    </div>
													</div>
													<div class="control-group">
													<label class="control-label">Sell Price</label>
													    <div class="controls">
															<input type="text" name="prod_sell_price" id="prod_sell_price" onkeyup="getDiscount()" <?php if($type=='view'){?>disabled<?php }?> value="<?php echo $prod_price;?>" class="span4 m-wrap"> 
													    </div>
													</div>
													<div class="control-group">
													<label class="control-label">Discount %</label>
													    <div class="controls">
															<input type="text" name="prod_discount" id="prod_discount" <?php if($type=='view'){?>disabled<?php }?> value="<?php echo $prod_discount;?>" class="span4 m-wrap"> 
													    </div>
													</div>
													<!--/span-->
													<div class="control-group">
													<label class="control-label">Quantity</label>
													    <div class="controls">
															<input type="text" name="prod_qty" id="prod_qty" <?php if($type=='view'){?>disabled<?php }?> value="<?php echo $prod_qty;?>" class="span4 m-wrap"> 
													    </div>
													</div>
													
													<!--/span-->
												
													<div class="control-group">
													<label class="control-label">Stock</label>
													    <div class="controls">
															<select name="prod_stock" class="span4 m-wrap">
																<option value="<?php echo $prod_stock ?>">In stock</option>
																<option value="0">In stock</option>
																<option value="1">Out of stock</option>
															</select>
															
														</div>
													</div>
													<!--/span-->
													<div class="control-group">
													<label class="control-label">Require Shipping</label>
													    <div class="controls">
															<div class="radio-list">
																<label class="radio-inline">
																<input type="radio" name="require_shipping" id="require_shipping1" value="1" checked>  Yes  </label>
																<label class="radio-inline">
																<input type="radio" name="require_shipping" id="require_shipping2" value="0"> No  </label>
															</div>
													    </div>
													</div>
													<div class="control-group"> 
													<label class="control-label">Shipping Price</label>
													    <div class="controls">
															<input type="text" name="prod_shipping_price" id="prod_shipping_price" <?php if($type=='view'){?>disabled<?php }?> value="<?php echo $prod_shipping_price;?>" class="span4 m-wrap"> 
													    </div>
													</div>
											</div>
											
										<script type="text/javascript">
				function getDiscount()
				{
					if(isNaN((document.getElementById('prod_price').value*1 - document.getElementById('prod_sell_price').value*1)*100/document.getElementById('prod_price').value*1))
					{
						document.getElementById('prod_discount').value=0;
					}
					else{
					document.getElementById('prod_discount').value=(document.getElementById('prod_price').value*1 - document.getElementById('prod_sell_price').value*1)*100/document.getElementById('prod_price').value*1;
					}
				}
				</script>
									</div>
								</div>
							</div>
							<div class="tab-pane " id="tab_2">
								<div class="portlet box blue">
									<div class="portlet-title">
										<div class="caption">
											<i class="fa fa-reorder"></i>Form Sample
										
										<div class="tools">
											<a href="javascript:;" class="collapse">
											</a>
											<a href="#portlet-config" data-toggle="modal" class="config">
											</a>
											<a href="javascript:;" class="reload">
											</a>
											<a href="javascript:;" class="remove">
											</a>
										</div>
										</div>
									</div>
									<div class="portlet-body form form-horizontal"">
										<!-- BEGIN FORM-->
										
											<div class="form-body">
												<h3 class="form-section">Upload Images For Description</h3>
												
											<div class="control-group">
											  <label class="control-label">Image 1:</label>
											  <div class="controls">
												<div class="fileupload fileupload-new" data-provides="fileupload">
													<?php if($type=='edit'){ ?><div class="fileupload-new thumbnail" style="width: 200px; height: 150px;">
													   <?php if($image_url1!=""){?>
														<img src="<?php echo base_url().$image_url1?>" /> 
														<?php } else {?>
													   <img src="<?php echo base_url()?>images/noimage.gif" alt="" />
													   <?php }?>
													   <input type="hidden" value="<?php echo $image_url1; ?>" name="img_url1">	
													</div><?php } ?>
													<div class="fileupload-preview fileupload-exists thumbnail" style="max-width: 200px; max-height: 150px; line-height: 20px;"></div>
													<div>
													   <span class="btn btn-file"><span class="fileupload-new">Select image</span>
													   <span class="fileupload-exists">Change</span>
													   <input type="file" name="fileinput1" <?php if($type=='view'){?>disabled<?php }?> class="default" /></span>
													   <a href="#" class="btn fileupload-exists" data-dismiss="fileupload">Remove</a>
													</div>
													
												 </div> 
											  </div> 
											</div> 
											 <div class="control-group">
                              <label class="control-label">Image 2:</label>
                              <div class="controls">
                                <div class="fileupload fileupload-new" data-provides="fileupload">
                                    <?php if($type=='edit'){ ?><div class="fileupload-new thumbnail" style="width: 200px; height: 150px;">
                                       <?php if($image_url2!=""){?>
										<img src="<?php echo base_url().$image_url2?>" /> 
										<?php } else {?>
									   <img src="<?php echo base_url()?>images/noimage.gif" alt="" />
									   <?php }?>
									   <input type="hidden" value="<?php echo $image_url2; ?>" name="img_url2">	
                                    </div><?php } ?> 
                                    <div class="fileupload-preview fileupload-exists thumbnail" style="max-width: 200px; max-height: 150px; line-height: 20px;"></div>
                                    <div>
                                       <span class="btn btn-file"><span class="fileupload-new">Select image</span>
                                       <span class="fileupload-exists">Change</span>
                                       <input type="file" name="fileinput2" <?php if($type=='view'){?>disabled<?php }?> class="default" /></span>
                                       <a href="#" class="btn fileupload-exists" data-dismiss="fileupload">Remove</a>
                                    </div>
									
                                 </div> 
                              </div>
                           </div> 
						    <div class="control-group">
                              <label class="control-label">Image 3:</label>
                              <div class="controls">
                                <div class="fileupload fileupload-new" data-provides="fileupload">
                                    <?php if($type=='edit'){ ?><div class="fileupload-new thumbnail" style="width: 200px; height: 150px;">
                                       <?php if($image_url3!=""){?>
										<img src="<?php echo base_url().$image_url3?>" /> 
										<?php } else {?>
									   <img src="<?php echo base_url()?>images/noimage.gif" alt="" />
									   <?php }?>
									   <input type="hidden" value="<?php echo $image_url3; ?>" name="img_url3">	
                                    </div><?php } ?> 
                                    <div class="fileupload-preview fileupload-exists thumbnail" style="max-width: 200px; max-height: 150px; line-height: 20px;"></div>
                                    <div>
                                       <span class="btn btn-file"><span class="fileupload-new">Select image</span>
                                       <span class="fileupload-exists">Change</span>
                                       <input type="file" name="fileinput3" <?php if($type=='view'){?>disabled<?php }?> class="default" /></span>
                                       <a href="#" class="btn fileupload-exists" data-dismiss="fileupload">Remove</a>
                                    </div>
									
                                 </div> 
                              </div>
                           </div> 
						    <div class="control-group">
                              <label class="control-label">Image 4:</label>
                              <div class="controls">
                                <div class="fileupload fileupload-new" data-provides="fileupload">
                                    <?php if($type=='edit'){ ?><div class="fileupload-new thumbnail" style="width: 200px; height: 150px;">
                                       <?php if($image_url4!=""){?>
										<img src="<?php echo base_url().$image_url4?>" /> 
										<?php } else {?>
									   <img src="<?php echo base_url()?>images/noimage.gif" alt="" />
									   <?php }?>
									   <input type="hidden" value="<?php echo $image_url4; ?>" name="img_url4">	
                                    </div><?php } ?> 
                                    <div class="fileupload-preview fileupload-exists thumbnail" style="max-width: 200px; max-height: 150px; line-height: 20px;"></div>
                                    <div>
                                       <span class="btn btn-file"><span class="fileupload-new">Select image</span>
                                       <span class="fileupload-exists">Change</span>
                                       <input type="file" name="fileinput4" <?php if($type=='view'){?>disabled<?php }?> class="default" /></span>
                                       <a href="#" class="btn fileupload-exists" data-dismiss="fileupload">Remove</a>
                                    </div>
									
                                 </div> 
                              </div>
                           </div> 
											</div>
											<div class="control-group">
											<div class="controls">
											<?php if($type!='view'){?>
											<button type="submit" class="btn blue">Save</button>
											<button type="button" class="btn default">Cancel</button>
											<?php }?>
											</div>
											</div>
										
											</div>
									</div>
								</div>
							
							
							
							
							
						</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>