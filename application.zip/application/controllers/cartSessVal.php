<?php 
session_start();
class CartSessVal extends CI_Controller
{
	function __Construct(){
		parent::__construct();
		
				
               $this->load->model('cart_model');
			}
	function setSession($prodid=null, $cartqtysess=null, $totalCartQty=null,$counter=null)
	{
		//$_SESSION['cartqty']=$totalCartQty;
		$_SESSION['counter'][$prodid]=$counter;
		/*unset($_SESSION['cartqty']);
		unset($_SESSION['cart']);
		*/
		//$itemArray = array($sqlArr['prod_id']=>array('prod_name'=>$sqlArr['prod_name'], 'prod_id'=>$sqlArr['prod_id'], 'quantity'=>$cartqtysess, 'price'=>$sqlArr['prod_price']));
		
			$id=intval($prodid); 
          
        if(isset($_SESSION['cart'][$id])){ 
              if($cartqtysess!=null)
			  {
				  $_SESSION['cart'][$id]['quantity']=$cartqtysess;
			  }
			  else{
            $_SESSION['cart'][$id]['quantity']++; 
			  }
              
        }else{ 
              
           $sqlArr=$this->cart_model->getCartProd($id);
           $_SESSION['cart'][$sqlArr['prod_id']]=array("prod_id"=>$sqlArr['prod_id'],"prod_name"=>$sqlArr['prod_name'],"quantity" => 1, "prod_price" => $sqlArr['prod_price'], "prod_image"=>$sqlArr['prod_image'] ); 
    
        } 
		$subtotal=0;
		$qtyTotal=0;
		$html='<h3>Cart</h3><ul class="list-thumbs-pro" >';
		foreach($_SESSION['cart'] as $k=>$v)
		{
			$qtyTotal=$qtyTotal+intval($v["quantity"]);
			$subtotal=$subtotal+intval($v["prod_price"])*intval($v["quantity"]);
				$html.='<div class="shopp" id="each">';
				$html.='<div class="label1">Product Name:'.$v["prod_name"].'</div>';
				$html.='<div class="shopp-price"><em>Price:'.intval($v["prod_price"]).'</em></div>';
				$html.='Quantity<span class="shopp-quantity">'.$v["quantity"].'</span>';
				$html.='<a onclick="getProdInfo'.$v["prod_id"].'('.$v["prod_id"].')"><img src="'.base_url().'images/remove.png" class="removeProd" /><br class="all" /></a>';
				$html.='</div>';
		}
		$html.='</ul>';
		$html.='<ul class="list-inline cart-subtotals">';
		$html.='<li class="cart-subtotal"><strong>Subtotal:</strong></li>';
		$html.='<li class="price"><span class="amount"><strong id="cart-total">'.$subtotal.'</strong></span></li>';
		$html.='<ul class="list-inline cart-subtotals">';
		$html.='<a href="'.base_url().'addtocart" class="btn btn-dark btn-block">View Cart</a>';
		$html.='<a href="shop-checkout.html" class="btn btn-primary btn-block">Go to Checkout</a>';
		$_SESSION['cartqty']=$qtyTotal;
		echo $html."|".$qtyTotal;
	//	echo $_SESSION['cart'][$id]['quantity'];
	}
	function removeCartProd($prodid=null,$totalCartQty=null)
	{
		$id=intval($prodid); 
		$sqlArr=$this->cart_model->getCartProd($id);
		//$_SESSION['counter'][$id]=$totalCartQty;
		if(isset($_SESSION['cart'][$sqlArr['prod_id']]))
		{
			$_SESSION['cartqty']=$totalCartQty-$_SESSION['cart'][$sqlArr['prod_id']]['quantity'];
			unset($_SESSION['cart'][$sqlArr['prod_id']]);
		}
		if($prodid!=null && $totalCartQty>=1)
		{
		
		
		$subtotal=0;
		$html='<h3>Cart</h3><ul class="list-thumbs-pro" >';
		foreach($_SESSION['cart'] as $k=>$v)
		{
			$subtotal=$subtotal+intval($v["prod_price"])*intval($v["quantity"]);
				$html.='<div class="shopp" id="each">';
				$html.='<div class="label1">Product Name:'.$v["prod_name"].'</div>';
				$html.='<div class="shopp-price"><em>Price:'.intval($v["prod_price"]).'</em></div>';
				$html.='Quantity<span class="shopp-quantity">'.$v["quantity"].'</span>';
				$html.='<a onclick="getProdInfo'.$v["prod_id"].'('.$v["prod_id"].')"><img src="'.base_url().'images/remove.png" class="removeProd" /><br class="all" /></a>';
				$html.='</div>';
		}
		$html.='</ul>';
		$html.='<ul class="list-inline cart-subtotals">';
		$html.='<li class="cart-subtotal"><strong>Subtotal:</strong></li>';
		$html.='<li class="price"><span class="amount"><strong id="cart-total">'.$subtotal.'</strong></span></li>';
		$html.='<ul class="list-inline cart-subtotals">';
		$html.='<a href="'.base_url().'addtocart" class="btn btn-dark btn-block">View Cart</a>';
		$html.='<a href="shop-checkout.html" class="btn btn-primary btn-block">Go to Checkout</a>';
		
		echo json_encode(array($html,$_SESSION['cartqty']));
		
	}
	else{
		
		echo "Cart is Empty";
	}
	}
	
}
?>