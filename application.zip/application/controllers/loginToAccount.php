<?php 
class LoginToAccount extends CI_COntroller
{
			function __Construct(){
			parent::__construct();
			$this->load->model('common_model');
			}
			function index()
			{
				
				
				$this->load->view("header_view");
				$this->load->view("LoginToAccount_view");
				$this->load->view("footer_view");
			}
			
			
}
?>