<?php 
class contact_model extends CI_Model{

			
			function get_all_contact_us_details($Id){


			    $sql=$this->db->query("select * from contact where Id='$Id'");
			    return $sql->result_array();
			
			}



}?>		