<?php 
class GetSubCategories extends CI_Controller
{
	function __Construct(){
		parent::__construct();
		if(!$this->session->userdata('user_id')){
				   redirect("cms/login");
				}
				
               $this->load->model('cms/getSubCatAjax');
			}
	function index()
	{
		if (isset($_POST) && isset($_POST['categories'])) {
            $category_id = $_POST['categories'];
			
            $arrSubcat = $this->getSubCatAjax->get_subcategories($category_id);
           $res=''; 
		   $cnt=0;
           foreach($arrSubcat as $row)
		   {
			   
			   $res=$res.'<span class="control-label">'.$row['sub_cat_name'].'<input type="checkbox" name="sub_cat_ids[]" id="subcategory'.$cnt.'" value="'.$row['sub_cat_id'].'"/></span>';
			   $cnt++;
		   }
		   echo $res;
		}
        
	} 
	function dropdown()
	{
		if (isset($_POST) && isset($_POST['categories'])) {
            $category_id = $_POST['categories'];
			
            $arrSubcat = $this->getSubCatAjax->get_subcategories($category_id);
			$arrFilter = $this->getSubCatAjax->get_filters($category_id);
           $res='<label class="control-label">Sub Categories</label><div class="controls"><select name="prod_sub_categories" id="prod_sub_categories">';
		   $res1='<label class="control-label">Filters</label><div class="controls"><select onclick="getFilterVals()" name="filter_id" id="filter_id">';
		  
           foreach($arrSubcat as $row)
		   {
			   
			   $res=$res.'<option value="'.$row['sub_cat_id'].'">'.$row['sub_cat_name'].'</option>';
			  
			  
		   }
		   foreach($arrFilter as $row1)
		   {
			   $res1=$res1.'<option value="'.$row1['filter_id'].'">'.$row1['filter_name'].'</option>';
			   
		   }
		   $finres=$res.'</select></div>|'.$res1.'</select></div>|';
		   echo $finres;
		}
	}
	function filterdropdown()
	{
		if (isset($_POST) && isset($_POST['filters'])) {
            $filters = $_POST['filters'];
			
            
			$arrFilterVal = $this->getSubCatAjax->get_filter_vals($filters);
           $res='<label class="control-label">Filter Values</label><div class="controls">';
		   
		  
           foreach($arrFilterVal as $row)
		   {
			   $filtervalArr=explode(',',$row['filter_values']);
			   for($i=0;$i<sizeof($filtervalArr);$i++)
			   {
			   $res=$res.'<div style="width:150px;float:left;"><input type="radio" name="filter_val" value="'.$row['filter_id'].'"> '.$filtervalArr[$i].'&nbsp; &nbsp;</div>';
			   }
			  
		   }
		 
		   $finres=$res.'</div>|';
		   echo $finres;
		}
	}
}
?>