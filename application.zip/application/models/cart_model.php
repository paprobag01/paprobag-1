<?php 
class Cart_model extends CI_Model
{
	function getCartProd($prodid=null)
	{
		$sql=$this->db->query("select * from products where prod_id=$prodid");
		return $sql->row_array();
	}
	function getCustomizatios($id=null)
	{
		$sql="";
		
		foreach($_SESSION['cart'] as $k=>$v)
		{
			if(isset($_SESSION['cusomizations_for_product'][$k]))
			{
			foreach($_SESSION['cusomizations_for_product'][$k] as $key=>$val)
			{
				foreach($val as $ky=>$vl)
				{
					$sql=$this->db->query("select `customizations`.customize_id as custid, `customizations`.custom_cat_id as custcatid, `customizations`.custom_name as custname, `customizations`.cat_id as catid, customize_type.custom_type_name as custtype from customizations left join customize_type on customizations.custom_cat_id = customize_type.custom_cat_id");
					return $sql->result_array();
				}
			}
			}
		}
		
	}
}
?>