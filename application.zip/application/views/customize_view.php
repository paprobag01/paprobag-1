<div class="page">
        <div class="main-container col1-layout">
            <div class="main" id="Container">
                                	<div class="process-wrap">
	
			</div>
	<div class="clearer"></div>
<script type="text/javascript">
            var GRANIFY_SITE_ID = 1118;
 
            (function(e,t,n){e=e+"?id="+t;window.Granify=n;n._stack=[];n.s_v=2;n.init=function(e,t,r){function i(e,t){e[t]=function(){Granify._stack.push([t].concat(Array.prototype.slice.call(arguments,0)))}}var s=n;h=["on","addTag","trackPageView","trackCart","trackOrder"];for(u=0;u<h.length;u++)i(s,h[u])};n.init();var r,i,s,o=document.createElement("iframe");o.src="javascript:false";o.title="";o.role="presentation";(o.frameElement||o).style.cssText="width: 0 !important; height: 0 !important; border: 0 !important; overflow: hidden !important; position: absolute !important; top: -1000px !important; left: -1000px !important;";s=document.getElementsByTagName("script");s=s[s.length-1];s.parentNode.insertBefore(o,s);try{i=o.contentWindow.document}catch(u){r=document.domain;o.src="javascript:var d=document.open();d.domain='"+r+"';void(0);";i=o.contentWindow.document}i.open()._l=function(){var t=this.createElement("script");if(r)this.domain=r;t.id="js-iframe-async";t.src=e;this.body.appendChild(t)};i.write('<body onload="document._l();">');i.close()})("../../../../../../cdn.granify.com/assets/magento.js",GRANIFY_SITE_ID,[])            
            </script>
<script type="text/javascript">
                Granify.trackPageView({
                    page_type: 'other'
                });
            </script>
<script type="text/javascript">
//<![CDATA[
Granify.trackCart({ items: [] });
//]]>
</script>


<script type="text/javascript">
    var optionsPrice = new Product.OptionsPrice({"productId":"540","priceFormat":{"pattern":"$%s","precision":2,"requiredPrecision":2,"decimalSymbol":".","groupSymbol":",","groupLength":3,"integerRequired":1},"includeTax":"false","showIncludeTax":false,"showBothPrices":false,"productPrice":"549","productOldPrice":"549","skipCalculate":1,"defaultTax":8.875,"currentTax":0,"idSuffix":"_clone","oldPlusDisposition":0,"plusDisposition":0,"oldMinusDisposition":0,"minusDisposition":0});
</script>
<div id="messages_product_view"></div>
<div style="width:100%;">
<div class="buttons-set" class="clearfix" style="width:100%;z-index:1000;position:absolute;margin-top:-17px;margin-left:24%;">
                        <!-- <a class="help custom button clearfix" href="#" title="Explain Customization Option"><span>Give me advice</span></a> -->
                                                    <a href="#" class="launch_advanced button three clearfix" style="width:20%"><span>Advanced Options</span></a>
													
                                            </div>
											</div>
											<div id="AdvancedOptions">
                            <div class="close"><span>+</span></div>
                            <div class="save-overlay" style="display: none;"></div>
                            <div id="save-dialog" style="display: none;">
                                <p>Would you like to save the changes?</p>
                                <div class="buttons-set clearfix">
                                    <a href="#" class="changes-save">Yes</a>
                                    <a href="#" class="changes-discard">No</a>
                                </div>
                            </div>
                            <h3><span>Advanced Options</span></h3>
							
                            
                            <div class="AdvOptions-wrap">
                            <ul id="AdvOptionsMenu"></ul>
                            <div class="slides">
 	<div class="slide" data-id='add_vest' rel="Add Vest">
		<div class="block" id="Add_Vest">
		<dt><label class="option_label">Add Vest</label>
		<div class="clear"></div>
		</dt>
		<div class="clear"></div>
		<dd>
	    <div class="input-box">
	        <ul id="options-147-list" class="options-list"><li  ><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[147]" id="options_147_2" value="411"  price="0" /></div><span class="label1"><label for="options_147_2"><span><span class="decoration-span">None <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_147_2').advaiceContainer = 'options-147-container';$('options_147_2').callbackFunction = 'validateOptionsCallback';</script></li><li  ><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[147]" id="options_147_3" value="390"  price="120" /></div><span class="label1"><label for="options_147_3"><span><span class="decoration-span">Yes <span class="price-notice">+<span class="price">$120.00</span></span><span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_147_3').advaiceContainer = 'options-147-container';$('options_147_3').callbackFunction = 'validateOptionsCallback';</script></li></ul>                                    <span id="options-147-container"></span>
	    </div>
		</dd>
		</div>
                                <div class="clear"></div>
								<div class='sub-block'>                                
                                                                                                            	    		      
	    	                                                                                
                                
 
<div class="block" id="Vest_Buttons">
<dt><label class="option_label">Vest Buttons</label>
<div class="clear"></div>
</dt>
<div class="clear"></div>
<dd>
    <div class="input-box">
        <ul id="options-145-list" class="options-list"><li  ><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[145]" id="options_145_2" value="386"  price="0" /></div><span class="label1"><label for="options_145_2"><span><span class="decoration-span">4 <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_145_2').advaiceContainer = 'options-145-container';$('options_145_2').callbackFunction = 'validateOptionsCallback';</script></li><li  ><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[145]" id="options_145_3" value="387"  price="0" /></div><span class="label1"><label for="options_145_3"><span><span class="decoration-span">5 <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_145_3').advaiceContainer = 'options-145-container';$('options_145_3').callbackFunction = 'validateOptionsCallback';</script></li></ul>                                    <span id="options-145-container"></span>
                        </div>
</dd>
</div>
                                <div class="clear"></div>

                                                                
                                                                                                            	    		      
	    	                                                                                
                                
 
<div class="block" id="Vest_Lining">
<dt><label class="option_label">Vest Lining</label>
<div class="clear"></div>
</dt>
<div class="clear"></div>
<dd>
    <div class="input-box" style="height:40px;">
        <ul id="options-146-list" class="options-list"><li  ><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[146]" id="options_146_2" value="388"  price="0" /></div><span class="label1"><label for="options_146_2"><span><span class="decoration-span">Black (Standard) <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_146_2').advaiceContainer = 'options-146-container';$('options_146_2').callbackFunction = 'validateOptionsCallback';</script></li><li  ><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[146]" id="options_146_3" value="389"  price="0" /></div><span class="label1"><label for="options_146_3"><span><span class="decoration-span">Match Inner Lining <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_146_3').advaiceContainer = 'options-146-container';$('options_146_3').callbackFunction = 'validateOptionsCallback';</script></li></ul>                                    <span id="options-146-container"></span>
                        </div>
</dd>
</div>
                                <div class="clear"></div>

                                                                </div>
                                 					
                                    <div class="description">
                                                                                            
                                        Add a vest and make your wardrobe more flexible with a 3-piece suit. The front of the vest is made with the same material as the suit and the back is made with either black Bemberg or Bemberg that matches your jacket's inner lining. The vest can be worn alone or with your suit and is most economical as an add-on option.                            
                                    </div> <!-- /description -->
                                    </div>
                                                                                                            	    		      

                                                                                                            
                            </div><!-- /slides -->
            <div class="clearer"></div>
                </div>
	    <div id="HiddenOptions">
                                                <script>
                    jQuery('#HiddenOptions #Lapel_Type').find('.options-list li:last-child input[type=radio]').attr('checked', 'checked');
                                            jQuery('#HiddenOptions #Collar_Type').find('.options-list li:first-child input[type=radio]').attr('checked', 'checked');
                        		</script>
	    </div>	
		<div class="save" style="margin-right:50px;position:relative;width:150px;float:right;" align="center"><span>Save</span></div>
              </div>
<div id="BodyText" style="margin-top:50px;">

	<div class="product-view">
            <form onsubmit="return false;" action="<?php echo base_url() ?>customize/SaveCustomizations" method="post" id="product_addtocart_form" enctype="multipart/form-data">
				<input type="hidden" value="<?php echo $prodid;?>" name="prod_id" />
                <div class="customize-options-wrapper">
                    <div class="no-display">
                        <input type="hidden" name="product" value="<?php echo $prodid?>" />
                        <input type="hidden" name="related_product" id="related-products-field" value="<?php echo $catid?>" />
                    </div>
                    <!-- {{{ not has options?  -->
                                        <!-- }}} -->

                                                                                    
                    <div class="clearer"></div>
                                            <div class="product-options" id="product-options-wrapper">
											
    <script type="text/javascript">
//<![CDATA[
var DateOption = Class.create({

    getDaysInMonth: function(month, year)
    {
        var curDate = new Date();
        if (!month) {
            month = curDate.getMonth();
        }
        if (2 == month && !year) { // leap year assumption for unknown year
            return 29;
        }
        if (!year) {
            year = curDate.getFullYear();
        }
        return 32 - new Date(year, month - 1, 32).getDate();
    },

    reloadMonth: function(event)
    {
        var selectEl = event.findElement();
        var idParts = selectEl.id.split("_");
        if (idParts.length != 3) {
            return false;
        }
        var optionIdPrefix = idParts[0] + "_" + idParts[1];
        var month = parseInt($(optionIdPrefix + "_month").value);
        var year = parseInt($(optionIdPrefix + "_year").value);
        var dayEl = $(optionIdPrefix + "_day");

        var days = this.getDaysInMonth(month, year);

        //remove days
        for (var i = dayEl.options.length - 1; i >= 0; i--) {
            if (dayEl.options[i].value > days) {
                dayEl.remove(dayEl.options[i].index);
            }
        }

        // add days
        var lastDay = parseInt(dayEl.options[dayEl.options.length-1].value);
        for (i = lastDay + 1; i <= days; i++) {
            this.addOption(dayEl, i, i);
        }
    },

    addOption: function(select, text, value)
    {
        var option = document.createElement('OPTION');
        option.value = value;
        option.text = text;

        if (select.options.add) {
            select.options.add(option);
        } else {
            select.appendChild(option);
        }
    }
});
dateOption = new DateOption();
//]]>
</script>



    <script type="text/javascript">
    //<![CDATA[
    var optionFileUpload = {
        productForm : $('product_addtocart_form'),
        formAction : '',
        formElements : {},
        upload : function(element){
            this.formElements = this.productForm.select('input', 'select', 'textarea', 'button');
            this.removeRequire(element.readAttribute('id').sub('option_', ''));

            template = '<iframe id="upload_target" name="upload_target" style="width:0; height:0; border:0;"><\/iframe>';

            Element.insert($('option_'+element.readAttribute('id').sub('option_', '')+'_uploaded_file'), {after: template});

            this.formAction = this.productForm.action;

            var baseUrl = 'http://www.xyz.com/process_product_customize/product/upload/';
            var urlExt = 'option_id/'+element.readAttribute('id').sub('option_', '');

            this.productForm.action = parseSidUrl(baseUrl, urlExt);
            this.productForm.target = 'upload_target';
            this.productForm.submit();
            this.productForm.target = '';
            this.productForm.action = this.formAction;
        },
        removeRequire : function(skipElementId){
            for(var i=0; i<this.formElements.length; i++){
                if (this.formElements[i].readAttribute('id') != 'option_'+skipElementId+'_file' && this.formElements[i].type != 'button') {
                    this.formElements[i].disabled='disabled';
                }
            }
        },
        addRequire : function(skipElementId){
            for(var i=0; i<this.formElements.length; i++){
                if (this.formElements[i].readAttribute('name') != 'options_'+skipElementId+'_file' && this.formElements[i].type != 'button') {
                    this.formElements[i].disabled='';
                }
            }
        },
        uploadCallback : function(data){
            this.addRequire(data.optionId);
            $('upload_target').remove();

            if (data.error) {

            } else {
                $('option_'+data.optionId+'_uploaded_file').value = data.fileName;
                $('option_'+data.optionId+'_file').value = '';
                $('option_'+data.optionId+'_file').hide();
                $('option_'+data.optionId+'').hide();
                template = '<div id="option_'+data.optionId+'_file_box"><a href="#"><img src="var/options/'+data.fileName+'" alt=""><\/a><a href="#" onclick="optionFileUpload.removeFile('+data.optionId+')" title="Remove file" \/>Remove file<\/a>';

                Element.insert($('option_'+data.optionId+'_uploaded_file'), {after: template});
            }
        },
        removeFile : function(optionId)
        {
            $('option_'+optionId+'_uploaded_file').value= '';
            $('option_'+optionId+'_file').show();
            $('option_'+optionId+'').show();

            $('option_'+optionId+'_file_box').remove();
        }
    }
    var optionTextCounter = {
        count : function(field,cntfield,maxlimit){
            if (field.value.length > maxlimit){
                field.value = field.value.substring(0, maxlimit);
            } else {
                cntfield.innerHTML = maxlimit - field.value.length;
            }
        }
    }

    Product.Options = Class.create();
    Product.Options.prototype = {
        initialize : function(config){
            this.config = config;
            this.reloadPrice();
            document.observe("dom:loaded", this.reloadPrice.bind(this));
        },
        reloadPrice : function(){
            price = new Number();
            config = this.config;
            skipIds = [];
            $$('.product-custom-option').each(function(element){
                var optionId = 0;
                element.name.sub(/[0-9]+/, function(match){
                    optionId = match[0];
                });
                if (this.config[optionId]) {
                    if (element.type == 'checkbox' || element.type == 'radio') {
                        if (element.checked) {
                            if (config[optionId][element.getValue()]) {
                                price += parseFloat(config[optionId][element.getValue()]);
                            }
                        }
                    } else if(element.hasClassName('datetime-picker') && !skipIds.include(optionId)) {
                        dateSelected = true;
                        $$('.product-custom-option[id^="options_' + optionId + '"]').each(function(dt){
                            if (dt.getValue() == '') {
                                dateSelected = false;
                            }
                        });
                        if (dateSelected) {
                            price += parseFloat(this.config[optionId]);
                            skipIds[optionId] = optionId;
                        }
                    } else if(element.type == 'select-one' || element.type == 'select-multiple') {
                        if (element.options) {
                            $A(element.options).each(function(selectOption){
                                if (selectOption.selected) {
                                    if (this.config[optionId][selectOption.value]) {
                                        price += parseFloat(this.config[optionId][selectOption.value]);
                                    }
                                }
                            });
                        }
                    } else {
                        if (element.getValue().strip() != '') {
                            price += parseFloat(this.config[optionId]);
                        }
                    }
                }
            });
            try {
                optionsPrice.changePrice('options', price);
                optionsPrice.changePrice('optionsPriceInclTax', price);
                optionsPrice.reload();
            } catch (e) {

            }
        }
    }
    function validateOptionsCallback(elmId, result){
        var container = $(elmId).up('ul.options-list');
        if (result == 'failed') {
            container.removeClassName('validation-passed');
            container.addClassName('validation-failed');
        } else {
            container.removeClassName('validation-failed');
            container.addClassName('validation-passed');
        }
    }
    var opConfig = new Product.Options({"99":{"274":"0","273":"0","272":"0"},"100":{"275":"0","276":"0","277":"0","530":"50","531":"50"},"101":{"279":"0","280":"0","281":"0","282":"0"},"125":{"337":"0","336":"0","338":"0"},"151":{"397":"0","398":"0","399":"0","400":"0","578":"0"},"97":{"270":"0","422":"0","341":"0","342":"0","343":"0","344":"0","345":"0","346":"0","347":"0","421":"0","418":"0","542":"0","543":"0","544":"0","943":"0","944":"0"},"98":"0","251":"0","109":{"297":"0","298":"0","299":"0"},"110":{"300":"0","301":"0","302":"0"},"41":{"116":"0","117":"0","118":"0"},"42":{"119":"0","120":"0"},"147":{"411":"0","390":"120"},"145":{"386":"0","387":"0"},"146":{"388":"0","389":"0"},"135":{"372":"160"},"117":{"319":"0","366":"0"},"118":{"321":"0","367":"0"},"120":{"767":"0","326":"0","327":"0"},"121":{"328":"0","396":"0"},"126":{"403":"0","349":"0"},"127":{"404":"0","350":"0"},"62":{"172":"0","170":"0","171":"0","169":"0"},"63":{"173":"0","174":"0"},"65":{"178":"0","177":"0","533":"0"}});
    //]]>
    </script>   	
	
    <dl>
	
    <div id="CustomizeSlider" style="height:70%">
	
        <div class="option-descr"></div>
		 
    	
    	
    	<div id="Options" data-presets="Array" style="height:533px;">
		
		<?php 
		$i=99;
		$j=1;
		
		foreach($type_names as $rw)
		{
			$tycnt=$rw['custom_type_name'];
		}
		
		if($tycnt>0)
		{
			$typcnt=0;
		foreach($types as $row)
		{
			
						
			if($typcnt<$tycnt)
			{
		if($j==$tycnt)
		{
		?>
            <div class='slide last' data-id='<?php $row['data_id'] ?>' style="width:100%">
			<?php 
		}
		else{
			?>
			<div class='slide' data-id='<?php $row['data_id'] ?>'  style="width:100%">
			<?php 
		}
		//echo $row['steps'];
			?>
			
			<script>
			$( document ).ready(function() {
    
			});
			</script>
                <div class="block" id="<?php echo $row['customize_div_id']?>">
					<dt><label class="option_label"><?php echo $row['custom_type_name']?></label>
						<div class="clear"></div>
					</dt>
				<div class="clear"></div>
					<dd>
						<div class="input-box" style="overflow:hidden;height:480px;width:100%;border-top:1px solid #D0D0CD;border-bottom:1px solid #D0D0CD;">
						<input type="hidden" name="custom_price[<?php echo $i?>]" id="custom_price<?php echo $i?>"/>
							<ul id="options-<?php echo $i?>-list" class="options-list" style="width: 101%;overflow: scroll;height:495px">
							<?php 
							$k=1;
							foreach($custmreslt as $row1)
							{
								
								if($row['steps']==$row1['steps'])
								{
							?>
							<li>
							<div class="option-description">
								The most form-fitting choice that's ideal for a very streamlined, close-cut look and feel.
							</div>
							<div class="radio-select">
								<input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[<?php echo $i?>]" id="options_<?php echo $i."_".$k;?>" value="<?php echo $row1['customize_id'];?>"  price="0" />
								
							</div>
							<span class="label1">
							<label class="garmentsOptions" for="options_<?php echo $i."_".$k?>" style="background:url('<?php echo base_url().$row1['image_url'];?>');background-repeat: no-repeat;background-size: 160px 150px;">
							
							<div style="margin-top:-20px;">
								<span class="decoration-span" onclick="getPrice<?php echo $i."_".$k?>()"><?php echo $row1['custom_name'];?><span class="icon-check"></span> <?php if($row1['custom_price']!=0){ echo "(+".$row1['custom_price'].")";?><input type="hidden" id="customPrice<?php echo $i."_".$k?>" value="<?php echo $row1['custom_price']; ?>"><?php }?>
								
								</span>
								
							</div>
							<script>
								function getPrice<?php echo $i."_".$k?>()
										{
										//alert("hi");
										document.getElementById("custom_price<?php echo $i?>").value=document.getElementById("customPrice<?php echo $i."_".$k?>").value;
										}
								</script>
							</label>
							
							</span>
							<script type="text/javascript">
							$('options_<?php echo $i."_".$k?>').advaiceContainer = 'options-99-container';$('options_<?php echo $i."_".$k?>').callbackFunction = 'validateOptionsCallback';
							</script>
							</li>
							<?php 
							$k++;
								}
							}
							
							?>
							
							<!-- <li>
							<div class="option-description">A tapered cut that's neither too fitted nor too baggy. </div>
							<div class="radio-select">
							<input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[99]" id="options_<?php echo $i?>_3" value="Tailored Fit"  price="0" /></div>
							<span class="label1"><label for="options_<?php echo $i?>_3"><span><span class="decoration-span">Tailored Fit <span class="icon-check"></span>
							</span>
							</span>
							</label></span>
							<script type="text/javascript">$('options_<?php echo $i?>_3').advaiceContainer = 'options-99-container';$('options_<?php echo $i?>_3').callbackFunction = 'validateOptionsCallback';</script>
							</li>
							<li><div class="option-description">A traditional, looser cut for a more relaxed look and feel.</div><div class="radio-select">
							<input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[99]" id="options_<?php echo $i?>_4" value="Standard Fit"  price="0" />
							</div><span class="label1"><label for="options_<?php echo $i?>_4"><span><span class="decoration-span">Standard Fit <span class="icon-check"></span></span></span></label></span>
							<script type="text/javascript">$('options_<?php echo $i?>_4').advaiceContainer = 'options-99-container';$('options_<?php echo $i?>_4').callbackFunction = 'validateOptionsCallback';</script>
							</li> -->
							
							</ul>                                    <span id="options-99-container"></span>
						</div>
					</dd>
				</div>
                            <div class="clear"></div>
                             </div>    
<?php 
		
		
		$i++;
		$j++;
		$typcnt++;
			}
		}
		}
		else{
			?>
			<div class='slide' >
			<dt><label class="option_label">No Customizations available for this category</label>
						<div class="clear"></div>
					</dt>
			</div>
			<?php 
		}
?>		
                    	                                    	    		      
	    	                                                                                                  <!--       <div class='slide ' data-id='jacket_type'>
                              
                                                        
                                                        
                            
 
<div class="block" id="Jacket_Type">
<dt>
<label class="option_label">Jacket Type</label>
<div class="clear"></div>
</dt>
<div class="clear"></div>
<dd>
    <div class="input-box">
        <ul id="options-100-list" class="options-list">
		<li >
		<div class="option-description">The choice for formal wear (e.g., tuxedos) or a trendier suited look.</div>
		<div class="radio-select">
		<input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[100]" id="options_100_2" value="275"  price="0" />
		</div>
		<span class="label1">
		<label for="options_100_2">
		<span>
			<span class="decoration-span">One-Button 
			<span class="icon-check">
			</span>
			</span>
		</span>
		</label>
		</span>
		<script type="text/javascript">$('options_100_2').advaiceContainer = 'options-100-container';$('options_100_2').callbackFunction = 'validateOptionsCallback';</script>
		</li>
		<li>
		<div class="option-description">The classic, all-purpose option that's suitable for all occasions.</div><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[100]" id="options_100_3" value="276"  price="0" /></div><span class="label1"><label for="options_100_3"><span><span class="decoration-span">Two-Button <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_100_3').advaiceContainer = 'options-100-container';$('options_100_3').callbackFunction = 'validateOptionsCallback';</script></li><li  ><div class="option-description">A more buttoned up look that we suggest only for tall gentlemen.</div><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[100]" id="options_100_4" value="277"  price="0" /></div><span class="label1"><label for="options_100_4"><span><span class="decoration-span">Three-Button <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_100_4').advaiceContainer = 'options-100-container';$('options_100_4').callbackFunction = 'validateOptionsCallback';</script></li><li  ><div class="option-description">The most classic double-breasted suiting option.</div><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[100]" id="options_100_5" value="530"  price="50" /></div><span class="label1"><label for="options_100_5"><span><span class="decoration-span">6x2 Button <span class="price-notice">+<span class="price">$50.00</span></span><span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_100_5').advaiceContainer = 'options-100-container';$('options_100_5').callbackFunction = 'validateOptionsCallback';</script></li><li  ><div class="option-description">A modern, alternative double breasted suiting option.</div><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[100]" id="options_100_6" value="531"  price="50" /></div><span class="label1"><label for="options_100_6"><span><span class="decoration-span">4x2 Button <span class="price-notice">+<span class="price">$50.00</span></span><span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_100_6').advaiceContainer = 'options-100-container';$('options_100_6').callbackFunction = 'validateOptionsCallback';</script></li></ul>                                    <span id="options-100-container"></span>
    </div>
</dd>
</div>
                            <div class="clear"></div>
                             </div>                                                    		        		
                    	                                    	    		      
	    	                                                                                                        <div class='slide ' data-id='lapel_type'>
                               
                                                        
                                                        
                            
 
<div class="block" id="Lapel_Type">
<dt><label class="option_label">Lapel Type</label>
<div class="clear"></div>
</dt>
<div class="clear"></div>
<dd>
    <div class="input-box">
        <ul id="options-101-list" class="options-list"><li  ><div class="option-description">The standard and most versatile lapel type.</div><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[101]" id="options_101_2" value="279"  price="0" /></div><span class="label1"><label for="options_101_2"><span><span class="decoration-span">Notch <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_101_2').advaiceContainer = 'options-101-container';$('options_101_2').callbackFunction = 'validateOptionsCallback';</script></li><li  ><div class="option-description">Ideal for a trendier, more modern look that's great on Slim or Tailored Fit suits.</div><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[101]" id="options_101_3" value="280"  price="0" /></div><span class="label1"><label for="options_101_3"><span><span class="decoration-span">Slim Notch <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_101_3').advaiceContainer = 'options-101-container';$('options_101_3').callbackFunction = 'validateOptionsCallback';</script></li><li  ><div class="option-description">The lapel of choice for some classic flair. It also has a flattering heightening effect.</div><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[101]" id="options_101_4" value="281"  price="0" /></div><span class="label1"><label for="options_101_4"><span><span class="decoration-span">Peak <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_101_4').advaiceContainer = 'options-101-container';$('options_101_4').callbackFunction = 'validateOptionsCallback';</script></li><li  ><div class="option-description">Slim and sleek, this is the most fashion-forward lapel type.</div><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[101]" id="options_101_5" value="282"  price="0" /></div><span class="label1"><label for="options_101_5"><span><span class="decoration-span">Slim Peak <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_101_5').advaiceContainer = 'options-101-container';$('options_101_5').callbackFunction = 'validateOptionsCallback';</script></li></ul>                                    <span id="options-101-container"></span>
                        </div>
</dd>
</div>
                            <div class="clear"></div>
                             </div>                                                    		        		
                    	                                    	    		      
	    	                                                                                                        <div class='slide ' data-id='vents'>
                                
                                                        
                                                        
                            
 
<div class="block" id="Vents">
<dt><label class="option_label">Vents</label>
<div class="clear"></div>
</dt>
<div class="clear"></div>
<dd>
    <div class="input-box">
        <ul id="options-125-list" class="options-list"><li  ><div class="option-description">The recommended option for a stylish, modern suit.</div><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[125]" id="options_125_2" value="337"  price="0" /></div><span class="label1"><label for="options_125_2"><span><span class="decoration-span">Double (Side) <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_125_2').advaiceContainer = 'options-125-container';$('options_125_2').callbackFunction = 'validateOptionsCallback';</script></li><li  ><div class="option-description">The recommended option for the larger gent or those with a larger backside.</div><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[125]" id="options_125_3" value="336"  price="0" /></div><span class="label1"><label for="options_125_3"><span><span class="decoration-span">Single (Center) <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_125_3').advaiceContainer = 'options-125-container';$('options_125_3').callbackFunction = 'validateOptionsCallback';</script></li><li  ><div class="option-description">The classic option for traditional tuxedos.</div><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[125]" id="options_125_4" value="338"  price="0" /></div><span class="label1"><label for="options_125_4"><span><span class="decoration-span">None <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_125_4').advaiceContainer = 'options-125-container';$('options_125_4').callbackFunction = 'validateOptionsCallback';</script></li></ul>                                    <span id="options-125-container"></span>
                        </div>
</dd>
</div>
                            <div class="clear"></div>
                             </div>                                                    		        		
                    	                                    	    		      
	    	                                                                                                        <div class='slide ' data-id='jacket_pockets'>
                              
                                                        
                                                        
                            
 
<div class="block" id="Jacket_Pockets">
<dt><label class="option_label">Jacket Pockets</label>
<div class="clear"></div>
</dt>
<div class="clear"></div>
<dd>
    <div class="input-box">
        <ul id="options-151-list" class="options-list"><li  ><div class="option-description">Also known as "hacking pockets", these slightly angled pockets signal custom-made. </div><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[151]" id="options_151_2" value="397"  price="0" /></div><span class="label1"><label for="options_151_2"><span><span class="decoration-span">Slanted Flapped <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_151_2').advaiceContainer = 'options-151-container';$('options_151_2').callbackFunction = 'validateOptionsCallback';</script></li><li  ><div class="option-description">Your most traditional and standard jacket pocket.</div><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[151]" id="options_151_3" value="398"  price="0" /></div><span class="label1"><label for="options_151_3"><span><span class="decoration-span">Straight Flapped <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_151_3').advaiceContainer = 'options-151-container';$('options_151_3').callbackFunction = 'validateOptionsCallback';</script></li><li  ><div class="option-description">Creates a minimalist look with a subtle and stylish twist.</div><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[151]" id="options_151_4" value="399"  price="0" /></div><span class="label1"><label for="options_151_4"><span><span class="decoration-span">Slanted Piped <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_151_4').advaiceContainer = 'options-151-container';$('options_151_4').callbackFunction = 'validateOptionsCallback';</script></li><li  ><div class="option-description">A minimalist look that is the preferred option for tuxedos.</div><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[151]" id="options_151_5" value="400"  price="0" /></div><span class="label1"><label for="options_151_5"><span><span class="decoration-span">Straight Piped <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_151_5').advaiceContainer = 'options-151-container';$('options_151_5').callbackFunction = 'validateOptionsCallback';</script></li><li  ><div class="option-description">Creates a more casual look for suits and blazers.</div><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[151]" id="options_151_6" value="578"  price="0" /></div><span class="label1"><label for="options_151_6"><span><span class="decoration-span">Patch Pocket <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_151_6').advaiceContainer = 'options-151-container';$('options_151_6').callbackFunction = 'validateOptionsCallback';</script></li></ul>                                    <span id="options-151-container"></span>
                        </div>
</dd>
</div>
                            <div class="clear"></div>
                             </div>                                                    		        		
                    	                                    	    		      
	    	                                                                                                        <div class='slide ' data-id='jacket_inner_lining'>
                               
                                                        
                                                        
                            
 
<div class="block" id="Jacket_Inner_Lining" style="height:650px;">
<dt><label class="option_label">Jacket Inner Lining</label>
<div class="clear"></div>
</dt>
<div class="clear"></div>
<dd style="height:650px;">
    <div class="input-box">
        <ul id="options-97-list" class="options-list" style="height:450px; overflow:scroll;"><li  ><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[97]" id="options_97_2" value="270"  price="0" /></div><span class="label1"><label for="options_97_2"><span><span class="decoration-span">Black <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_97_2').advaiceContainer = 'options-97-container';$('options_97_2').callbackFunction = 'validateOptionsCallback';</script></li><li  ><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[97]" id="options_97_3" value="422"  price="0" /></div><span class="label1"><label for="options_97_3"><span><span class="decoration-span">Lavender <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_97_3').advaiceContainer = 'options-97-container';$('options_97_3').callbackFunction = 'validateOptionsCallback';</script></li><li  ><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[97]" id="options_97_4" value="341"  price="0" /></div><span class="label1"><label for="options_97_4"><span><span class="decoration-span">Sea Blue <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_97_4').advaiceContainer = 'options-97-container';$('options_97_4').callbackFunction = 'validateOptionsCallback';</script></li><li  ><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[97]" id="options_97_5" value="342"  price="0" /></div><span class="label1"><label for="options_97_5"><span><span class="decoration-span">Sky Blue <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_97_5').advaiceContainer = 'options-97-container';$('options_97_5').callbackFunction = 'validateOptionsCallback';</script></li><li  ><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[97]" id="options_97_6" value="343"  price="0" /></div><span class="label1"><label for="options_97_6"><span><span class="decoration-span">Teal Blue <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_97_6').advaiceContainer = 'options-97-container';$('options_97_6').callbackFunction = 'validateOptionsCallback';</script></li><li  ><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[97]" id="options_97_7" value="344"  price="0" /></div><span class="label1"><label for="options_97_7"><span><span class="decoration-span">Red <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_97_7').advaiceContainer = 'options-97-container';$('options_97_7').callbackFunction = 'validateOptionsCallback';</script></li><li  ><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[97]" id="options_97_8" value="345"  price="0" /></div><span class="label1"><label for="options_97_8"><span><span class="decoration-span">Maroon <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_97_8').advaiceContainer = 'options-97-container';$('options_97_8').callbackFunction = 'validateOptionsCallback';</script></li><li  ><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[97]" id="options_97_9" value="346"  price="0" /></div><span class="label1"><label for="options_97_9"><span><span class="decoration-span">Royal Purple <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_97_9').advaiceContainer = 'options-97-container';$('options_97_9').callbackFunction = 'validateOptionsCallback';</script></li><li  ><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[97]" id="options_97_10" value="347"  price="0" /></div><span class="label1"><label for="options_97_10"><span><span class="decoration-span">Gunmetal <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_97_10').advaiceContainer = 'options-97-container';$('options_97_10').callbackFunction = 'validateOptionsCallback';</script></li><li  ><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[97]" id="options_97_11" value="421"  price="0" /></div><span class="label1"><label for="options_97_11"><span><span class="decoration-span">Silver <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_97_11').advaiceContainer = 'options-97-container';$('options_97_11').callbackFunction = 'validateOptionsCallback';</script></li><li  ><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[97]" id="options_97_12" value="418"  price="0" /></div><span class="label1"><label for="options_97_12"><span><span class="decoration-span">Light Gold <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_97_12').advaiceContainer = 'options-97-container';$('options_97_12').callbackFunction = 'validateOptionsCallback';</script></li><li  ><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[97]" id="options_97_13" value="542"  price="0" /></div><span class="label1"><label for="options_97_13"><span><span class="decoration-span">Teal <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_97_13').advaiceContainer = 'options-97-container';$('options_97_13').callbackFunction = 'validateOptionsCallback';</script></li><li  ><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[97]" id="options_97_14" value="543"  price="0" /></div><span class="label1"><label for="options_97_14"><span><span class="decoration-span">Magenta <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_97_14').advaiceContainer = 'options-97-container';$('options_97_14').callbackFunction = 'validateOptionsCallback';</script></li><li  ><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[97]" id="options_97_15" value="544"  price="0" /></div><span class="label1"><label for="options_97_15"><span><span class="decoration-span">Burnt Orange <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_97_15').advaiceContainer = 'options-97-container';$('options_97_15').callbackFunction = 'validateOptionsCallback';</script></li><li  ><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[97]" id="options_97_16" value="943"  price="0" /></div><span class="label1"><label for="options_97_16"><span><span class="decoration-span">Chocolate Brown <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_97_16').advaiceContainer = 'options-97-container';$('options_97_16').callbackFunction = 'validateOptionsCallback';</script></li><li  ><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[97]" id="options_97_17" value="944"  price="0" /></div><span class="label1"><label for="options_97_17"><span><span class="decoration-span">Yellow <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_97_17').advaiceContainer = 'options-97-container';$('options_97_17').callbackFunction = 'validateOptionsCallback';</script></li></ul>                                    <span id="options-97-container"></span>
                        </div>
</dd>
</div>
                            <div class="clear"></div>
                             </div>                                                    		        		
                    	                                    	    		      
	    	                                                                                                        <div class='slide ' data-id='text' style="height:550px;overflow:scroll;width:100%;top:100px;margin-top:100px;">
                              
                                                        
                                                           
															<dt style="margin-top:0px">
<label class="option_label" >Monogramming (Optional)</label>
<div class="clear"></div>
</dt>
                                <div class="sub-block">
                            
                                                        
                            <div class="block" id="Text">
<dt><label class="option_label ">Text</label>
    </dt>
<dd>
    <div class="input-box">
            <input type="text" onchange="opConfig.reloadPrice()" id="options_98_text" class="input-text  validate-length maximum-length-15 product-custom-option" name="options[98]" value="" />
                <p class="note">Maximum number of characters: <strong>15</strong></p>
        </div>
</dd>
</div>                            <div class="clear"></div>
                                                                                		        		
                    	                                    	    		      
	    	                                                                                                        <div class='slide ' data-id='text_line_2'>
                               
                                                        
                                                        
                            <div class="block" id="Text_Line_2">
<dt><label class="option_label ">Text Line 2</label>
    </dt>
<dd>
    <div class="input-box">
            <input type="text" onchange="opConfig.reloadPrice()" id="options_251_text" class="input-text  validate-length maximum-length-15 product-custom-option" name="options[251]" value="" />
                <p class="note">Maximum number of characters: <strong>15</strong></p>
        </div>
</dd>
</div>                            <div class="clear"></div>
                             </div>                                                    		        		
                    	                                    	    		      
	    	                                                                                                    
                                                        
                            
 
<div class="block" id="Color">
<dt><label class="option_label">Color</label>
<div class="clear"></div>
</dt>
<div class="clear"></div>
<dd>
    <div class="input-box">
        <ul id="options-109-list" class="options-list"><li><div class="radio-select"><input type="radio" id="options_109" class="radio product-custom-option" name="options[109]" onclick="opConfig.reloadPrice()" value="" checked="checked" /></div><span class="label1"><label for="options_109"><span><span class="decoration-span">None<span class="icon-check"></span></span></span></label></span></li><li  ><div class="radio-select"><input type="radio" class="radio  product-custom-option" onclick="opConfig.reloadPrice()" name="options[109]" id="options_109_2" value="297"  price="0" /></div><span class="label1"><label for="options_109_2"><span><span class="decoration-span">Gold <span class="icon-check"></span></span></span></label></span></li><li  ><div class="radio-select"><input type="radio" class="radio  product-custom-option" onclick="opConfig.reloadPrice()" name="options[109]" id="options_109_3" value="298"  price="0" /></div><span class="label1"><label for="options_109_3"><span><span class="decoration-span">White <span class="icon-check"></span></span></span></label></span></li><li  ><div class="radio-select"><input type="radio" class="radio  product-custom-option" onclick="opConfig.reloadPrice()" name="options[109]" id="options_109_4" value="299"  price="0" /></div><span class="label1"><label for="options_109_4"><span><span class="decoration-span">Silver <span class="icon-check"></span></span></span></label></span></li></ul>            </div>
</dd>
</div>
                            <div class="clear"></div>
                                                                                		        		
                    	                                    	    		      
	    	                                                                                                    
                                                        
                            
 
<div class="block" id="Font">
<dt><label class="option_label">Font</label>
<div class="clear"></div>
</dt>
<div class="clear"></div>
<dd>
    <div class="input-box">
        <ul id="options-110-list" class="options-list"><li><div class="radio-select"><input type="radio" id="options_110" class="radio product-custom-option" name="options[110]" onclick="opConfig.reloadPrice()" value="" checked="checked" /></div><span class="label1"><label for="options_110"><span><span class="decoration-span">None<span class="icon-check"></span></span></span></label></span></li><li  ><div class="radio-select"><input type="radio" class="radio  product-custom-option" onclick="opConfig.reloadPrice()" name="options[110]" id="options_110_2" value="300"  price="0" /></div><span class="label1"><label for="options_110_2"><span><span class="decoration-span">Block <span class="icon-check"></span></span></span></label></span></li><li  ><div class="radio-select"><input type="radio" class="radio  product-custom-option" onclick="opConfig.reloadPrice()" name="options[110]" id="options_110_3" value="301"  price="0" /></div><span class="label1"><label for="options_110_3"><span><span class="decoration-span">Bold Script <span class="icon-check"></span></span></span></label></span></li><li  ><div class="radio-select"><input type="radio" class="radio  product-custom-option" onclick="opConfig.reloadPrice()" name="options[110]" id="options_110_4" value="302"  price="0" /></div><span class="label1"><label for="options_110_4"><span><span class="decoration-span">Fancy Script <span class="icon-check"></span></span></span></label></span></li></ul>            </div>
</dd>
</div>
                            <div class="clear"></div>
                             </div>                            <div class="clear"></div></div>                        		        		
                    	                                    	    		      
	    	                                                                                                        <div class='slide ' data-id='pant_pleats'>
                               
                                                        
                                                        
                            
 
<div class="block" id="Pant_Pleats">
<dt><label class="option_label">Pant Pleats</label>
<div class="clear"></div>
</dt>
<div class="clear"></div>
<dd>
    <div class="input-box">
        <ul id="options-41-list" class="options-list"><li  ><div class="option-description">A clean look that's recommended for all suiting styles. Pair without cuffs.</div><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[41]" id="options_41_2" value="116"  price="0" /></div><span class="label1"><label for="options_41_2"><span><span class="decoration-span">None (Flat Front) <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_41_2').advaiceContainer = 'options-41-container';$('options_41_2').callbackFunction = 'validateOptionsCallback';</script></li><li  ><div class="option-description">A classic look that creates more room in the thighs without adding too much bulk to the pants.</div><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[41]" id="options_41_3" value="117"  price="0" /></div><span class="label1"><label for="options_41_3"><span><span class="decoration-span">Single (One) <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_41_3').advaiceContainer = 'options-41-container';$('options_41_3').callbackFunction = 'validateOptionsCallback';</script></li><li  ><div class="option-description">A "heftier", throwback look that creates more room around the thighs and seat of pants. Pair with cuffs.</div><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[41]" id="options_41_4" value="118"  price="0" /></div><span class="label1"><label for="options_41_4"><span><span class="decoration-span">Double (Two) <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_41_4').advaiceContainer = 'options-41-container';$('options_41_4').callbackFunction = 'validateOptionsCallback';</script></li></ul>                                    <span id="options-41-container"></span>
                        </div>
</dd>
</div>
                            <div class="clear"></div>
                             </div>                                                    		        		
                    	                                    	    		      
	    	                                                                                                        <div class='slide last' data-id='cuffs'>
                               
                                                        
                                                        
                            
 
<div class="block" id="Cuffs">
<dt><label class="option_label">Cuffs</label>
<div class="clear"></div>
</dt>
<div class="clear"></div>
<dd>
    <div class="input-box">
        <ul id="options-42-list" class="options-list"><li  ><div class="option-description">The choice for a minimal, modern look. Also the best choice for shorter gentlemen.</div><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[42]" id="options_42_2" value="119"  price="0" /></div><span class="label1"><label for="options_42_2"><span><span class="decoration-span">No <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_42_2').advaiceContainer = 'options-42-container';$('options_42_2').callbackFunction = 'validateOptionsCallback';</script></li><li  ><div class="option-description">A tradition option that's typically paired with pleated pants.</div><div class="radio-select"><input type="radio" class="radio  validate-one-required-by-name product-custom-option" onclick="opConfig.reloadPrice()" name="options[42]" id="options_42_3" value="120"  price="0" /></div><span class="label1"><label for="options_42_3"><span><span class="decoration-span">Yes <span class="icon-check"></span></span></span></label></span><script type="text/javascript">$('options_42_3').advaiceContainer = 'options-42-container';$('options_42_3').callbackFunction = 'validateOptionsCallback';</script></li></ul>                                    <span id="options-42-container"></span>
                        </div>
</dd>
</div>
                            <div class="clear"></div>
                             </div>        <!-- /slides -->                                            		        		
                    	                                    	    		      
	    	                                        </div>
													
                    <div class="clear"></div>
                    <div id="Customizer_Pager_Wrapper" class="clearfix">
                        <div class="clearfix customizer_pager Suits">
                                   
                <div class="MeasurementsWrapper">
                <div class="measurements_pager pager-wrap measurements-confirm clearfix" align="center" style="">
                    <a href="#" class="previous button"> &nbsp;Previous &nbsp;	</a><a onclick="onNext()" class="button next">Next</a>
					</div>
				
					<div align="center" style="width: 25%;margin: 0px auto 0px auto"><ul id="pagination" style="margin-top:50px;"></ul></div>
					</div>
					
                                            <div class="add-to-cart" style="margin-left:62%;position:absolute;">
                                                            <input type="hidden" name="qty" id="qty" maxlength="12" value="1" title="Qty" class="input-text qty" />
                                                                                    <a href="#" class="button two addtocart" style="height:35px;" onclick="productAddToCartForm.submit(this)">Add to Bag</a>
                            <br />
                                                    </div>
                                    </div>
									<div style="width:100%;height:40px;margin-left:30%">
									<div class="customizerErrors"></div>
									</div>
									
            </div>
    	</div>
                    </div>
                    
    <div class="clear"></div>
    </dl>

<script type="text/javascript">
//<![CDATA[
enUS = {"m":{"wide":["January","February","March","April","May","June","July","August","September","October","November","December"],"abbr":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]}}; // en_US locale reference
Calendar._DN = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]; // full day names
Calendar._SDN = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"]; // short day names
Calendar._FD = 0; // First day of the week. "0" means display Sunday first, "1" means display Monday first, etc.
Calendar._MN = ["January","February","March","April","May","June","July","August","September","October","November","December"]; // full month names
Calendar._SMN = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]; // short month names
Calendar._am = "AM"; // am/pm
Calendar._pm = "PM";

// tooltips
Calendar._TT = {};
Calendar._TT["INFO"] = "About the calendar";

Calendar._TT["ABOUT"] =
"DHTML Date/Time Selector\n" +
"(c) dynarch.com 2002-2005 / Author: Mihai Bazon\n" +
"For latest version visit: http://www.dynarch.com/projects/calendar/\n" +
"Distributed under GNU LGPL. See http://gnu.org/licenses/lgpl.html for details." +
"\n\n" +
"Date selection:\n" +
"- Use the \xab, \xbb buttons to select year\n" +
"- Use the " + String.fromCharCode(0x2039) + ", " + String.fromCharCode(0x203a) + " buttons to select month\n" +
"- Hold mouse button on any of the above buttons for faster selection.";
Calendar._TT["ABOUT_TIME"] = "\n\n" +
"Time selection:\n" +
"- Click on any of the time parts to increase it\n" +
"- or Shift-click to decrease it\n" +
"- or click and drag for faster selection.";

Calendar._TT["PREV_YEAR"] = "Prev. year (hold for menu)";
Calendar._TT["PREV_MONTH"] = "Prev. month (hold for menu)";
Calendar._TT["GO_TODAY"] = "Go Today";
Calendar._TT["NEXT_MONTH"] = "Next month (hold for menu)";
Calendar._TT["NEXT_YEAR"] = "Next year (hold for menu)";
Calendar._TT["SEL_DATE"] = "Select date";
Calendar._TT["DRAG_TO_MOVE"] = "Drag to move";
Calendar._TT["PART_TODAY"] = ' (' + "Today" + ')';

// the following is to inform that "%s" is to be the first day of week
Calendar._TT["DAY_FIRST"] = "Display %s first";

// This may be locale-dependent. It specifies the week-end days, as an array
// of comma-separated numbers. The numbers are from 0 to 6: 0 means Sunday, 1
// means Monday, etc.
Calendar._TT["WEEKEND"] = "0,6";

Calendar._TT["CLOSE"] = "Close";
Calendar._TT["TODAY"] = "Today";
Calendar._TT["TIME_PART"] = "(Shift-)Click or drag to change value";

// date formats
Calendar._TT["DEF_DATE_FORMAT"] = "%b %e, %Y";
Calendar._TT["TT_DATE_FORMAT"] = "%B %e, %Y";

Calendar._TT["WK"] = "Week";
Calendar._TT["TIME"] = "Time:";
//]]>
</script>
    
</div>
<script type="text/javascript">decorateGeneric($$('#product-options-wrapper dl'), ['last']);</script>
                                    </div>
                                    <?php
                                    $i=0;
                                     foreach($custmreslt as $row){
                                     	$i++;
                                     ?>
					                <div id="descriptionid<?php echo $i;?>" class="customize-product-image-wrapper" <?php if($i>1){?>style="margin-top:-104px; margin-left:4px; width:37.5%;padding:20px;display:none;"<?php }else{?> style="margin-top:-104px; margin-left:4px; width:37.5%;padding:20px;" <?php }?>>
					                                    <div class="custom-help-overlay"></div>
					                                    <div id="CustomHelp" class="custom-help">
					                                            <div class="modal-content">
																
																</div>
					                                    </div>
					                     <?php echo $row['customize_description']; ?>
					
					                </div>
					                <?php  }?>
                <div class="clearer"></div>

            </form>

		<script type="text/javascript">
		//<![CDATA[
			var productAddToCartForm = new VarienForm('product_addtocart_form');
			
			productAddToCartForm.submit = function(button, url) {
				if (this.validator.validate()) {
					var form = this.form;
					var oldUrl = form.action;

					if (url) {
					form.action = url;
					}
					var e = null;
					try {
						this.form.submit();
					} catch (e) {
					}
					this.form.action = oldUrl;
					if (e) {
						throw e;
					}

					if (button && button != 'undefined') {
						button.disabled = true;
					}
				}
			}.bind(productAddToCartForm);

			productAddToCartForm.submitLight = function(button, url){
				if(this.validator) {
					var nv = Validation.methods;
					delete Validation.methods['required-entry'];
					delete Validation.methods['validate-one-required'];
					delete Validation.methods['validate-one-required-by-name'];
					if (this.validator.validate()) {
						if (url) {
							this.form.action = url;
						}
						this.form.submit();
					}
					Object.extend(Validation.methods, nv);
				}
			}.bind(productAddToCartForm);
		//]]>
		</script>
    </div>
</div>
            </div>
        </div>
     </div>
</div>