<!-- BEGIN PAGE -->
		<div class="page-content">
			<h2><a href="<?php echo base_url()?>index.php/cms/home_page">Home</a></h2>
		</div>