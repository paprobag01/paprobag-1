<?php 
 class Customize extends CI_Controller{

		function __Construct(){
		
				parent::__construct();
               $this->load->model('cms/customize_model');
			}
      
	  function index(){
		  $result=$this->customize_model->get_customization_type();
		$result1=$this->customize_model->get_categories();
		 $data['step']='';
		   $data['custmtypes']=$result;
		  $data['page']='customization';
		  $data['type']='add';
		  $data['page_data']=$result;
		  $data['page_data3']=$result1;
		 $this->load->view('cms/header_view', $data);
		 $this->load->view('cms/add_customization_view', $data);
		 $this->load->view('cms/footer_view');
		
     }
	 function save_customization_type_page()
	 {
		 $i=$this->customize_model->save_customization_type();
		 if($i==1)
		 {
		 redirect('cms/customize');
		 }
		 else
		 {
			 die;
		 }
	 }
	 function save_customization_page()
	 {
		 $i=$this->customize_model->save_customization();
		 
		 if($i==1)
		 {
		 redirect('cms/customize');
		 }
		 else
		 {
			 die;
		 }
	 }
	 function listCustomizations()
	 {
		 $reslt=$this->customize_model->listCustomizations();
		  $data['page']='customization';
		  $data['custmdtls']=$reslt;
		 $this->load->view('cms/header_view', $data);
		 $this->load->view('cms/Customization_Listing');
		 $this->load->view('cms/footer_view');
	 }
	 function getCustomizations($customize_id=null, $cat_id=null)
	 {
		
		$arr['id']=$customize_id; 
		$arr['cat_id']=$cat_id;
		
		$reslt=$this->customize_model->getCustomizations($arr);
		$reslt1=$this->customize_model->getCategory($arr);
		$reslt2=$this->customize_model->getCategories();
		$reslt3=$this->customize_model->get_customization_type();
		
		
		 $reslt['type']='edit';
		$data['page_data']=$reslt;
		$data['page_data2']=$reslt1;
		$data['page_data4']=$reslt2;
		$data['page_data5']=$reslt3;
		$data['page']='customization';
		 $this->load->view('cms/header_view', $data);
		 $this->load->view('cms/add_customization_view', $data);
		 $this->load->view('cms/footer_view');
		
	 }
	 function viewCustomizations($customize_id=null,$cat_id=null)
	 {
		 
		$arr['id']=$customize_id; 
		$arr['cat_id']=$cat_id;
		
		$reslt=$this->customize_model->getCustomizations($arr);
		$reslt1=$this->customize_model->getCategory($arr);
		$reslt2=$this->customize_model->getCategories();
		$reslt3=$this->customize_model->get_customization_type();
		
		
		$reslt['type']='view';
		$data['page_data']=$reslt;
		$data['page_data2']=$reslt1;
		$data['page_data4']=$reslt2;
		$data['page_data5']=$reslt3;
		$data['page']='customization';
		 $this->load->view('cms/header_view', $data);
		 $this->load->view('cms/add_customization_view', $data);
		 $this->load->view('cms/footer_view');
	 }
	 function editCustomizationType()
	 {
		 $reslt=$this->customize_model->editCustomizationType();
		 $customize_id=$this->input->post('customize_id1');
		$reslt['type']='edit';
		
		$reslt1=$this->customize_model->get_customization_type();
		foreach($reslt1 as $rw)
		{
			$cat_id= $rw['cat_id'];
		}
		$data['page_data']=$reslt;
		$data['page_data1']=$reslt1;
		$this->getCustomizations($customize_id, $cat_id);
		/* $this->load->view('cms/header_view', $data);
		 $this->load->view('cms/add_customization_view', $data);
		 $this->load->view('cms/footer_view');*/
	 }
	 function editCustomizations()
	 {
		$reslt=$this->customize_model->editCustomizations(); 
		$customize_id=$this->input->post('customize_id');//custom_catid
		$cat_id=$this->input->post('custom_catid');
		$reslt['type']='edit';
		$reslt1=$this->customize_model->get_customization_type();
		
		$data['page_data']=$reslt;
		$data['page_data1']=$reslt1;
		$data['page']='customization';
		$this->getCustomizations($customize_id, $cat_id);
		/* $this->load->view('cms/header_view', $data);
		 $this->load->view('cms/add_customization_view', $data);
		 $this->load->view('cms/footer_view');*/
	 }
	 function deleteCustomization($custid)
	 {
		  $this->customize_model->deleteCustomization($custid);
		  $reslt=$this->customize_model->listCustomizations();
		  $data['page']='customization';
		  $data['custmdtls']=$reslt;
		 $this->load->view('cms/header_view', $data);
		 $this->load->view('cms/Customization_Listing');
		 $this->load->view('cms/footer_view');
	 }
	 
	
}
?>