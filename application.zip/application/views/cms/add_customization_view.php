<?php 
extract($page_data);

?>
<!-- BEGIN PAGE -->  
      <div class="page-content"> 
         <!-- BEGIN PAGE CONTAINER-->
         <div class="container-fluid">
            <!-- BEGIN PAGE HEADER-->   
            <div class="row-fluid">
               <div class="span12"> 
                  <h3 class="page-title">
                     <?php if($type=='view'){ echo "View"; } else if($type=='edit'){ echo "Edit";} else{ ?> Add <?php } ?> Customizations 
                  </h3> 
               </div>
            </div>
            <!-- END PAGE HEADER-->
            <!-- BEGIN PAGE CONTENT-->
            <div class="row-fluid">
               <div class="span12">
                  <!-- BEGIN SAMPLE FORM PORTLET-->   
                  <div class="portlet box blue">
                     <div class="portlet-title">
                        <h4><i class="icon-reorder"></i><?php if($type=='view'){ echo "View"; } else if($type=='edit'){ echo "Edit";} else{?>Add Customization details<?php }?></h4>
                        <div class="tools">
                           <a href="javascript:;" class="collapse"></a> 
                           <a href="javascript:;" class="remove"></a>
                        </div>
                     </div>
                     <div class="portlet-body form">
                        <!-- BEGIN FORM-->
                        <form <?php if($type=='add'){ ?>action="<?php echo base_url()?>cms/customize/save_customization_type_page" <?php }else{ ?>action="<?php echo base_url()?>cms/customize/editCustomizationType" <?php } ?> class="form-horizontal" method="post" enctype="multipart/form-data" />
						 <?php if($type=='edit'){ ?>
                         <input type="hidden" name="custom_cat_id" value="<?php echo $custom_cat_id;?>">
						  <input type="hidden" name="customize_id1" value="<?php echo $customize_id;?>">
						 <?php } ?>
						    <div class="control-group">
                              <label class="control-label">Customization Type</label>
                              <div class="controls">
                                 <input type="text"  name="custmztype" id="custmztype" <?php if($type=='view'){?>disabled<?php }?> value="<?php if($type=='edit' || $type=='view'){ echo $custom_type_name;}?>" class="span4  m-wrap" /> 
                              </div>
                           </div>
						   <div class="control-group">
                              <label class="control-label">Step</label>
                              <div class="controls">
                               
								  <input type="number" required name="custmzstep" id="custmzstep" <?php if($type=='view'){?>disabled<?php }?> value="<?php if($type=='edit' || $type=='view'){ echo $steps;}?>" class="span4  m-wrap" /> 
                              </div>
                           </div>
						   <div class="control-group">
                              <label class="control-label">Categories</label>
                              <div class="controls">
                                 <select name="cat_id" required <?php if($type=='view'){?>disabled<?php }?>>
								
								
									
									<?php 
									
									if($type=='edit' || $type=='view')
									{
									foreach($page_data2 as $row2)
									{
									?>
									<option value="$row2['cat_id']"><?php  echo $row2['category_name'];?></option>
									<?php 
									}
									foreach($page_data4 as $row2)
									{
									?>
									<option value="<?php echo $row2['cat_id']?>"><?php echo $row2['category_name']?></option>
									<?php
									}
									}
									else
									{
										?>
										<option value="">Select</option>
										<?php
									foreach($page_data3 as $row3)
									{
									?>
									 
									<option value="<?php echo $row3['cat_id']?>"><?php echo $row3['category_name']?></option>
									<?php
									}
									}
									?>
								 </select>
                              </div>
                           </div>
                          <?php if($type!='view'){?> <div class="form-actions">
                           <button type="submit" class="btn blue">Save</button>
                              <button type="button" class="cancel btn">Cancel</button>
                           </div><?php } ?>
						  </form> 
                        <!-- END FORM-->           
                     </div>
					 <div class="portlet-body form">
					
					 <form <?php if($type=='add'){ ?>action="<?php echo base_url()?>cms/customize/save_customization_page" <?php }else{ ?>action="<?php echo base_url()?>cms/customize/editCustomizations" <?php } ?> class="form-horizontal" method="post" enctype="multipart/form-data" />
						 <?php if($type=='edit'){ ?>
                         <input type="hidden" name="customize_id" value="<?php echo $customize_id;?>">
						 <input type="hidden" name="custom_catid" value="<?php echo $custom_cat_id;?>">
						 <?php } ?>
							 <div class="control-group">
                              <label class="control-label">Customization Type</label>
                              <div class="controls">
                                 <select name="custmztypeid" required <?php if($type=='view'){?>disabled<?php }?>>
								 
								 <?php 
								
									if($type=='edit')
									{
									foreach($page_data1 as $row)
									{
									?>
									<option value="<?php echo $row['custom_cat_id']?>"><?php  echo $row['custom_type_name'];?></option>
									<?php 
									}
									foreach($page_data5 as $row)
									{
									?>
									<option value="<?php echo $row['custom_cat_id']?>"><?php echo $row['custom_type_name']?></option>
									<?php
									}
									}
									else
									{
										?>
										<option value="">Select</option>
										<?php 
									foreach($page_data as $row1)
									{
									?>
									
									<option value="<?php echo $row1['custom_cat_id']?>"><?php echo $row1['custom_type_name']?></option>
									<?php
									}
									}
									?>
								 </select>
                              </div>
                           </div>
							<div class="control-group">
                              <label class="control-label">Customization Name</label>
                              <div class="controls">
                                <!-- <textarea  name="details"  id="ai" class="span12 ckeditor m-wrap" cols="30" rows="10">  </textarea> -->
								
								  <input type="text" <?php if($type=='view'){?>disabled<?php }?> name="custmzname" id="custmzname" class="span4  m-wrap" value="<?php if($type=='edit' || $type=='view'){ echo $custom_name;}?>"/> 
                              </div>
                           </div>
						   <div class="control-group">
                              <label class="control-label">Image :</label>
                              <div class="controls">
                                <div class="fileupload fileupload-new" data-provides="fileupload">
                                    <?php if($type=='edit'){ ?><div class="fileupload-new thumbnail" style="width: 200px; height: 150px;">
                                       <?php if($image_url!=""){?>
										<img src="<?php echo base_url().$image_url?>" /> 
										<?php } else {?>
									   <img src="<?php echo base_url()?>images/noimage.gif" alt="" />
									   <?php }?>
									   <input type="hidden" value="<?php echo $image_url; ?>" name="img_url">	
                                    </div><?php } ?>
                                    <div class="fileupload-preview fileupload-exists thumbnail" style="max-width: 200px; max-height: 150px; line-height: 20px;"></div>
                                    <div>
                                       <span class="btn btn-file"><span class="fileupload-new">Select image</span>
                                       <span class="fileupload-exists">Change</span>
                                       <input type="file" name="fileinput" <?php if($type=='view'){?>disabled<?php }?> class="default" /></span>
                                       <a href="#" class="btn fileupload-exists" data-dismiss="fileupload">Remove</a>
                                    </div>
									
                                 </div> 
                              </div>
                           </div> 
						   <div class="control-group">
                              <label class="control-label">Categories</label>
                              <div class="controls">
                                 <select name="cat_id1" required <?php if($type=='view'){?>disabled<?php }?>>
								<?php 
									
									if($type=='edit' || $type=='view')
									{
									foreach($page_data2 as $row2)
									{
									?>
									<option value="<?php echo $row2['cat_id'];?>"><?php  echo $row2['category_name'];?></option>
									<?php 
									}
									foreach($page_data4 as $row2)
									{
									?>
									<option value="<?php echo $row2['cat_id']?>"><?php echo $row2['category_name']?></option>
									<?php
									}
									}
									else
									{
										?>
										<option value="">Select</option>
										<?php 
									foreach($page_data3 as $row3)
									{
									?>
									 
									<option value="<?php echo $row3['cat_id']?>"><?php echo $row3['category_name']?></option>
									<?php
									}
									}
									?>
								 </select>
                              </div>
                           </div>
                            <?php if($type!='view'){?> <div class="form-actions">
                         <button type="submit" class="btn blue">Save</button>
                              <button type="button" class="cancel btn">Cancel</button>
						   
                           </div><?php }?>
					 </form>
					 </div>
                  </div>
                  <!-- END SAMPLE FORM PORTLET-->
               </div>
            </div>
			<script type="text/javascript">
			 $(document).ready(function(){
				$(".cancel").click(function()
					{

					document.location="<?php echo base_url()?>cms/customize";
				});             

				
		  });	
		  </script>	
			</div>
            </div>
			</div>