<?php 
class GetSubCatAjax extends CI_Model
{
	
    function get_subcategories($catids) {
		$data="";
        $query = $this->db->query("select sub_cat_id, sub_cat_name from subcategories where cat_id=$catids and deleted=0");
         
        
        
		return $query->result_array();
        }
		function get_filters($catids) {
		$data="";
        $query = $this->db->query("select * from filters where FIND_IN_SET('$catids', cat_ids) and deleted=0");
         
        
        
		return $query->result_array();
        }
	function get_filter_vals($id)
	{
			$query = $this->db->query("select * from filters where filter_id=$id and deleted=0");
		return $query->result_array();
	}
    
}
?>