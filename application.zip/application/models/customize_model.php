<?php 

class Customize_model extends CI_Model {
	public function __construct()
    {
        parent::__construct();
		$this->load->library('site_sentry');
    }
	
	/*public function Save_Customizations()
	{
	
		$customizations=$this->input->post('options');
		
		$_SESSION['CustomizeOptions']=$customizations;
		
		
		
			redirect('ContinueCheckout');
		
	}*/
	public function get_Customizations($id=null)
	{
	
		$sql=$this->db->query("select ct.custom_type_name as custom_type_name, ct.steps as steps, ct.customize_description as customize_description, c.customize_id as customize_id, c.custom_cat_id as custom_cat_id, c.custom_name as custom_name, c.custom_price as custom_price,  c.image_url as image_url FROM customize_type ct left join customizations c on ct.custom_cat_id = c.custom_cat_id where ct.cat_id=".$id." order by steps desc");
							
		$sql1=$this->db->query("select count(*) as cnt from (select * from customize_type where cat_id=".$id.") as cnts");
		
		$sql2=$this->db->query("select * from customize_type where cat_id=".$id." and deleted=0 order by steps");
		
		$sql3=$this->db->query("select count(distinct(custom_type_name)) as custom_type_name from (select ct.custom_type_name as custom_type_name, ct.steps as steps, c.customize_id as customize_id, c.custom_cat_id as custom_cat_id, c.custom_name as custom_name, c.image_url as image_url FROM customize_type ct left join customizations c on ct.custom_cat_id = c.custom_cat_id where ct.cat_id=".$id." and c.cat_id=".$id.") as dist");
		
		$sqlResltArr=array($sql->result_array(), $sql1->result_array(), $sql2->result_array(), $sql3->result_array());
		//$this->db->trans_complete();
		return $sqlResltArr;
		
	}
	public function listCustomizations()
	{
		
	}
}
?>