<!DOCTYPE html>
<html>
<head>

		<!-- Basic -->
		<meta charset="utf-8">
		<title>Paprobag.com</title>		
		<meta name="keywords" content="HTML5 Template" />
		<meta name="description" content="Marvel - MultiShop Responsive HTML5 Template">
		<meta name="author" content="pixelgeeklab.com">

		<!-- Mobile Metas -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
		<link href="<?php echo base_url()?>admin/bootstrap-fileupload/bootstrap-fileupload.css" rel="stylesheet" />
<link href="<?php echo base_url()?>css/imgUploadstyle.css" rel="stylesheet" />
<link href="<?php echo base_url()?>css/jquery-ui.css" rel="stylesheet" />
<script type="text/javascript" src="<?php echo base_url()?>js/jquery-ui.js"></script>
<script type="text/javascript" src="<?php echo base_url()?>js/jquery.form.js"></script>
<script type="text/javascript" src="<?php echo base_url()?>js/uploader.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/normalize.css" />
		<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/demo.css" />
		<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/component.css" />
<script type="text/javascript">
window.addEventListener("load", function() {

    // handle image preview
    var input      = document.getElementById("photo");
    var img        = document.getElementById("img");
    var previewBtn = document.getElementById("preview");
    previewBtn.addEventListener("click", function() {
        img.src = input.files[0].getAsDataURL();
    }, false);

    // handle file upload
    var form      = document.getElementsById("ImageProcess")[0];
    var uploader  = new Uploader(form);
    var uploadBtn = document.getElementById("upload");
    uploadBtn.addEventListener("click", function() {
        uploader.send();
    }, false);

}, false);
</script>
		<?php 

if(isset($measurement))
{
?>
<script type="text/javascript"> var skinUrl = '<?php echo base_url()?>allmeasurementfiles/skin/frontend/default/blacklapel/';</script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/e618606b3154462df417bf12d682a9e6.css" media="all" />
<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>css/dbab80f81a011309b8791100c571ba00.css" media="print" />

<link rel="stylesheet" href="<?php echo base_url()?>vendor/fontawesome/css/font-awesome.css">
<script type="text/javascript" src="<?php echo base_url(); ?>js/8d08f920f0bde5e0042f6d5cf5e71f8b.js" global_header></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/e231a5f6ec4b057efa20f72992e06780.js"></script>

<!--[if lt IE 8]>
<link rel="stylesheet" type="text/css" href="http://www.blacklapel.com/media/css/815df5309df491d3bddab8f4b7053761.css" media="all" />
<![endif]-->
<!--[if lt IE 7]>
<script type="text/javascript" src="http://www.blacklapel.com/media/js/6b732f23679251267070ef1f80dd8411.js"></script>
<![endif]-->



<script type="text/javascript">
//<![CDATA[
optionalZipCountries = ["AF","AL","DZ","AS","AD","AO","AI","AQ","AG","AR","AM","AW","AU","AT","AZ","BS","BH","BD","BB","BY","BE","BZ","BJ","BM","BT","BO","BA","BW","BV","BR","IO","VG","BN","BG","BF","BI","KH","CM","CA","CV","KY","CF","TD","CL","CN","CX","CC","CO","KM","CG","CD","CK","CR","HR","CU","CY","CZ","CI","DK","DJ","DM","DO","EC","EG","SV","GQ","ER","EE","ET","FK","FO","FJ","FI","FR","GF","PF","TF","GA","GM","GE","DE","GH","GI","GR","GL","GD","GP","GU","GT","GG","GN","GW","GY","HT","HM","HN","HK","HU","IS","IN","ID","IR","IQ","IE","IM","IL","IT","JM","JP","JE","JO","KZ","KE","KI","KW","KG","LA","LV","LB","LS","LR","LY","LI","LT","LU","MO","MK","MG","MW","MY","MV","ML","MT","MH","MQ","MR","MU","YT","MX","FM","MD","MC","MN","ME","MS","MA","MZ","MM","NA","NR","NP","NL","AN","NC","NZ","NI","NE","NG","NU","NF","KP","MP","NO","OM","PK","PW","PS","PA","PG","PY","PE","PH","PN","PL","PT","PR","QA","RO","RU","RW","RE","BL","SH","KN","LC","MF","PM","VC","WS","SM","SA","SN","RS","SC","SL","SG","SK","SI","SB","SO","ZA","GS","KR","ES","LK","SD","SR","SJ","SZ","SE","CH","SY","ST","TW","TJ","TZ","TH","TL","TG","TK","TO","TT","TN","TR","TM","TC","TV","UM","VI","UG","UA","AE","GB","US","UY","UZ","VU","VA","VE","VN","WF","EH","YE","ZM","ZW","AX"];
//]]>
</script>
<script type="text/javascript">var Translator = new Translate({"Please use only letters (a-z or A-Z), numbers (0-9) or underscore(_) in this field, first character should be a letter.":"Please use only letters (a-z or A-Z), numbers (0-9) or underscores (_) in this field, first character must be a letter."});</script><meta name="google-site-verification" content="TiX6AR1f4dF-eBKf54LnDkKr6rqqsckdJqjO6Yb51fU" />
<link rel="stylesheet" href="<?php echo base_url()?>css/theme.css">
<!-- PaagmVNa3AHrsUP-3shNZ-d0LNI -->
<script type="text/javascript" src="allmeasurementfiles/use.typekit.net/zgh3skp.js"></script>
<script type="text/javascript">try{Typekit.load();}catch(e){}</script>
<?php 
}
else if(isset($customize))
{
?>



<script type="text/javascript" src="<?php echo base_url()?>js/jquery-1.8.2.min.js"></script>
<script type="text/javascript" src="<?php echo base_url()?>js/jquery.livequery.js"></script>
<link rel="stylesheet" href="<?php echo base_url()?>vendor/fontawesome/css/font-awesome.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/83996e5fc1a36f31ed181848956c8294.css" />
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/0370055d2bf1d05fcfdde50ff6a20b78.css" media="all" />
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/dbab80f81a011309b8791100c571ba00.css" media="print" />



<link rel="stylesheet" href="<?php echo base_url()?>vendor/fontawesome/css/font-awesome.css">
		<link rel="stylesheet" href="<?php echo base_url()?>vendor/owlcarousel/owl.carousel.css" media="screen">
		<link rel="stylesheet" href="<?php echo base_url()?>vendor/owlcarousel/owl.theme.css" media="screen">
		<link rel="stylesheet" href="<?php echo base_url()?>vendor/owl-carousel/owl.transitions.html"  media="screen">
		<link rel="stylesheet" href="<?php echo base_url()?>vendor/flexslider/flexslider.css" media="screen">
		<link rel="stylesheet" href="<?php echo base_url()?>vendor/chosen/chosen.css" media="screen">
		<link rel="stylesheet" href="<?php echo base_url()?>vendor/magnific-popup/magnific-popup.css" media="screen">


		
		<link rel="stylesheet" href="<?php echo base_url()?>css/theme-animate.css">
		<link rel="stylesheet" href="<?php echo base_url()?>css/style2.css">
		
		<script src="<?php echo base_url()?>vendor/modernizr/modernizr.js"></script>
		
<script type="text/javascript" src="<?php echo base_url();?>js/8d08f920f0bde5e0042f6d5cf5e71f8b.js" global_header></script>
<script type="text/javascript" src="<?php echo base_url();?>js/a8163ee17832d4adee2af561842fd0ff.js"></script>
<script type="text/javascript"> var skinUrl = 'http://www.blacklapel.com/skin/frontend/default/blacklapel/';</script>
<!--[if lt IE 8]>
<link rel="stylesheet" type="text/css" href="http://www.blacklapel.com/media/css/815df5309df491d3bddab8f4b7053761.css" media="all" />
<![endif]-->
<!--[if lt IE 7]>
<script type="text/javascript" src="http://www.blacklapel.com/media/js/6b732f23679251267070ef1f80dd8411.js"></script>
<![endif]-->

<link rel="stylesheet" href="<?php echo base_url()?>css/theme.css">

<script type="text/javascript">
//<![CDATA[
optionalZipCountries = ["AF","AL","DZ","AS","AD","AO","AI","AQ","AG","AR","AM","AW","AU","AT","AZ","BS","BH","BD","BB","BY","BE","BZ","BJ","BM","BT","BO","BA","BW","BV","BR","IO","VG","BN","BG","BF","BI","KH","CM","CA","CV","KY","CF","TD","CL","CN","CX","CC","CO","KM","CG","CD","CK","CR","HR","CU","CY","CZ","CI","DK","DJ","DM","DO","EC","EG","SV","GQ","ER","EE","ET","FK","FO","FJ","FI","FR","GF","PF","TF","GA","GM","GE","DE","GH","GI","GR","GL","GD","GP","GU","GT","GG","GN","GW","GY","HT","HM","HN","HK","HU","IS","IN","ID","IR","IQ","IE","IM","IL","IT","JM","JP","JE","JO","KZ","KE","KI","KW","KG","LA","LV","LB","LS","LR","LY","LI","LT","LU","MO","MK","MG","MW","MY","MV","ML","MT","MH","MQ","MR","MU","YT","MX","FM","MD","MC","MN","ME","MS","MA","MZ","MM","NA","NR","NP","NL","AN","NC","NZ","NI","NE","NG","NU","NF","KP","MP","NO","OM","PK","PW","PS","PA","PG","PY","PE","PH","PN","PL","PT","PR","QA","RO","RU","RW","RE","BL","SH","KN","LC","MF","PM","VC","WS","SM","SA","SN","RS","SC","SL","SG","SK","SI","SB","SO","ZA","GS","KR","ES","LK","SD","SR","SJ","SZ","SE","CH","SY","ST","TW","TJ","TZ","TH","TL","TG","TK","TO","TT","TN","TR","TM","TC","TV","UM","VI","UG","UA","AE","GB","US","UY","UZ","VU","VA","VE","VN","WF","EH","YE","ZM","ZW","AX"];
//]]>
</script>
<script type="text/javascript">var Translator = new Translate({"Please use only letters (a-z or A-Z), numbers (0-9) or underscore(_) in this field, first character should be a letter.":"Please use only letters (a-z or A-Z), numbers (0-9) or underscores (_) in this field, first character must be a letter."});</script><meta name="google-site-verification" content="TiX6AR1f4dF-eBKf54LnDkKr6rqqsckdJqjO6Yb51fU" />

<!-- PaagmVNa3AHrsUP-3shNZ-d0LNI -->

<script type="text/javascript">try{Typekit.load();}catch(e){}</script>
<?php
}
else if(isset($gallery))
{
	?>
	
	<script type="text/javascript" src="<?php echo base_url()?>js/jquery-1.8.2.min.js"></script>
<link href="<?php echo base_url() ?>css/style1.css" title="style" rel="stylesheet" type="text/css" />
<link id="clink" href="<?php echo base_url() ?>css/style-blue.css" title="style" rel="stylesheet" type="text/css" media="screen"/>
<script type="text/javascript" src="<?php echo base_url()?>js/jquery.livequery.js"></script>

<?php 
}
else
{
?>
		
		<!-- Web Fonts  -->
		<link href='http://fonts.googleapis.com/css?family=Dosis:300,400,500,600,700' rel='stylesheet' type='text/css'>

		<!-- Vendor CSS -->
		<link rel="stylesheet" href="<?php echo base_url() ?>vendor/fontawesome/css/font-awesome.css">
		<link rel="stylesheet" href="<?php echo base_url() ?>vendor/owlcarousel/owl.carousel.css" media="screen">
		<link rel="stylesheet" href="<?php echo base_url() ?>vendor/owlcarousel/owl.theme.css" media="screen">
		<link rel="stylesheet" href="<?php echo base_url() ?>vendor/owl-carousel/owl.transitions.html"  media="screen">
		<link rel="stylesheet" href="<?php echo base_url() ?>vendor/flexslider/flexslider.css" media="screen">
		<link rel="stylesheet" href="<?php echo base_url() ?>vendor/chosen/chosen.css" media="screen">
		<link rel="stylesheet" href="<?php echo base_url() ?>vendor/magnific-popup/magnific-popup.css" media="screen">

		<!-- Theme CSS -->
		<link rel="stylesheet" href="<?php echo base_url() ?>css/theme.css">
		
		<link rel="stylesheet" href="<?php echo base_url() ?>css/theme-animate.css">

		<!-- Style Switcher-->
		<link rel="stylesheet" href="<?php echo base_url() ?>style-switcher/css/style-switcher.css">
		<link rel="stylesheet" href="<?php echo base_url() ?>css/colors/default/style.html" id="layoutstyle">
		
		<link rel="stylesheet" href="<?php echo base_url() ?>css/style.css">
    <!-- <link href="css/bootstrap.css" rel="stylesheet"> -->

		<link rel="stylesheet" href="<?php echo base_url() ?>fonts/icomoon/iconmoon.css">
		<!-- Head libs -->
		<script src="<?php echo base_url()?><?php echo base_url()?>vendor/modernizr/modernizr.js"></script>
		<!--  <script type="text/javascript" src="<?php echo base_url()?><?php echo base_url()?>Vistaprint_files/jquery.clickChild_min.js"></script> -->
		
		<!--- vist ---->
		<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>Vistaprint_files/css(1).css">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>Vistaprint_files/css(2).css">
		<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>Vistaprint_files/vpfooter.vistaprint_less_min.css">

		<!--[if IE]>
			<link rel="stylesheet" href="<?php echo base_url() ?>css/ie.css">
		<![endif]-->

		<!--[if lte IE 8]>
			<script src="<?php echo base_url()?>vendor/respond/respond.js"></script>
			<script src="<?php echo base_url()?>vendor/excanvas/excanvas.js"></script>
		<![endif]-->
		<?php }?>
	<style>
	/* rotator in-page placement */
    div.rotator {
    position:relative;
    
    display:none;
}
/* rotator css */
    div.rotator ul {
    margin:0;
    padding:0;
}
    div.rotator ul li {
    float:left;
    position:absolute;
    list-style: none;
}
/* rotator image style */
    div.rotator ul li img {
    /* border:1px solid #ccc; */
    padding: 4px;
    background: #FFF;
	height: 198px;	
}
    div.rotator ul li.show {
    z-index:500;
	
}
 div.rotator ul li.hid {
    margin-left:20px;
	margin-top:20px;
}



.transparent {
  
 /* border: 1px solid #000; */
  color: #444 !important;
  font-size: 16px;
  font-weight: 700;
  letter-spacing: 1px;
  line-height: 31px;
  margin: 0;
  padding: 0 10px;
  text-transform: uppercase;
  top: 0px;
  height: 120px;
  margin-left: 100px;
margin-right: 100px;
position:relative;
box-shadow: 10px 10px 5px #888888;
}
.transparent1 {
  background: none repeat scroll 0 0 transparent;
 
  color: #444 !important;
  font-size: 16px;
  font-weight: 700;
  letter-spacing: 1px;
  line-height: 31px;
  margin: 0;
  padding: 0 10px;
  text-transform: uppercase;
  top: 0px;
}

.transparent:hover {
 /* background: #D5D5D5; */
  /*border: 1px solid #717171;*/
}
.transparent1:hover {
  /*background: #D5D5D5;*/

}
.dimensns
{
background-color: #222222;
border-top: 2px solid #dd4e4e;
color: #fff;
display: table;
height: 57px;
margin-bottom: 30px;
text-align: center;
width: 100%;
}
.line2 {
background: #e8e8e8;
height: 1px;
margin: 12px 0 6px 0;
padding: 0;
display: block;

}
.footerimg
{

margin-top: -68px;
height: auto;
max-width: 100%;
vertical-align: middle;
border: 0;
}
.shopp, .cart-total {
border: solid #ccc 1px;
padding: 8px;
-webkit-border-radius: 8px;
-moz-border-radius: 8px;
font-size: 12px;
background: url(remove.png) center right no-repeat 5px;
border-radius: 8px;
font-family: "LubalGraphBdBTBold",Tahoma;
margin-bottom: 3px;
width: 260px;
}
	</style>
	<!-- <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js" type="text/javascript"></script>--><!-- By Dylan Wagstaff, http://www.alohatechsupport.net -->
	<script type="text/javascript">// <![CDATA[
function theRotator() {
    //Set the opacity of all images to 0
    $('div.rotator ul li').css({opacity: 0.0});
 
    //Get the first image and display it (gets set to full opacity)
    $('div.rotator ul li:first').css({opacity: 1.0});
 
    //Call the rotator function to run the slideshow, 6000 = change to next image after 6 seconds
 
    if ($('div.rotator ul li').length > 1) {
    setTimeout('rotate()', 1000);
}
}
 
function rotate() {
    //Get the first image
    var current = ($('div.rotator ul li.show')? $('div.rotator ul li.show') : $('div.rotator ul li:first'));
 
    if ( current.length == 0 ) current = $('div.rotator ul li:first');
 
    //Get next image, when it reaches the end, rotate it back to the first image
    var next = ((current.next().length) ? ((current.next().hasClass('show')) ? $('div.rotator ul li:first') :current.next()) : $('div.rotator ul li:first'));
 
    //Un-comment the 3 lines below to get the images in random order
 
    //var sibs = current.siblings();
    //var rndNum = Math.floor(Math.random() * sibs.length );
    //var next = $( sibs[ rndNum ] );
 
    //Set the fade in effect for the next image, the show class has higher z-index
    next.css({opacity: 0.0}).addClass('show').animate({opacity: 1.0}, 1000);
 
    //Hide the current image
    current.animate({opacity: 1.0}, 1000, function(){setTimeout('rotate()', 1000);}) .removeClass('show');
 
};
 
$(document).ready(function() {
    //Load the slideshow
    theRotator();
    $('div.rotator').fadeIn(1000);
    $('div.rotator ul li').fadeIn(1000); // tweek for IE
});
// ]]></script>

	</head>
	<body class="front bg-pattern-dark">
		<div class="body">
			<header id="header" class="header-light">
			
				
				<div class="container">
				<!-- <div class="container text-center"> -->
					<div class="navbar-header">
						<a href="#offcanvas" class="uk-navbar-toggle hidden-lg pull-right" data-uk-offcanvas>
							<span class="sr-only">Toggle navigation</span>
							<i class="fa fa-bars"></i>
						</a>
						<h1 class="logo">
							<a href="<?php echo base_url() ?>"><img alt="Marvel" src="<?php echo base_url()?>images/paprobagLogo.png"></a>
							
						</h1>
						
					</div>
					
					
					
					<!--  -->
					<div class="light-header-top" >
					
						<nav >
							<ul class="nav nav-pills nav-top nav-top-right">
							
							
								<li class="login">
									<a data-target=".form-wrapper" data-toggle="modal" href="javascript:void(0);"><i class="fa fa-phone-square"> 022-22449977</i></a> <!-- <i class="fa fa-user"></i> --></a>
								</li>
								
								<!--<li class="dropdown langs">
									<a class="dropdown-toggle" data-toggle="dropdown" href="#"><i class="fa fa-globe"></i> <span>English</span> <i class="fa fa-caret-down"></i></a>
									<ul class="dropdown-menu">
										<li><a href="#">French</a></li>
										<li><a href="#">Japanese</a></li>
										<li><a href="#">Danish</a></li>
									</ul>
								</li>-->
								
								
								<li class="login">
									<a href="<?php echo base_url()?>loginToAccount"><i class="fa fa-user"></i> Login</a> | <a href="<?php echo base_url()?>createAccount">Sign Up <!-- <i class="fa fa-user"></i> --></a>
								</li>
								<li class="login">
									<a data-target=".form-wrapper" data-toggle="modal" href="javascript:void(0);">Refer & Earn <!-- <i class="fa fa-user"></i> --></a>
								</li>
								<li class="shopping-cart">
									<img src="<?php echo base_url()?>images/bag.png"/><a href="#offcanvas-cart" data-uk-offcanvas>My Bag <!--<i class="fa fa-shopping-cart"></i>--> <span>(<span id="cartqty"><?php if(isset($_SESSION['cartqty'])){echo $_SESSION['cartqty'];}else{?>0<?php }?></span>)</span></a>
								</li>
							</ul>
						</nav>
						
						

				</div>
				
				<div style=""></div>
				
						
						
					<!--<ul class="nav nav-pills nav-top nav-top-right">
						<li class="login">
							<a data-target=".form-wrapper" data-toggle="modal" href="javascript:void(0);"><i class="fa fa-user"></i> <span>Login/Register</span></a>
						</li>
						<li class="shopping-cart">
							<a href="#offcanvas-cart" data-uk-offcanvas><i class="fa fa-shopping-cart"></i> <span>(<span>0</span>)</span></a>
						</li>
					</ul> 
					<ul class="nav nav-pills nav-top nav-top-left">
						<li class="dropdown langs">
							<a class="dropdown-toggle" data-toggle="dropdown" href="#"><i class="fa fa-globe"></i> <span>English</span> <i class="fa fa-caret-down"></i></a>
							<ul class="dropdown-menu">
								<li><a href="#">French</a></li>
								<li><a href="#">Japanese</a></li>
								<li><a href="#">Danish</a></li>
							</ul>
						</li>
						<li class="search"><a data-target=".search-wrapper" data-toggle="modal" href="javascript:void(0);"><i class="fa fa-search"></i></a></li>
						<li class="menu-icon hidden-lg">
							<a href="#offcanvas" class="uk-navbar-toggle" data-uk-offcanvas>
								<span class="sr-only">Toggle navigation</span>
								<i class="fa fa-bars"></i>
							</a>
						</li>
					</ul>
					<h1 class="logo">
						<a href="index.html"><img alt="Marvel" src="<?php echo base_url()?>images/logo2.png"></a>
					</h1>-->
					
										<script> 
										function changeByPaperBag()
										{
										
										document.getElementById("chosebyprodimg").style.backgroundImage = "url('<?php echo base_url()?>images/megamenu/carry-bags-250x250.jpg')";
										
										}
										function changeByEcoBag()
										{
										
										document.getElementById("chosebyprodimg").style.backgroundImage = "url('<?php echo base_url()?>images/megamenu/ecobags.jpg')";
										
										}
										function changeByBoxes()
										{
										
										document.getElementById("chosebyprodimg").style.backgroundImage = "url('<?php echo base_url()?>images/megamenu/box1.jpg')";
										
										}
										function changeByPouches()
										{
										
										document.getElementById("chosebyprodimg").style.backgroundImage = "url('<?php echo base_url()?>images/megamenu/pouches.jpg')";
										
										}
										function changeByOfficeProd()
										{
										
										document.getElementById("chosebyprodimg").style.backgroundImage = "url('<?php echo base_url()?>images/megamenu/Green-Office-Supplies-Pack.jpg')";
										
										}
										</script>
						<nav class="nav-main pull-left" style="width:1200px;">
							<ul class="nav nav-pills nav-main-menu">
							<li class="dropdown megamenu">
									<a class="dropdown-toggle" data-toggle="dropdown" href="#">Customize Now</a>
									<div class="dropdown-menu" style="width:100%;height:auto;">
										<div class="col-md-2" style="width:165px;border-bottom:1px solid #eed; border-right:1px solid #eed;">
											
											<ul style="list-style: none;border;padding-left:0px;">
												<li id="chosebyPaperBag" onmouseover="changeByPaperBag()"><b>Paper Bags</b></li>
												<li><a>Shopping carry Bags</a></li>
												<li><a>Handmade Paper Bags</a></li>
												<li><a>Food Parcel Bags</a></li>
												<li><a>Glossary Bags</a></li>
												<li><a>Wine Bags</a></li>
												<li><a>News Paper Bags</a></li>
												<li><a>Medical Bags</a></li>
											</ul>
										</div>
										<div class="col-md-2" style="margin-left:0px;border-top:1px solid #eed; width:128px;">
												<ul style="list-style: none;margin-left:-30px">
												<li onmouseover="changeByEcoBag()"><b>Eco Bags</b></li>
												<li><a>Nonwoven Bags</a></li>
												<li><a>Woven Bags</a></li>
												<li><a>Jute Bags</a></li>
												<li><a>Canvas Bags</a></li>
												<li><a>Cotton Bags</a></li>
												<li><a>Khadi Bags</a></li>
												<li><a>Bamboo Bags</a></li>
												</ul>
										</div>
										<div class="col-md-2" style="border-left:1px solid #eed;border-right:1px solid #eed;border-bottom:1px solid #eed;width:167px">
												<ul style="list-style: none;margin-left:-30px;">
												<li onmouseover="changeByBoxes()"><b>Boxes</b></li>
												<li><a>Mailing Boxes</a></li>
												<li><a>Packaging & Courier Boxes</a></li>
												<li><a>Food Boxes</a></li>
												<li><a>Chocolate Boxes</a></li>
												<li><a>Sweet Boxes</a></li>
												<li><a>FMCG Products Boxes</a></li>
												</ul>
										</div>
										<div class="col-md-2" style="border-top:1px solid #eed;width:130px;">
												<ul style="list-style: none;margin-left:-30px;">
												<li onmouseover="changeByPouches()"><b>Pouches</b></li>
												<li><a>Non woven Pouches</a></li>
												<li><a>Woven Pouches</a></li>
												<li><a>Jute Pouches</a></li>
												<li><a>Canvas Pouches</a></li>
												<li><a>Cotton Pouches</a></li>
												<li><a>Mix Pouches</a></li>
												</ul>
										</div>
										<div class="col-md-2" style="border-right:1px solid #eed;border-bottom:1px solid #eed;border-left:1px solid #eed;width:140px;">
												<ul style="list-style: none;margin-left:-30px;">
												<li onmouseover="changeByOfficeProd()"><b>Office Products</b></li>
												<li><a>Envelops</a></li>
												<li><a>Mailing Boxes</a></li>
												<li><a>Corporate Gift Boxes</a></li>
												<li><a>Handmade Dairy</a></li>
												<li><a>Stickers</a></li>
												<li><a>Pamphlets</a></li>
												<li><a>Mascot</a></li>
												</ul>
										</div>
										<div class="col-md-2" style="border-right:1px solid #eed;border-top:1px solid #eed;width:145px">
												<ul style="list-style: none;margin-left:-30px;">
												<li><b>Accessories</b></li>
												<li><a>Tags</a></li>
												<li><a>Shut Cover</a></li>
												<li><a>Hanger</a></li>
												<li><a>Tissue Paper</a></li>
												<li><a>Color News Paper</a></li>
												</ul>
										</div>
										<div class="col-md-2" id="chosebyprodimg" style="margin-left:50px;width:270px;height:270px;background-image:url('<?php echo base_url()?>images/megamenu/carry-bags-250x250.jpg')">
												
										</div>
										
										
										
									</div>
								 
								</li>
								
								
								<li class="dropdown megamenu">
									<a class="dropdown-toggle" data-toggle="dropdown" href="#">Ready To Print</a>
									<div class="dropdown-menu" style="width:50%">
										<div class="col-md-2" style="width:195px;border-bottom:1px solid #eed; border-right:1px solid #eed;">
											
											<ul style="list-style: none;border;padding-left:0px;">
												<li><b>Non Woven Bags</b></li>
												<li><a>D-cut Handle Bags</a></li>
												<li><a>Vertical Loop Handle Bags</a></li>
												<li><a>Horizontal Loop Handle Bag</a></li>
												<li><a>W&U Cut Bags</a></li>
												
											</ul>
										</div>
										<div class="col-md-2" style="margin-left:0px;border-top:1px solid #eed; width:128px;">
												<ul style="list-style: none;margin-left:-30px">
												<li><b>Paper Bag</b></li>
												<li><a>Brown Kraft.B</a></li>
												<li><a>White Kraft</a></li>
												<li><a>Color Kraft</a></li>
												<li><a>Glossy Bags</a></li>
												<li><a>Counter Bags</a></li>
												
												</ul>
										</div>
										
										<div class="col-md-2" style="width:270px;height:250px;background-image:url('<?php echo base_url()?>images/megamenu/carry-bags-250x250.jpg')">
												
										</div>
										
									</div>
								 
								</li>
								<li class="dropdown megamenu">
									<a class="dropdown-toggle" data-toggle="dropdown" href="#">Ready to deliver</a>
									 
									 <div class="dropdown-menu" style="width:1000px;margin-bottom:-100px;">
										<div class="mega-menu-content">
											<div class="row">
												<!-- <div class="col-md-3 menu-column">
													<div class="menu-column-inner">
														<h3>Categories</h3>
														<ul>
															<li>Nonwoven Bags</li>
															<li>Woven Bags</li>
															<li>Jute Bags</li>
															<li>Canvas Bags</li>
															<li>Cotton Bags</li>
															<li>Khadi Bags</li>
															<li>Bamboo Bags</li>
															<li>Envelops</li>
															<li>Mailing Boxes</li>
															<li>Corporate Gift Boxes</li>
															<li>Handmade Dairy</li>
															<li>Stickers</li>
														</ul>
													</div>
												</div> -->
												<div class="col-md-4 menu-column">
													<div class="menu-column-inner">
														<h3>Retail</h3>
														<div class="thumb-item">
															<div class="thumb-item-img">
																<img class="img-responsive" src="<?php echo base_url()?>images/products/product-4.jpg" width="263" alt="">
																<span class="thumb-act thumb-act-first">
																	<a href="#" class="btn-cart"><i class="fa fa-shopping-cart"></i></a>
																	<a data-target="#quickview-detail" data-toggle="modal" href="javascript:void(0);"><i class="fa fa-eye"></i></a>
																	<a href="#"><i class="fa fa-heart-o"></i></a>
																	<a href="#"><i class="fa fa-exchange"></i></a>
																</span>
															</div>
															<div class="thumb-item-content">
																<div class="star-rating pull-right" title="Rated 5.00 out of 5">
																	<span style="width:100%"><strong class="rating">5.00</strong> out of 5</span>
																</div>
																<h3><a href="#">Non Woven Bags</a></h3>
																<p class="product-price"><del>$150.00</del> <ins>$280.00</ins></p>
															</div>
														</div>
														<!-- <div class="countdown countdown-big" data-countdown="Jul 7, 2014 5:30:00"></div> -->
													</div>
												</div>
												
												<div class="col-md-4 menu-column">
													<div class="menu-column-inner">
														<h3>Offers</h3>
														<div class="thumb-item">
															<div class="thumb-item-img">
																<img class="img-responsive" src="<?php echo base_url()?>images/products/product-4.jpg" alt="">
																<span class="thumb-act thumb-act-first">
																	<a href="#" class="btn-cart"><i class="fa fa-shopping-cart"></i></a>
																	<a data-target="#quickview-detail" data-toggle="modal" href="javascript:void(0);"><i class="fa fa-eye"></i></a>
																	<a href="#"><i class="fa fa-heart-o"></i></a>
																	<a href="#"><i class="fa fa-exchange"></i></a>
																</span>
															</div>
															<div class="thumb-item-content">
																<div class="star-rating pull-right" title="Rated 5.00 out of 5">
																	<span style="width:100%"><strong class="rating">5.00</strong> out of 5</span>
																</div>
																<h3><a href="#">Non Woven Bags</a></h3>
																<p class="product-price"><del>$150.00</del> <ins>$280.00</ins></p>
															</div>
														</div>
														<!-- <div class="countdown countdown-big" data-countdown="Jul 7, 2014 5:30:00"></div> -->
													</div>
												</div>
												
												<div class="col-md-4 menu-column">
													<div class="menu-column-inner">
														<h3>Wholesale</h3>
														<div class="thumb-item">
															<div class="thumb-item-img">
																<img class="img-responsive" src="<?php echo base_url()?>images/products/product-4.jpg" alt="">
																<span class="thumb-act thumb-act-first">
																	<a href="#" class="btn-cart"><i class="fa fa-shopping-cart"></i></a>
																	<a data-target="#quickview-detail" data-toggle="modal" href="javascript:void(0);"><i class="fa fa-eye"></i></a>
																	<a href="#"><i class="fa fa-heart-o"></i></a>
																	<a href="#"><i class="fa fa-exchange"></i></a>
																</span>
															</div>
															<div class="thumb-item-content">
																<div class="star-rating pull-right" title="Rated 5.00 out of 5">
																	<span style="width:100%"><strong class="rating">5.00</strong> out of 5</span>
																</div>
																<h3><a href="#">Non Woven Bags</a></h3>
																<p class="product-price"><del>$150.00</del> <ins>$280.00</ins></p>
															</div>
														</div>
														<!-- <div class="countdown countdown-big" data-countdown="Jul 7, 2014 5:30:00"></div> -->
													</div>
												</div>
												
											</div>
											
										</div>
									</div> 
								</li>
								<li class="dropdown megamenu">
									<a class="dropdown-toggle" data-toggle="dropdown" href="#">Ecological Ad Bags</a>
									
								 
								</li>
								<li style="width:450px">
								<div class="col-md-12" style="margin-left:20px; margin-bottom:2px;margin-top:-10px">
								<form class="form-inline form-search" role="form">
						<div class="form-group">
							<label class="sr-only" for="textsearch">Enter text search</label>
							<input type="text" class="form-control" style="border-bottom:1px solid #eed;" id="textsearch" placeholder="Enter text search">
						</div>
						<button type="submit" class="btn btn-default1" style="background: #fff;border-bottom:1px solid #eed;"><i class="fa fa-search"></i></button>
						</form>
						</div>
								</li>
								
								
								<li class="dropdown" style="float:right;">
									<a class="dropdown-toggle" data-toggle="dropdown" href="#"><span><i class="fa fa-cogs"></i></span> Customize</a>
								 
								</li> 
								
							</ul>
							
						</nav>
					</div>
</header>