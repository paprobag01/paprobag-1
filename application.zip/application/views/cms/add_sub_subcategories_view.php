<?php 
extract($page_data);
extract($page_data4);
extract($page_data1);
?>
<!-- BEGIN PAGE -->  
      <div class="page-content"> 
         <!-- BEGIN PAGE CONTAINER-->
         <div class="container-fluid">
            <!-- BEGIN PAGE HEADER-->   
            <div class="row-fluid">
               <div class="span12"> 
                  <h3 class="page-title">
                     Create Sub-Subcategories
                  </h3> 
				   <p style="text-align:right"><button type="button" id="add_new" class="btn blue">View Subcategory Details</button></p>			
               </div>
            </div>
            <!-- END PAGE HEADER-->
            <!-- BEGIN PAGE CONTENT-->
            <div class="row-fluid">
               <div class="span12">
                  <!-- BEGIN SAMPLE FORM PORTLET-->   
				 
                  <div class="portlet box blue">
                     <div class="portlet-title">
                        <h4><i class="icon-reorder"></i>Add Subcategory details</h4>
                        <div class="tools">
                           <a href="javascript:;" class="collapse"></a> 
                           <a href="javascript:;" class="remove"></a>
                        </div>
                     </div>
                     <div class="portlet-body form">
                        <!-- BEGIN FORM-->
                        <form action="<?php echo base_url()?>cms/subSubCategories/save_sub_subcategories" class="form-horizontal" method="post" enctype="multipart/form-data" />
							<input type="hidden" name="sub_sub_cat_id" value="<?php echo $sub_sub_cat_id;?>"/>
							<input type="hidden" name="created_on" value="<?php echo date('d-m-Y')?>"/>
							 
						    <div class="control-group">
                              <label class="control-label">Sub-Subcategory Name</label>
                              <div class="controls">
                                <!-- <textarea  name="details"  id="ai" class="span12 ckeditor m-wrap" cols="30" rows="10">  </textarea> -->
									
								  <input type="text" <?php if($type=='view'){?>disabled<?php }?> name="sub_sub_cat_name" id="sub_sub_cat_name" value="<?php echo $sub_sub_cat_name?>" class="span4  m-wrap" /> 
                              </div>
                           </div>
                           <div class="control-group">
                              <label class="control-label">Sub-Category</label>
                              <div class="controls">
							 
                                <!-- <textarea  name="details"  id="ai" class="span12 ckeditor m-wrap" cols="30" rows="10">  </textarea> -->
									<select name='sub_cat_id' id='sub_cat_id' <?php if($type=='view'){?>disabled<?php }?> class="span4 m-wrap">
									<option value="<?php echo $sub_cat_id;?>"><?php echo $sub_cat_name?></option>
									<?php foreach ($page_data3 as $row){
										if($sub_cat_id!=$row['sub_cat_id']) 
										{
									?>
									<option value="<?php echo $row['sub_cat_id'];?>"><?php echo $row['sub_cat_name']?></option>
									<?php } }?>
									</select>
								  
                              </div>
                           </div>
						   <div class="control-group">
                              <label class="control-label">Category</label>
                              <div class="controls">
							 
                                <!-- <textarea  name="details"  id="ai" class="span12 ckeditor m-wrap" cols="30" rows="10">  </textarea> -->
									<select name='cat_id' id='cat_id' <?php if($type=='view'){?>disabled<?php }?> class="span4 m-wrap">
									
									<option value="<?php echo $cat_id ?>"><?php echo $category_name;?></option>
									<?php foreach ($page_data2 as $row){?>
									<option value="<?php echo $row['cat_id']?>"><?php echo $row['category_name']?></option>
									<?php }?>
									</select>
								  
                              </div>
                           </div>
						  
                           </div>
						  <?php if($type!='view'){ ?>
                           <div class="form-actions">
                           <button type="submit" class="btn blue">Save</button>
                              <button type="button" class="cancel btn">Cancel</button>
                           </div>
						   <?php }?>
                        </form>
                        <!-- END FORM-->           
                     </div>
                  </div>
                  <!-- END SAMPLE FORM PORTLET-->
               </div>
            </div>
			<script type="text/javascript">
			 $(document).ready(function(){
				 $("#add_new").click(function(){

				document.location="<?php echo base_url()?>cms/subcategories";
			});
				$(".cancel").click(function()
					{

					document.location="<?php echo base_url()?>cms/home_page/home_page_view";
				});             

				
		  });	
		  </script>	
			</div>
            </div>
			</div>